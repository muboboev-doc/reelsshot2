# Пошаговое руководство по внедрению

> Практические примеры кода для каждого этапа плана

---

## Phase 1: Критическая безопасность

### 1.1 Исправление Command Injection

**Проблема:**
```python
# УЯЗВИМОСТЬ!
command = ["yt-dlp", "-f", "mp4", "--output", video_path, reel_url]
subprocess.run(command, check=True)
```

**Решение:**
```python
import re
from urllib.parse import urlparse

# Разрешенные домены
ALLOWED_DOMAINS = {
    'instagram.com',
    'www.instagram.com',
    'youtube.com',
    'www.youtube.com',
    'youtu.be',
    'fb.watch',
    'facebook.com',
}

REEL_URL_PATTERN = re.compile(
    r'^https?://(?:www\.)?(?:instagram\.com/reel/[^/]+|'
    r'(?:youtube\.com/watch\?v=|youtu\.be/)[^&/?]+|'
    r'fb\.watch/[^/]+)/?$'
)

def validate_reel_url(url: str) -> bool:
    """Валидация URL с проверкой домена и формата."""
    if not url or len(url) > 500:
        return False
    
    # Проверка паттерна
    if not REEL_URL_PATTERN.match(url):
        return False
    
    # Проверка домена
    try:
        parsed = urlparse(url)
        domain = parsed.netloc.lower()
        if domain not in ALLOWED_DOMAINS:
            return False
    except Exception:
        return False
    
    return True

# Безопасный вызов
async def download_video(reel_url: str, output_path: str):
    if not validate_reel_url(reel_url):
        raise HTTPException(400, "Invalid URL")
    
    command = [
        "yt-dlp",
        "-f", "best[ext=mp4]/best",
        "--output", output_path,
        "--max-filesize", str(settings.max_file_size),
        "--",  # Разделитель - всё после этого считается URL
        reel_url
    ]
    
    proc = await asyncio.create_subprocess_exec(
        *command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    
    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(),
            timeout=300
        )
    except asyncio.TimeoutError:
        proc.kill()
        raise HTTPException(504, "Download timeout")
    
    if proc.returncode != 0:
        raise HTTPException(400, "Download failed")
```

---

### 1.2 Исправление Path Traversal

**Проблема:**
```python
# УЯЗВИМОСТЬ!
frame_path = os.path.join(STORAGE_FOLDER, unique_id, frame_name)
```

**Решение:**
```python
import re
from pathlib import Path

UUID_PATTERN = re.compile(
    r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
)

FILENAME_PATTERN = re.compile(r'^frame_\d{4}\.png$')

def validate_uuid(uuid_str: str) -> bool:
    """Валидация UUID v4 формата."""
    return bool(UUID_PATTERN.match(uuid_str))

def validate_filename(filename: str) -> bool:
    """Валидация имени файла кадра."""
    return bool(FILENAME_PATTERN.match(filename))

def get_safe_path(storage_folder: str, unique_id: str, filename: str) -> Path:
    """Безопасное построение пути с защитой от path traversal."""
    # Валидация входных данных
    if not validate_uuid(unique_id):
        raise HTTPException(400, "Invalid UUID format")
    
    if not validate_filename(filename):
        raise HTTPException(400, "Invalid filename format")
    
    # Построение пути
    base_path = Path(storage_folder).resolve()
    file_path = (base_path / unique_id / filename).resolve()
    
    # Критически важная проверка: путь должен быть внутри base_path
    try:
        file_path.relative_to(base_path)
    except ValueError:
        raise HTTPException(403, "Access denied")
    
    return file_path

# Использование в endpoint
@app.get("/get-frame/{unique_id}/{frame_name}")
async def get_frame(unique_id: str, frame_name: str):
    try:
        frame_path = get_safe_path(settings.storage_folder, unique_id, frame_name)
    except HTTPException:
        raise
    
    if not frame_path.exists():
        raise HTTPException(404, "Frame not found")
    
    return StreamingResponse(
        open(frame_path, "rb"),
        media_type="image/png"
    )
```

---

### 1.3 Исправление Arbitrary File Write

**Проблема:**
```python
# УЯЗВИМОСТЬ!
video_path = f"temp_{video_file.filename}"
with open(video_path, "wb") as buffer:
    buffer.write(video_file.file.read())
```

**Решение:**
```python
import uuid
from pathlib import Path

ALLOWED_EXTENSIONS = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
MAX_FILE_SIZE = 500 * 1024 * 1024  # 500MB

def validate_file_extension(filename: str) -> bool:
    """Проверка расширения файла."""
    ext = Path(filename).suffix.lower()
    return ext in ALLOWED_EXTENSIONS

@app.post("/extract-frames")
async def extract_frames_api(
    video_file: UploadFile = File(...),
    method: str = Form("ssim"),
    threshold: float = Form(0.8),
):
    # Валидация расширения
    if not validate_file_extension(video_file.filename):
        raise HTTPException(
            400,
            f"Invalid file type. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"
        )
    
    # Чтение и проверка размера
    contents = await video_file.read()
    if len(contents) > MAX_FILE_SIZE:
        raise HTTPException(413, f"File too large. Max: {MAX_FILE_SIZE // (1024*1024)}MB")
    
    # Генерация безопасного имени
    unique_id = str(uuid.uuid4())
    file_ext = Path(video_file.filename).suffix.lower()
    video_path = f"temp_{unique_id}{file_ext}"
    
    try:
        # Асинхронная запись
        async with aiofiles.open(video_path, "wb") as f:
            await f.write(contents)
        
        # Обработка...
        
    finally:
        # Гарантированная очистка
        if os.path.exists(video_path):
            os.remove(video_path)
```

---

### 1.4 Rate Limiting

**Установка:**
```bash
pip install slowapi redis
```

**Реализация:**
```python
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

# Redis backend для распределенного rate limiting
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["100/minute"],
    storage_uri="redis://localhost:6379"
)

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

@app.post("/extract-frames")
@limiter.limit("5/minute")  # Строгий лимит для upload
async def extract_frames_api(request: Request, ...):
    ...

@app.post("/extract-frames-url")
@limiter.limit("3/minute")  # Еще строже для URL
async def extract_frames_url_api(request: Request, ...):
    ...

@app.get("/get-frame/{unique_id}/{frame_name}")
@limiter.limit("60/minute")  # Более мягкий для чтения
async def get_frame(request: Request, ...):
    ...
```

---

## Phase 2: Производительность

### 2.1 Асинхронная обработка файлов

**Установка:**
```bash
pip install aiofiles
```

**Реализация:**
```python
import aiofiles
from concurrent.futures import ThreadPoolExecutor
import asyncio

# Глобальный пул потоков
executor = ThreadPoolExecutor(max_workers=4)

@app.post("/extract-frames")
async def extract_frames_api(...):
    unique_id = str(uuid.uuid4())
    video_path = f"temp_{unique_id}.mp4"
    
    try:
        # Асинхронное чтение
        contents = await video_file.read()
        
        # Асинхронная запись
        async with aiofiles.open(video_path, "wb") as f:
            await f.write(contents)
        
        # CPU-bound операция в пуле потоков
        loop = asyncio.get_event_loop()
        frame_names = await loop.run_in_executor(
            executor,
            extract_frames,
            video_path,
            method,
            threshold,
            frame_dir
        )
        
    finally:
        if os.path.exists(video_path):
            os.remove(video_path)
```

---

### 2.2 Оптимизация памяти в video_utils

**Оригинал:**
```python
def extract_frames(video_path, method, threshold, frame_dir):
    frames = {}  # Хранит все кадры в памяти!
    # ...
    frames[frame_name] = encode_frame(frame)  # Потребляет память
    return frames  # Возвращает все кадры
```

**Оптимизированная версия:**
```python
def extract_frames(
    video_path: str,
    method: str,
    threshold: float,
    frame_dir: str,
    skip_frames: int = 2,
    resize_for_comparison: tuple = (320, 240)
) -> List[str]:
    """
    Извлечение кадров с оптимизацией памяти.
    
    Returns:
        List[str]: Список имен сохраненных файлов (не сами кадры!)
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {video_path}")
    
    frame_names = []
    prev_frame = None
    frame_count = 0
    saved_count = 0
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # Пропуск кадров для производительности
            if frame_count % (skip_frames + 1) != 0:
                frame_count += 1
                continue
            
            # Уменьшение для быстрого сравнения
            small_frame = cv2.resize(frame, resize_for_comparison)
            gray_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2GRAY)
            
            if prev_frame is not None:
                should_save = False
                
                if method == 'ssim':
                    score, _ = ssim(prev_frame, gray_frame, full=True)
                    should_save = score < threshold
                elif method == 'pixel':
                    diff = cv2.absdiff(prev_frame, gray_frame)
                    diff_percent = np.count_nonzero(diff) / diff.size
                    should_save = diff_percent > threshold
                
                if should_save:
                    frame_name = f'frame_{saved_count:04d}.png'
                    frame_path = os.path.join(frame_dir, frame_name)
                    
                    # Сохраняем оригинал, но не храним в памяти
                    cv2.imwrite(frame_path, frame)
                    frame_names.append(frame_name)
                    saved_count += 1
            
            prev_frame = gray_frame
            frame_count += 1
    
    finally:
        cap.release()
    
    return frame_names  # Только имена файлов!
```

---

### 2.3 Graceful Shutdown

```python
import signal
import sys

@app.on_event("startup")
async def startup_event():
    """Инициализация при старте."""
    # Создание директорий
    os.makedirs(settings.storage_folder, exist_ok=True)
    
    # Настройка сигналов
    def signal_handler(sig, frame):
        print("\n🛑 Received shutdown signal, cleaning up...")
        # Очистка здесь
        sys.exit(0)
    
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    print(f"🚀 ReelShot API started")

@app.on_event("shutdown")
async def shutdown_event():
    """Очистка при завершении."""
    print("👋 Shutting down gracefully...")
    
    # Остановка пула потоков
    executor.shutdown(wait=True)
    
    # Очистка временных файлов
    for temp_file in Path('.').glob('temp_*'):
        temp_file.unlink()
    
    print("✅ Cleanup completed")
```

---

## Phase 3: Архитектура

### 3.1 Thread-safe хранилище задач

```python
import asyncio
from typing import Dict, Optional
from datetime import datetime, timedelta

class TaskStorage:
    """Thread-safe хранилище для background tasks."""
    
    def __init__(self):
        self._storage: Dict[str, Dict] = {}
        self._lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[Dict]:
        async with self._lock:
            return self._storage.get(key)
    
    async def set(self, key: str, value: Dict):
        async with self._lock:
            self._storage[key] = value
    
    async def update(self, key: str, updates: Dict):
        async with self._lock:
            if key in self._storage:
                self._storage[key].update(updates)
    
    async def delete(self, key: str):
        async with self._lock:
            self._storage.pop(key, None)
    
    async def get_all(self) -> Dict[str, Dict]:
        async with self._lock:
            return dict(self._storage)
    
    async def cleanup_old_tasks(self, max_age_hours: int = 24):
        """Очистка старых задач."""
        async with self._lock:
            current_time = datetime.now()
            to_delete = []
            
            for task_id, task in self._storage.items():
                start_time_str = task.get("start_time")
                if start_time_str:
                    start_time = datetime.fromisoformat(start_time_str)
                    if (current_time - start_time).total_seconds() > max_age_hours * 3600:
                        to_delete.append(task_id)
            
            for task_id in to_delete:
                del self._storage[task_id]
            
            return len(to_delete)

# Глобальный экземпляр
task_storage = TaskStorage()

# Использование
@app.get("/background-tasks/{unique_id}")
async def get_task_status(unique_id: str):
    task = await task_storage.get(unique_id)
    if not task:
        raise HTTPException(404, "Task not found")
    return task
```

---

### 3.2 Health Check Endpoint

```python
import psutil
from datetime import datetime

class HealthResponse(BaseModel):
    status: str
    timestamp: str
    version: str
    uptime_seconds: float
    system: dict
    dependencies: dict

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Комprehensive health check."""
    
    # Проверка диска
    disk = psutil.disk_usage(settings.storage_folder)
    disk_healthy = disk.percent < 90
    
    # Проверка памяти
    memory = psutil.virtual_memory()
    memory_healthy = memory.percent < 90
    
    # Проверка зависимостей
    redis_healthy = await check_redis_connection()
    
    overall_status = "healthy" if all([
        disk_healthy,
        memory_healthy,
        redis_healthy
    ]) else "degraded"
    
    return HealthResponse(
        status=overall_status,
        timestamp=datetime.now().isoformat(),
        version="2.0.0",
        uptime_seconds=time.time() - start_time,
        system={
            "disk_usage_percent": disk.percent,
            "memory_usage_percent": memory.percent,
            "cpu_percent": psutil.cpu_percent(interval=1)
        },
        dependencies={
            "redis": "up" if redis_healthy else "down",
            "storage": "writable" if disk_healthy else "full"
        }
    )
```

---

## Phase 4: База данных

### 4.1 SQLAlchemy модели

**Установка:**
```bash
pip install sqlalchemy asyncpg alembic
```

**Модели:**
```python
from sqlalchemy import Column, String, DateTime, Integer, Float, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

Base = declarative_base()

class VideoTask(Base):
    __tablename__ = "video_tasks"
    
    id = Column(String(36), primary_key=True)  # UUID
    status = Column(String(20), default="pending")  # pending, processing, completed, failed
    method = Column(String(10))  # ssim, pixel
    threshold = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    error_message = Column(String(500), nullable=True)
    frame_count = Column(Integer, default=0)
    file_size_bytes = Column(Integer, nullable=True)
    processing_time_seconds = Column(Float, nullable=True)
    
    # Для URL-based задач
    source_url = Column(String(500), nullable=True)
    
    # Метаданные
    video_duration_seconds = Column(Float, nullable=True)
    video_resolution = Column(String(20), nullable=True)

# Async engine
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

engine = create_async_engine(
    "postgresql+asyncpg://user:pass@localhost/reelshot",
    echo=False,
    future=True
)

async_session = sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)

# Использование
@app.post("/extract-frames")
async def extract_frames_api(...):
    unique_id = str(uuid.uuid4())
    
    # Сохранение в БД
    async with async_session() as session:
        task = VideoTask(
            id=unique_id,
            status="processing",
            method=method,
            threshold=threshold
        )
        session.add(task)
        await session.commit()
    
    # Обработка...
    
    # Обновление статуса
    async with async_session() as session:
        task = await session.get(VideoTask, unique_id)
        task.status = "completed"
        task.completed_at = datetime.utcnow()
        task.frame_count = len(frame_names)
        await session.commit()
```

---

### 4.2 Alembic миграции

**Инициализация:**
```bash
alembic init alembic
```

**Конфигурация alembic.ini:**
```ini
[alembic]
script_location = alembic
sqlalchemy.url = postgresql://user:pass@localhost/reelshot
```

**Создание миграции:**
```bash
alembic revision --autogenerate -m "Initial migration"
alembic upgrade head
```

---

## Phase 5: Celery очереди

### 5.1 Установка и настройка

```bash
pip install celery redis flower
```

**celery_app.py:**
```python
from celery import Celery
from celery.signals import task_postrun

app = Celery('reelshot')
app.conf.update(
    broker_url='redis://localhost:6379/0',
    result_backend='redis://localhost:6379/0',
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
    task_track_started=True,
    task_time_limit=600,  # 10 минут
    worker_prefetch_multiplier=1,
)

@app.task(bind=True, max_retries=3)
def process_video_task(self, video_path: str, method: str, threshold: float, frame_dir: str):
    """Celery task для обработки видео."""
    try:
        self.update_state(state='PROCESSING')
        
        frame_names = extract_frames(video_path, method, threshold, frame_dir)
        
        return {
            'status': 'completed',
            'frame_count': len(frame_names),
            'frames': frame_names
        }
    
    except Exception as exc:
        self.update_state(state='FAILED')
        raise self.retry(exc=exc, countdown=60)

# Flower monitoring
# celery -A celery_app flower --port=5555
```

**Использование в FastAPI:**
```python
from celery_app import process_video_task

@app.post("/extract-frames")
async def extract_frames_api(...):
    unique_id = str(uuid.uuid4())
    video_path = f"temp_{unique_id}.mp4"
    frame_dir = os.path.join(settings.storage_folder, unique_id)
    
    # Сохранение файла...
    
    # Запуск Celery task
    task = process_video_task.delay(
        video_path=video_path,
        method=method,
        threshold=threshold,
        frame_dir=frame_dir
    )
    
    return {
        "task_id": task.id,
        "unique_id": unique_id,
        "status": "processing"
    }

@app.get("/tasks/{task_id}")
async def get_task_status(task_id: str):
    task = process_video_task.AsyncResult(task_id)
    
    return {
        "task_id": task_id,
        "status": task.status,
        "result": task.result if task.ready() else None
    }
```

---

## Phase 6: S3 хранилище

### 6.1 Интеграция с boto3

```bash
pip install boto3 aiobotocore
```

**s3_client.py:**
```python
import boto3
from botocore.exceptions import ClientError

class S3Storage:
    def __init__(self):
        self.s3 = boto3.client(
            's3',
            aws_access_key_id=settings.aws_access_key,
            aws_secret_access_key=settings.aws_secret_key,
            region_name=settings.aws_region
        )
        self.bucket = settings.s3_bucket
    
    async def upload_frame(self, unique_id: str, frame_name: str, file_path: str):
        """Загрузка кадра в S3."""
        key = f"frames/{unique_id}/{frame_name}"
        
        self.s3.upload_file(
            file_path,
            self.bucket,
            key,
            ExtraArgs={
                'ContentType': 'image/png',
                'CacheControl': 'max-age=3600'
            }
        )
        
        return key
    
    async def get_presigned_url(self, key: str, expiration: int = 3600) -> str:
        """Генерация pre-signed URL."""
        try:
            url = self.s3.generate_presigned_url(
                'get_object',
                Params={'Bucket': self.bucket, 'Key': key},
                ExpiresIn=expiration
            )
            return url
        except ClientError:
            raise HTTPException(500, "Failed to generate URL")

s3_storage = S3Storage()

# Использование
@app.get("/get-frame/{unique_id}/{frame_name}")
async def get_frame(unique_id: str, frame_name: str):
    if settings.use_s3:
        key = f"frames/{unique_id}/{frame_name}"
        url = await s3_storage.get_presigned_url(key)
        return RedirectResponse(url)
    else:
        # Локальное хранение
        frame_path = get_safe_path(settings.storage_folder, unique_id, frame_name)
        return StreamingResponse(open(frame_path, "rb"), media_type="image/png")
```

---

## Phase 7: Мониторинг

### 7.1 Prometheus метрики

```bash
pip install prometheus-client
```

```python
from prometheus_client import Counter, Histogram, Gauge, generate_latest
from prometheus_client.core import CollectorRegistry

# Метрики
upload_counter = Counter(
    'video_uploads_total',
    'Total video uploads',
    ['method', 'status']
)

processing_time = Histogram(
    'video_processing_seconds',
    'Video processing time',
    ['method']
)

frame_counter = Counter(
    'frames_extracted_total',
    'Total frames extracted',
    ['method']
)

active_tasks = Gauge(
    'active_processing_tasks',
    'Number of active processing tasks'
)

# Middleware для сбора метрик
@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    duration = time.time() - start_time
    
    # Запись метрик
    if request.url.path == "/extract-frames":
        upload_counter.labels(
            method="upload",
            status=response.status_code
        ).inc()
        processing_time.labels(method="upload").observe(duration)
    
    return response

@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type="text/plain")
```

---

## Phase 8: Тестирование

### 8.1 Pytest fixtures

```python
import pytest
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch
import asyncio

@pytest.fixture
def client():
    return TestClient(app)

@pytest.fixture
def mock_video_file(tmp_path):
    """Создание тестового видео файла."""
    video_path = tmp_path / "test.mp4"
    video_path.write_bytes(b"fake video content")
    return str(video_path)

@pytest.fixture
def mock_task_storage():
    """Mock для task storage."""
    with patch('main.task_storage') as mock:
        mock.get = Mock(return_value={
            "status": "completed",
            "frames": ["frame_0000.png"]
        })
        yield mock

# Тесты
def test_extract_frames_success(client, mock_video_file):
    with patch('main.extract_frames') as mock_extract:
        mock_extract.return_value = ["frame_0000.png"]
        
        with open(mock_video_file, "rb") as f:
            response = client.post(
                "/extract-frames",
                files={"video_file": ("test.mp4", f, "video/mp4")},
                data={"method": "ssim", "threshold": "0.8"}
            )
        
        assert response.status_code == 201
        assert "unique_id" in response.json()

def test_path_traversal_protection(client):
    response = client.get("/get-frame/../../../etc/passwd/test.png")
    assert response.status_code in [400, 403, 404]

@pytest.mark.asyncio
async def test_task_storage_thread_safety():
    storage = TaskStorage()
    
    # Конкурентные записи
    await asyncio.gather(
        storage.set("task1", {"status": "pending"}),
        storage.set("task2", {"status": "processing"}),
        storage.set("task3", {"status": "completed"}),
    )
    
    all_tasks = await storage.get_all()
    assert len(all_tasks) == 3
```

---

## Phase 9: Деплой

### 9.1 Docker Compose продакшен

```yaml
version: '3.8'

services:
  app:
    build: .
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '2'
          memory: 2G
    environment:
      - DATABASE_URL=postgresql://user:pass@postgres:5432/reelshot
      - REDIS_URL=redis://redis:6379/0
      - S3_BUCKET=reelshot-production
    depends_on:
      - postgres
      - redis
  
  worker:
    build: .
    command: celery -A celery_app worker --loglevel=info --concurrency=4
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '4'
          memory: 4G
    depends_on:
      - redis
      - postgres
  
  postgres:
    image: postgres:15-alpine
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=reelshot
  
  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data
  
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.prod.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - app

volumes:
  postgres_data:
  redis_data:
```

---

## 📋 Чеклист внедрения

### Перед началом:
- [ ] Создать ветку `production-readiness`
- [ ] Настроить тестовое окружение
- [ ] Сделать бэкап текущего кода

### После каждой фазы:
- [ ] Запустить тесты
- [ ] Проверить security scan
- [ ] Обновить документацию
- [ ] Сделать коммит

### Перед деплоем:
- [ ] Пройти полный чеклист
- [ ] Провести load testing
- [ ] Провести security audit
- [ ] Подготовить rollback план

---

**Начните с Phase 1 и следуйте плану последовательно!**
