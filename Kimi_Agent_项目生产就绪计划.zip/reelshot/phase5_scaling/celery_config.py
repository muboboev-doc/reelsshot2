"""
Celery Configuration for ReelShot Backend
Асинхронная обработка задач с Redis брокером
"""

from celery import Celery
from celery.signals import task_failure, task_success, task_retry
import logging
import os

# Logging setup
logger = logging.getLogger(__name__)

# Redis URL from environment
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")

# Create Celery app
celery_app = Celery(
    "reelshot",
    broker=REDIS_URL,
    backend=REDIS_URL,
    include=["tasks"]  # Модуль с задачами
)

# Celery Configuration
celery_app.conf.update(
    # Task settings
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    
    # Task execution
    task_track_started=True,
    task_time_limit=300,  # 5 minutes max per task
    task_soft_time_limit=240,  # Soft limit 4 minutes
    
    # Worker settings
    worker_prefetch_multiplier=1,  # One task at a time per worker
    worker_max_tasks_per_child=50,  # Restart worker after 50 tasks
    
    # Result backend
    result_expires=3600,  # Results expire after 1 hour
    result_backend_max_retries=3,
    
    # Retry settings
    task_default_retry_delay=60,  # 1 minute
    task_max_retries=3,
    
    # Rate limiting
    task_annotations={
        "tasks.process_video": {"rate_limit": "10/m"},
        "tasks.upload_to_s3": {"rate_limit": "20/m"},
    },
    
    # Queue configuration
    task_routes={
        "tasks.process_video": {"queue": "video_processing"},
        "tasks.upload_to_s3": {"queue": "s3_operations"},
        "tasks.cleanup_old_files": {"queue": "maintenance"},
    },
    
    # Monitoring
    worker_send_task_events=True,
    task_send_sent_event=True,
)


# ============ SIGNALS ============

@task_failure.connect
def handle_task_failure(sender=None, task_id=None, exception=None, **kwargs):
    """Обработка ошибок задач"""
    logger.error(f"Task {sender.name}[{task_id}] failed: {exception}")


@task_success.connect
def handle_task_success(sender=None, result=None, **kwargs):
    """Обработка успешных задач"""
    logger.info(f"Task {sender.name} completed successfully")


@task_retry.connect
def handle_task_retry(sender=None, request=None, reason=None, **kwargs):
    """Обработка retry задач"""
    logger.warning(f"Task {sender.name} retrying: {reason}")


# ============ HEALTH CHECK ============

@celery_app.task(bind=True)
def health_check(self):
    """Health check задача для мониторинга Celery"""
    return {
        "status": "healthy",
        "worker": self.request.hostname,
        "timestamp": datetime.utcnow().isoformat()
    }


# ============ BEAT SCHEDULE (Periodic Tasks) ============

from datetime import datetime

celery_app.conf.beat_schedule = {
    "cleanup-old-files": {
        "task": "tasks.cleanup_old_files",
        "schedule": 3600.0,  # Every hour
    },
    "health-check": {
        "task": "celery_config.health_check",
        "schedule": 60.0,  # Every minute
    },
}

if __name__ == "__main__":
    celery_app.start()
