# Фаза 5: Масштабирование

## Обзор

Фаза 5 добавляет горизонтальное масштабирование через Celery + Redis для асинхронной обработки задач, S3-хранилище для кадров, CDN интеграцию и нагрузочное тестирование.

## Архитектура

```
┌─────────────┐     ┌─────────────┐     ┌─────────────────┐
│   Client    │────▶│    Nginx    │────▶│   FastAPI App   │
└─────────────┘     └─────────────┘     └────────┬────────┘
                                                  │
                       ┌──────────────────────────┘
                       │
                       ▼
              ┌─────────────────┐
              │   Redis Queue   │
              └────────┬────────┘
                       │
         ┌─────────────┼─────────────┐
         ▼             ▼             ▼
   ┌──────────┐  ┌──────────┐  ┌──────────┐
   │ Worker 1 │  │ Worker 2 │  │ Worker N │
   └────┬─────┘  └────┬─────┘  └────┬─────┘
        │             │             │
        └─────────────┴─────────────┘
                      │
                      ▼
              ┌───────────────┐
              │  S3 / Local   │
              └───────────────┘
```

## Компоненты

### 1. Celery Workers

```bash
# Запуск worker
 celery -A celery_config worker --loglevel=info --concurrency=4

# Запуск beat (scheduler)
celery -A celery_config beat --loglevel=info

# Flower (monitoring)
celery -A celery_config flower --port=5555
```

### 2. API Endpoints

| Endpoint | Method | Описание | Rate Limit |
|----------|--------|----------|------------|
| `/api/v1/screenshot/async` | POST | Асинхронный скриншот | 5/min |
| `/api/v1/screenshot/batch` | POST | Пакетная обработка | 2/min |
| `/api/v1/tasks/{id}` | GET | Статус задачи | 10/sec |
| `/api/v1/tasks/{id}/result` | GET | Результат задачи | 10/sec |
| `/api/v1/workers` | GET | Статус workers | 1/sec |

### 3. Environment Variables

```bash
# Celery
REDIS_URL=redis://redis:6379/0
WORKER_CONCURRENCY=4
CELERY_WORKERS=2

# S3
S3_BUCKET_NAME=reelshot-frames
AWS_ACCESS_KEY_ID=xxx
AWS_SECRET_ACCESS_KEY=xxx
AWS_REGION=us-east-1
CDN_URL=https://cdn.example.com

# Flower
FLOWER_AUTH=admin:securepassword
```

## Запуск

```bash
# 1. Запуск всего стека
docker-compose -f docker-compose.scaling.yml up -d

# 2. Масштабирование workers
docker-compose -f docker-compose.scaling.yml up -d --scale celery_worker=5

# 3. Просмотр логов workers
docker-compose -f docker-compose.scaling.yml logs -f celery_worker

# 4. Открыть Flower UI
open http://localhost:5555
```

## Нагрузочное тестирование

```bash
# Запуск Locust
docker-compose -f docker-compose.scaling.yml --profile testing up -d

# Открыть Locust UI
open http://localhost:8089

# Headless mode
locust -f locustfile.py --host=http://localhost \
  --headless -u 100 -r 10 --run-time 5m
```

## Мониторинг

### Prometheus Metrics

- `celery_tasks_total` - Всего задач
- `celery_tasks_active` - Активные задачи
- `http_requests_total` - HTTP запросы
- `http_request_duration_seconds` - Время ответа

### Grafana Dashboards

- Celery Tasks Overview
- API Performance
- System Resources

## Очереди

| Queue | Purpose | Priority |
|-------|---------|----------|
| `video_processing` | Обработка видео | High |
| `s3_operations` | Загрузка в S3 | Medium |
| `maintenance` | Очистка файлов | Low |

## Результаты нагрузочного тестирования

### Целевые показатели

| Metric | Target | Current |
|--------|--------|---------|
| RPS | 100 | TBD |
| P95 Latency | < 500ms | TBD |
| Error Rate | < 1% | TBD |
| Task Throughput | 50/min | TBD |

## Troubleshooting

### Workers не обрабатывают задачи

```bash
# Проверить подключение к Redis
docker-compose exec celery_worker celery -A celery_config inspect ping

# Проверить очереди
docker-compose exec celery_worker celery -A celery_config inspect active

# Перезапустить workers
docker-compose restart celery_worker
```

### Очередь переполнена

```bash
# Проверить длину очереди
redis-cli LLEN celery

# Очистить очередь (осторожно!)
redis-cli DEL celery

# Масштабировать workers
docker-compose up -d --scale celery_worker=10
```

## Безопасность

- Flower защищен basic auth
- S3 credentials в environment variables
- Rate limiting на async endpoints
- Webhook URL validation
