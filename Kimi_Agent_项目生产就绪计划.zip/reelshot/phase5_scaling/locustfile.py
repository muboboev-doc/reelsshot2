"""
Locust Load Testing for ReelShot Async API
Нагрузочное тестирование API

Usage:
    locust -f locustfile.py --host=http://localhost:8000
"""

from locust import HttpUser, task, between, events
from locust.runners import MasterRunner
import random
import json
import time
import logging

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Test data
TEST_URLS = [
    "https://www.instagram.com/reel/C0xAMPLE1/",
    "https://www.instagram.com/reel/C0xAMPLE2/",
    "https://www.instagram.com/reel/C0xAMPLE3/",
    "https://instagram.com/reel/C0xAMPLE4/",
    "https://instagr.am/reel/C0xAMPLE5/",
]

API_TOKEN = "your-secure-token-here"  # Change in production


class ReelShotUser(HttpUser):
    """Симуляция пользователя API"""
    
    wait_time = between(1, 5)  # Wait 1-5 seconds between tasks
    
    def on_start(self):
        """Вызывается при старте пользователя"""
        self.headers = {
            "Authorization": f"Bearer {API_TOKEN}",
            "Content-Type": "application/json"
        }
        logger.info(f"User started: {self.user_id}")
    
    @task(3)
    def health_check(self):
        """Тест health endpoint"""
        with self.client.get("/health", catch_response=True) as response:
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "healthy":
                    response.success()
                else:
                    response.failure("Health check returned unhealthy status")
            else:
                response.failure(f"Health check failed: {response.status_code}")
    
    @task(2)
    def get_task_status_random(self):
        """Тест получения статуса задачи (с рандомным ID)"""
        task_id = f"random-task-{random.randint(1000, 9999)}"
        
        with self.client.get(
            f"/api/v1/tasks/{task_id}",
            headers=self.headers,
            catch_response=True
        ) as response:
            # Task not found is expected for random IDs
            if response.status_code in [200, 404]:
                response.success()
            else:
                response.failure(f"Unexpected status: {response.status_code}")
    
    @task(1)
    def create_async_screenshot(self):
        """Тест создания асинхронного скриншота"""
        payload = {
            "url": random.choice(TEST_URLS),
            "timestamp": random.uniform(0, 30),
            "format": random.choice(["jpg", "png", "webp"]),
            "quality": random.randint(1, 5)
        }
        
        with self.client.post(
            "/api/v1/screenshot/async",
            json=payload,
            headers=self.headers,
            catch_response=True
        ) as response:
            if response.status_code == 200:
                data = response.json()
                if "task_id" in data:
                    response.success()
                    # Store task_id for future checks
                    self.task_id = data["task_id"]
                else:
                    response.failure("No task_id in response")
            elif response.status_code == 429:
                response.success()  # Rate limiting is expected
            else:
                response.failure(f"Failed: {response.status_code} - {response.text}")
    
    @task(1)
    def create_batch_screenshots(self):
        """Тест пакетной обработки"""
        count = random.randint(2, 5)
        
        payload = {
            "urls": [random.choice(TEST_URLS) for _ in range(count)],
            "timestamps": [random.uniform(0, 30) for _ in range(count)]
        }
        
        with self.client.post(
            "/api/v1/screenshot/batch",
            json=payload,
            headers=self.headers,
            catch_response=True
        ) as response:
            if response.status_code == 200:
                data = response.json()
                if "task_id" in data:
                    response.success()
                else:
                    response.failure("No task_id in response")
            elif response.status_code == 429:
                response.success()
            else:
                response.failure(f"Failed: {response.status_code}")
    
    @task(1)
    def get_metrics(self):
        """Тест endpoint метрик"""
        with self.client.get("/metrics", catch_response=True) as response:
            if response.status_code == 200:
                response.success()
            else:
                response.failure(f"Metrics failed: {response.status_code}")


class HeavyLoadUser(HttpUser):
    """Пользователь для тяжелой нагрузки"""
    
    wait_time = between(0.1, 0.5)  # Very short wait times
    weight = 1  # Lower weight than normal user
    
    def on_start(self):
        self.headers = {
            "Authorization": f"Bearer {API_TOKEN}",
            "Content-Type": "application/json"
        }
    
    @task(10)
    def health_check_heavy(self):
        """Интенсивный тест health endpoint"""
        self.client.get("/health")
    
    @task(5)
    def create_screenshot_heavy(self):
        """Интенсивное создание задач"""
        payload = {
            "url": random.choice(TEST_URLS),
            "timestamp": random.uniform(0, 30),
            "format": "jpg",
            "quality": 3
        }
        
        with self.client.post(
            "/api/v1/screenshot/async",
            json=payload,
            headers=self.headers,
            catch_response=True
        ) as response:
            if response.status_code == 429:
                response.success()  # Rate limit expected under heavy load
            elif response.status_code == 200:
                response.success()


# ============ EVENT HOOKS ============

@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    """Вызывается при старте теста"""
    logger.info("=" * 50)
    logger.info("LOAD TEST STARTED")
    logger.info("=" * 50)
    
    if isinstance(environment.runner, MasterRunner):
        logger.info("Running in distributed mode (master)")
    else:
        logger.info("Running in standalone/worker mode")


@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """Вызывается при остановке теста"""
    logger.info("=" * 50)
    logger.info("LOAD TEST STOPPED")
    logger.info("=" * 50)


@events.request.add_listener
def on_request(request_type, name, response_time, response_length, 
               response, context, exception, **kwargs):
    """Логирование запросов"""
    if exception:
        logger.warning(f"Request failed: {request_type} {name} - {exception}")


# ============ CUSTOM COMMANDS ============

if __name__ == "__main__":
    import sys
    
    # Allow running with: python locustfile.py
    print("To run load tests:")
    print("  locust -f locustfile.py --host=http://localhost:8000")
    print("")
    print("Headless mode:")
    print("  locust -f locustfile.py --host=http://localhost:8000 \\")
    print("    --headless -u 100 -r 10 --run-time 5m")
    print("")
    print("Distributed mode:")
    print("  # Master")
    print("  locust -f locustfile.py --master")
    print("  # Workers")
    print("  locust -f locustfile.py --worker --master-host=localhost")
