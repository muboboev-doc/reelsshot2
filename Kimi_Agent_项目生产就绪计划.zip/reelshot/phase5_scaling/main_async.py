"""
ReelShot Backend - Async API with Celery Integration
Масштабируемая версия с асинхронной обработкой задач
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends, Request, Query
from fastapi.responses import JSONResponse, FileResponse, RedirectResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi_limiter import FastAPILimiter
from fastapi_limiter.depends import RateLimiter
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from prometheus_client.openmetrics.exposition import generate_latest as generate_latest_openmetrics
from starlette.responses import PlainTextResponse
from contextlib import asynccontextmanager
from typing import Optional, List
from pydantic import BaseModel, Field, field_validator, HttpUrl
import redis.asyncio as redis
import os
import logging
import time
from datetime import datetime
import asyncio

# Celery imports
from celery.result import AsyncResult
from celery_config import celery_app
from tasks import process_video, cleanup_old_files, batch_process_videos

# Security imports
from security import validate_url, sanitize_filename, verify_token
from validators import validate_reel_url, ValidationError

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Environment variables
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
API_TOKEN = os.getenv("API_TOKEN", "your-secure-token-here")
FRAMES_DIR = os.getenv("FRAMES_DIR", "/app/frames")
MAX_CONCURRENT_TASKS = int(os.getenv("MAX_CONCURRENT_TASKS", "10"))

# Prometheus metrics
http_requests_total = Counter(
    "http_requests_total",
    "Total HTTP requests",
    ["method", "endpoint", "status"]
)

http_request_duration_seconds = Histogram(
    "http_request_duration_seconds",
    "HTTP request duration in seconds",
    ["method", "endpoint"],
    buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0]
)

celery_tasks_total = Counter(
    "celery_tasks_total",
    "Total Celery tasks",
    ["task_name", "status"]
)

celery_tasks_active = Gauge(
    "celery_tasks_active",
    "Number of active Celery tasks"
)

# ============ LIFESPAN ============

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting up ReelShot Async API...")
    
    # Initialize Redis for rate limiting
    redis_connection = redis.from_url(REDIS_URL, encoding="utf-8", decode_responses=True)
    await FastAPILimiter.init(redis_connection)
    logger.info("Rate limiter initialized")
    
    # Create frames directory
    os.makedirs(FRAMES_DIR, exist_ok=True)
    
    yield
    
    # Shutdown
    logger.info("Shutting down ReelShot Async API...")
    await redis_connection.close()

# ============ APP INITIALIZATION ============

app = FastAPI(
    title="ReelShot Async API",
    description="Масштабируемый API для создания скриншотов из Instagram Reels с Celery",
    version="2.0.0",
    lifespan=lifespan
)

# Security middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.add_middleware(TrustedHostMiddleware, allowed_hosts=["*"])

# Auth
security = HTTPBearer()

# ============ MIDDLEWARE ============

@app.middleware("http")
async def metrics_middleware(request: Request, call_next):
    """Middleware для сбора метрик"""
    start_time = time.time()
    
    response = await call_next(request)
    
    duration = time.time() - start_time
    endpoint = request.url.path
    method = request.method
    status = str(response.status_code)
    
    http_requests_total.labels(
        method=method,
        endpoint=endpoint,
        status=status
    ).inc()
    
    http_request_duration_seconds.labels(
        method=method,
        endpoint=endpoint
    ).observe(duration)
    
    return response

# ============ PYDANTIC MODELS ============

class AsyncScreenshotRequest(BaseModel):
    """Модель запроса для асинхронного создания скриншота"""
    url: str = Field(..., description="URL Instagram Reels")
    timestamp: float = Field(0.0, ge=0, description="Временная метка в секундах")
    format: str = Field("jpg", pattern="^(jpg|jpeg|png|webp)$")
    quality: int = Field(2, ge=1, le=5, description="Качество (1-лучшее, 5-худшее)")
    webhook_url: Optional[str] = Field(None, description="URL для webhook callback")
    
    @field_validator("url")
    @classmethod
    def validate_instagram_url(cls, v):
        if not validate_reel_url(v):
            raise ValueError("Invalid Instagram Reels URL")
        return v

class BatchRequest(BaseModel):
    """Модель для пакетной обработки"""
    urls: List[str] = Field(..., min_length=1, max_length=100)
    timestamps: List[float] = Field(..., min_length=1)
    webhook_url: Optional[str] = None
    
    @field_validator("urls")
    @classmethod
    def validate_urls(cls, v):
        for url in v:
            if not validate_reel_url(url):
                raise ValueError(f"Invalid URL: {url}")
        return v
    
    @field_validator("timestamps")
    @classmethod
    def validate_timestamps(cls, v, info):
        urls = info.data.get("urls", [])
        if len(v) != len(urls):
            raise ValueError("Number of timestamps must match number of URLs")
        return v

class TaskResponse(BaseModel):
    """Модель ответа с task_id"""
    task_id: str
    status: str
    message: str
    created_at: str

class TaskStatusResponse(BaseModel):
    """Модель статуса задачи"""
    task_id: str
    status: str
    result: Optional[dict] = None
    progress: Optional[dict] = None

# ============ AUTH DEPENDENCY ============

async def verify_auth(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Проверка токена авторизации"""
    token = credentials.credentials
    if token != API_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid token")
    return token

# ============ API ENDPOINTS ============

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "ReelShot Async API",
        "version": "2.0.0",
        "status": "operational",
        "docs": "/docs"
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    # Check Celery workers
    try:
        inspector = celery_app.control.inspect()
        active_workers = inspector.active()
        worker_count = len(active_workers) if active_workers else 0
        
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "celery_workers": worker_count,
            "version": "2.0.0"
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )

@app.post(
    "/api/v1/screenshot/async",
    response_model=TaskResponse,
    dependencies=[Depends(RateLimiter(times=5, seconds=60))]
)
async def create_screenshot_async(
    request: AsyncScreenshotRequest,
    token: str = Depends(verify_auth)
):
    """
    Создание скриншота асинхронно через Celery
    
    Returns task_id для отслеживания статуса
    """
    try:
        # Queue the task
        task = process_video.delay(
            video_url=request.url,
            timestamp=request.timestamp,
            output_format=request.format,
            quality=request.quality,
            webhook_url=request.webhook_url
        )
        
        celery_tasks_total.labels(
            task_name="process_video",
            status="queued"
        ).inc()
        
        logger.info(f"Task queued: {task.id} for URL: {request.url}")
        
        return TaskResponse(
            task_id=task.id,
            status="queued",
            message="Screenshot task queued successfully",
            created_at=datetime.utcnow().isoformat()
        )
    
    except Exception as e:
        logger.error(f"Failed to queue task: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to queue task: {str(e)}")

@app.post(
    "/api/v1/screenshot/batch",
    response_model=TaskResponse,
    dependencies=[Depends(RateLimiter(times=2, seconds=60))]
)
async def create_batch_screenshots(
    request: BatchRequest,
    token: str = Depends(verify_auth)
):
    """
    Пакетная обработка нескольких видео
    
    Returns batch task_id
    """
    try:
        task = batch_process_videos.delay(
            video_urls=request.urls,
            timestamps=request.timestamps,
            webhook_url=request.webhook_url
        )
        
        celery_tasks_total.labels(
            task_name="batch_process_videos",
            status="queued"
        ).inc()
        
        logger.info(f"Batch task queued: {task.id}, {len(request.urls)} videos")
        
        return TaskResponse(
            task_id=task.id,
            status="queued",
            message=f"Batch task queued for {len(request.urls)} videos",
            created_at=datetime.utcnow().isoformat()
        )
    
    except Exception as e:
        logger.error(f"Failed to queue batch: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to queue batch: {str(e)}")

@app.get("/api/v1/tasks/{task_id}", response_model=TaskStatusResponse)
async def get_task_status(task_id: str):
    """
    Получение статуса задачи Celery
    """
    try:
        task_result = AsyncResult(task_id, app=celery_app)
        
        response = {
            "task_id": task_id,
            "status": task_result.status,
        }
        
        # Add progress info if available
        if task_result.info and isinstance(task_result.info, dict):
            response["progress"] = task_result.info
        
        # Add result if task is complete
        if task_result.ready():
            if task_result.successful():
                response["result"] = task_result.result
            else:
                response["result"] = {"error": str(task_result.result)}
        
        return TaskStatusResponse(**response)
    
    except Exception as e:
        logger.error(f"Failed to get task status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get task status: {str(e)}")

@app.get("/api/v1/tasks/{task_id}/result")
async def get_task_result(task_id: str):
    """
    Получение результата задачи (перенаправление на URL кадра)
    """
    try:
        task_result = AsyncResult(task_id, app=celery_app)
        
        if not task_result.ready():
            raise HTTPException(status_code=202, detail="Task not ready yet")
        
        if not task_result.successful():
            raise HTTPException(status_code=500, detail=f"Task failed: {task_result.result}")
        
        result = task_result.result
        
        if not result.get("success"):
            raise HTTPException(status_code=500, detail=result.get("error", "Unknown error"))
        
        # Redirect to frame URL
        frame_url = result.get("url")
        if frame_url:
            return RedirectResponse(url=frame_url)
        else:
            raise HTTPException(status_code=404, detail="Frame URL not found")
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get task result: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get task result: {str(e)}")

@app.post("/api/v1/tasks/cleanup")
async def trigger_cleanup(
    max_age_hours: int = Query(24, ge=1, le=168),
    token: str = Depends(verify_auth)
):
    """
    Запуск задачи очистки старых файлов
    """
    try:
        task = cleanup_old_files.delay(max_age_hours=max_age_hours)
        
        return {
            "task_id": task.id,
            "status": "queued",
            "message": f"Cleanup queued for files older than {max_age_hours} hours"
        }
    
    except Exception as e:
        logger.error(f"Failed to queue cleanup: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to queue cleanup: {str(e)}")

@app.get("/api/v1/workers")
async def get_workers_status(token: str = Depends(verify_auth)):
    """
    Статус Celery workers
    """
    try:
        inspector = celery_app.control.inspect()
        
        return {
            "active": inspector.active() or {},
            "scheduled": inspector.scheduled() or {},
            "reserved": inspector.reserved() or {},
            "stats": inspector.stats() or {}
        }
    
    except Exception as e:
        logger.error(f"Failed to get workers status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get workers status: {str(e)}")

# ============ METRICS ============

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return PlainTextResponse(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST
    )

# ============ ERROR HANDLERS ============

@app.exception_handler(ValidationError)
async def validation_error_handler(request: Request, exc: ValidationError):
    return JSONResponse(
        status_code=400,
        content={
            "error": "Validation error",
            "message": str(exc),
            "timestamp": datetime.utcnow().isoformat()
        }
    )

@app.exception_handler(Exception)
async def general_error_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "message": str(exc) if os.getenv("DEBUG") else "An error occurred",
            "timestamp": datetime.utcnow().isoformat()
        }
    )

# ============ MAIN ============

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main_async:app",
        host="0.0.0.0",
        port=8000,
        reload=os.getenv("DEBUG", "false").lower() == "true",
        workers=1
    )
