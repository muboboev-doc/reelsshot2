"""
Celery Tasks for ReelShot Backend
Асинхронные задачи для обработки видео и работы с S3
"""

from celery import Task
from celery.exceptions import MaxRetriesExceededError, SoftTimeLimitExceeded
from celery_config import celery_app
from typing import Optional, Dict, Any
import logging
import os
import tempfile
import shutil
from datetime import datetime, timedelta
import asyncio
import subprocess
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

# Logging
logger = logging.getLogger(__name__)

# S3 Configuration
S3_BUCKET = os.getenv("S3_BUCKET_NAME", "reelshot-frames")
S3_REGION = os.getenv("AWS_REGION", "us-east-1")
S3_ACCESS_KEY = os.getenv("AWS_ACCESS_KEY_ID")
S3_SECRET_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
S3_ENDPOINT_URL = os.getenv("S3_ENDPOINT_URL")  # For MinIO compatibility
S3_CDN_URL = os.getenv("CDN_URL")  # CloudFront/CloudFlare CDN URL

# Local storage for fallback
FRAMES_DIR = os.getenv("FRAMES_DIR", "/app/frames")


# ============ BASE TASK CLASS ============

class ReelShotTask(Task):
    """Базовый класс задачи с обработкой ошибок"""
    
    autoretry_for = (Exception,)
    retry_backoff = True
    retry_backoff_max = 300  # Max 5 minutes
    retry_jitter = True
    max_retries = 3
    
    def on_failure(self, exc, task_id, args, kwargs, einfo):
        logger.error(f"Task {self.name} failed: {exc}")
        super().on_failure(exc, task_id, args, kwargs, einfo)
    
    def on_retry(self, exc, task_id, args, kwargs, einfo):
        logger.warning(f"Task {self.name} retrying: {exc}")
        super().on_retry(exc, task_id, args, kwargs, einfo)
    
    def on_success(self, retval, task_id, args, kwargs):
        logger.info(f"Task {self.name} succeeded")
        super().on_success(retval, task_id, args, kwargs)


# ============ S3 CLIENT ============

def get_s3_client():
    """Создание S3 клиента"""
    try:
        session = boto3.Session(
            aws_access_key_id=S3_ACCESS_KEY,
            aws_secret_access_key=S3_SECRET_KEY,
            region_name=S3_REGION
        )
        
        client_kwargs = {
            "service_name": "s3",
            "region_name": S3_REGION,
        }
        
        if S3_ENDPOINT_URL:
            client_kwargs["endpoint_url"] = S3_ENDPOINT_URL
        
        return session.client(**client_kwargs)
    except NoCredentialsError:
        logger.error("AWS credentials not found")
        return None
    except Exception as e:
        logger.error(f"Failed to create S3 client: {e}")
        return None


# ============ VIDEO PROCESSING TASK ============

@celery_app.task(bind=True, base=ReelShotTask)
def process_video(
    self,
    video_url: str,
    timestamp: float,
    output_format: str = "jpg",
    quality: int = 2,
    webhook_url: Optional[str] = None
) -> Dict[str, Any]:
    """
    Асинхронная обработка видео и извлечение кадра
    
    Args:
        video_url: URL видео для обработки
        timestamp: Временная метка для скриншота
        output_format: Формат выходного файла
        quality: Качество (1-5, где 1 - лучшее)
        webhook_url: URL для webhook callback
    
    Returns:
        Dict с результатом обработки
    """
    task_id = self.request.id
    temp_dir = None
    
    try:
        logger.info(f"[{task_id}] Starting video processing: {video_url}")
        
        # Create temp directory
        temp_dir = tempfile.mkdtemp(prefix=f"reelshot_{task_id}_")
        output_path = os.path.join(temp_dir, f"frame.{output_format}")
        
        # Download video
        video_path = os.path.join(temp_dir, "video.mp4")
        self.update_state(state="PROGRESS", meta={"step": "downloading", "progress": 10})
        
        download_result = _download_video(video_url, video_path)
        if not download_result["success"]:
            raise Exception(f"Download failed: {download_result['error']}")
        
        # Extract frame
        self.update_state(state="PROGRESS", meta={"step": "extracting", "progress": 50})
        
        extract_result = _extract_frame(
            video_path=video_path,
            timestamp=timestamp,
            output_path=output_path,
            quality=quality
        )
        
        if not extract_result["success"]:
            raise Exception(f"Extraction failed: {extract_result['error']}")
        
        # Upload to S3
        self.update_state(state="PROGRESS", meta={"step": "uploading", "progress": 80})
        
        s3_key = f"frames/{task_id}/{int(timestamp)}.{output_format}"
        upload_result = _upload_file_to_s3(output_path, s3_key)
        
        if not upload_result["success"]:
            # Fallback to local storage
            local_path = os.path.join(FRAMES_DIR, s3_key)
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            shutil.copy2(output_path, local_path)
            
            result = {
                "success": True,
                "task_id": task_id,
                "storage": "local",
                "path": local_path,
                "url": f"/frames/{task_id}/{int(timestamp)}.{output_format}",
                "timestamp": timestamp,
                "format": output_format,
                "size_bytes": os.path.getsize(output_path),
                "processed_at": datetime.utcnow().isoformat()
            }
        else:
            # Generate CDN URL
            frame_url = f"{S3_CDN_URL}/{s3_key}" if S3_CDN_URL else upload_result["url"]
            
            result = {
                "success": True,
                "task_id": task_id,
                "storage": "s3",
                "bucket": S3_BUCKET,
                "key": s3_key,
                "url": frame_url,
                "timestamp": timestamp,
                "format": output_format,
                "size_bytes": upload_result["size"],
                "processed_at": datetime.utcnow().isoformat()
            }
        
        # Send webhook if provided
        if webhook_url:
            _send_webhook(webhook_url, result)
        
        logger.info(f"[{task_id}] Video processing completed successfully")
        return result
        
    except SoftTimeLimitExceeded:
        logger.error(f"[{task_id}] Task timed out")
        raise self.retry(exc=Exception("Task timed out"), countdown=60)
    
    except Exception as e:
        logger.error(f"[{task_id}] Processing failed: {e}")
        
        # Retry logic
        if self.request.retries < self.max_retries:
            countdown = 60 * (self.request.retries + 1)
            logger.info(f"[{task_id}] Retrying in {countdown} seconds...")
            raise self.retry(exc=e, countdown=countdown)
        
        # Max retries exceeded
        error_result = {
            "success": False,
            "task_id": task_id,
            "error": str(e),
            "retries": self.request.retries,
            "failed_at": datetime.utcnow().isoformat()
        }
        
        if webhook_url:
            _send_webhook(webhook_url, error_result)
        
        return error_result
    
    finally:
        # Cleanup temp directory
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
                logger.debug(f"[{task_id}] Cleaned up temp directory: {temp_dir}")
            except Exception as e:
                logger.warning(f"[{task_id}] Failed to cleanup temp dir: {e}")


# ============ HELPER FUNCTIONS ============

def _download_video(url: str, output_path: str) -> Dict[str, Any]:
    """Скачивание видео с помощью yt-dlp"""
    try:
        cmd = [
            "yt-dlp",
            "--no-playlist",
            "--format", "best[height<=720]",
            "--output", output_path,
            "--quiet",
            url
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120
        )
        
        if result.returncode == 0:
            return {"success": True, "path": output_path}
        else:
            return {"success": False, "error": result.stderr}
    
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "Download timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _extract_frame(
    video_path: str,
    timestamp: float,
    output_path: str,
    quality: int
) -> Dict[str, Any]:
    """Извлечение кадра с помощью ffmpeg"""
    try:
        # Quality mapping (1-5, 1 is best)
        crf_values = {1: 15, 2: 18, 3: 23, 4: 28, 5: 32}
        crf = crf_values.get(quality, 23)
        
        cmd = [
            "ffmpeg",
            "-y",
            "-ss", str(timestamp),
            "-i", video_path,
            "-vframes", "1",
            "-q:v", str(crf),
            "-f", "image2",
            output_path
        ]
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode == 0 and os.path.exists(output_path):
            return {"success": True, "path": output_path}
        else:
            return {"success": False, "error": result.stderr}
    
    except subprocess.TimeoutExpired:
        return {"success": False, "error": "Extraction timeout"}
    except Exception as e:
        return {"success": False, "error": str(e)}


def _upload_file_to_s3(file_path: str, s3_key: str) -> Dict[str, Any]:
    """Загрузка файла в S3"""
    s3_client = get_s3_client()
    
    if not s3_client:
        return {"success": False, "error": "S3 client not available"}
    
    try:
        extra_args = {
            "ContentType": f"image/{s3_key.split('.')[-1]}",
            "CacheControl": "max-age=31536000",  # 1 year cache
        }
        
        s3_client.upload_file(
            Filename=file_path,
            Bucket=S3_BUCKET,
            Key=s3_key,
            ExtraArgs=extra_args
        )
        
        # Generate URL
        url = s3_client.generate_presigned_url(
            "get_object",
            Params={"Bucket": S3_BUCKET, "Key": s3_key},
            ExpiresIn=3600
        )
        
        return {
            "success": True,
            "key": s3_key,
            "url": url,
            "size": os.path.getsize(file_path)
        }
    
    except ClientError as e:
        logger.error(f"S3 upload failed: {e}")
        return {"success": False, "error": str(e)}
    except Exception as e:
        logger.error(f"S3 upload error: {e}")
        return {"success": False, "error": str(e)}


def _send_webhook(url: str, data: Dict[str, Any]):
    """Отправка webhook callback"""
    import requests
    
    try:
        response = requests.post(
            url,
            json=data,
            headers={"Content-Type": "application/json"},
            timeout=30
        )
        response.raise_for_status()
        logger.info(f"Webhook sent successfully to {url}")
    except Exception as e:
        logger.error(f"Webhook failed: {e}")


# ============ MAINTENANCE TASKS ============

@celery_app.task(bind=True, base=ReelShotTask)
def cleanup_old_files(self, max_age_hours: int = 24) -> Dict[str, Any]:
    """
    Очистка старых файлов из локального хранилища
    
    Args:
        max_age_hours: Максимальный возраст файлов в часах
    """
    cleaned = 0
    total_size = 0
    cutoff_time = datetime.utcnow() - timedelta(hours=max_age_hours)
    
    try:
        if not os.path.exists(FRAMES_DIR):
            return {"cleaned": 0, "size_freed": 0}
        
        for root, dirs, files in os.walk(FRAMES_DIR):
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    stat = os.stat(file_path)
                    file_time = datetime.utcfromtimestamp(stat.st_mtime)
                    
                    if file_time < cutoff_time:
                        size = stat.st_size
                        os.remove(file_path)
                        cleaned += 1
                        total_size += size
                        
                except Exception as e:
                    logger.warning(f"Failed to remove {file_path}: {e}")
        
        logger.info(f"Cleanup completed: {cleaned} files, {total_size} bytes freed")
        return {
            "cleaned": cleaned,
            "size_freed": total_size,
            "timestamp": datetime.utcnow().isoformat()
        }
    
    except Exception as e:
        logger.error(f"Cleanup failed: {e}")
        raise self.retry(exc=e, countdown=300)


@celery_app.task(bind=True, base=ReelShotTask)
def batch_process_videos(
    self,
    video_urls: list,
    timestamps: list,
    webhook_url: Optional[str] = None
) -> Dict[str, Any]:
    """
    Пакетная обработка нескольких видео
    
    Args:
        video_urls: Список URL видео
        timestamps: Список временных меток
        webhook_url: URL для webhook
    """
    results = []
    
    for i, (url, timestamp) in enumerate(zip(video_urls, timestamps)):
        self.update_state(
            state="PROGRESS",
            meta={"current": i + 1, "total": len(video_urls), "url": url}
        )
        
        # Queue individual task
        task = process_video.delay(
            video_url=url,
            timestamp=timestamp,
            webhook_url=webhook_url
        )
        
        results.append({
            "url": url,
            "timestamp": timestamp,
            "task_id": task.id
        })
    
    return {
        "success": True,
        "batch_id": self.request.id,
        "tasks": results,
        "total": len(results)
    }
