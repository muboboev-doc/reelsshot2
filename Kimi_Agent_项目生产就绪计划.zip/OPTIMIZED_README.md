# ReelShot Backend - Optimized Version

FastAPI backend for extracting frames from video with security and performance fixes.

## 🚀 Quick Start

```bash
# Clone and setup
git clone <repository-url>
cd reelshot

# Install dependencies
make install

# Setup environment
cp .env.example .env
# Edit .env with your settings

# Run development server
make run-dev
```

## 📋 Requirements

- Python 3.11+
- FFmpeg
- Docker (optional)

## 🔧 Configuration

Create `.env` file:

```env
STORAGE_FOLDER=storage
DELETE_DELAY_MINS=30
MAX_FILE_SIZE=524288000
FRONTEND_URL=http://localhost:5173
PORT=8000
```

## 🐳 Docker Deployment

```bash
# Build and run with Docker Compose
make build
make run

# Or manually
docker-compose up -d
```

## 🧪 Testing

```bash
# Run tests
make test

# Run tests with coverage
make test-cov

# Run security scans
make security
```

## 📊 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/extract-frames` | POST | Upload and extract frames |
| `/extract-frames-url` | POST | Extract frames from URL |
| `/get-frame/{id}/{name}` | GET | Get specific frame |
| `/background-tasks` | GET | List all tasks |
| `/background-tasks/{id}` | GET | Get task status |

## 🔒 Security Features

- ✅ Path traversal protection
- ✅ Command injection prevention
- ✅ File upload validation
- ✅ Rate limiting
- ✅ CORS configuration
- ✅ UUID validation
- ✅ Filename sanitization

## ⚡ Performance Optimizations

- ✅ Async file operations
- ✅ Thread pool for CPU-bound tasks
- ✅ Frame skipping for faster processing
- ✅ Memory-efficient frame processing
- ✅ Connection pooling

## 🛠️ Development

```bash
# Format code
make format

# Run linter
make lint

# Run security scan
make security

# Full CI pipeline
make ci
```

## 📈 Monitoring

Health check: `GET /health`

Metrics: `GET /metrics` (if enabled)

## 📝 License

MIT License
