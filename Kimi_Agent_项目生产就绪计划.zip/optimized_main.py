"""
ReelShot Backend - Optimized Version
FastAPI application for extracting frames from video with security and performance fixes.
"""

import os
import re
import asyncio
import shutil
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import aiofiles
from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks, Request, Form, status
from fastapi.responses import JSONResponse, StreamingResponse, HTMLResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded

from utils.video_utils import extract_frames


# ============== Configuration ==============

class Settings(BaseSettings):
    """Application settings with validation."""
    storage_folder: str = Field(default="storage", alias="STORAGE_FOLDER")
    frontend_url: str = Field(default="http://localhost:5173", alias="FRONTEND_URL")
    port: int = Field(default=8000, alias="PORT")
    delete_delay_mins: int = Field(default=10, alias="DELETE_DELAY_MINS")
    max_file_size: int = Field(default=500 * 1024 * 1024, alias="MAX_FILE_SIZE")  # 500MB
    allowed_origins: List[str] = Field(default=["http://localhost:5173"], alias="ALLOWED_ORIGINS")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()


# ============== Constants ==============

ALLOWED_EXTENSIONS = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
UUID_PATTERN = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
FILENAME_PATTERN = re.compile(r'^frame_\d{4}\.png$')
REEL_URL_PATTERN = re.compile(
    r'^https?://(www\.)?(instagram\.com|fb\.watch|youtube\.com|youtu\.be)/.*$'
)

# Thread pool for CPU-bound operations
executor = ThreadPoolExecutor(max_workers=4)


# ============== FastAPI App ==============

app = FastAPI(
    title="ReelShot API",
    description="API for extracting frames from video files",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Rate limiter
limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
    max_age=600,
)

# Trusted host middleware
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["*"]  # Configure for production
)

# Create storage directory
os.makedirs(settings.storage_folder, exist_ok=True)


# ============== Thread-safe task storage ==============

class TaskStorage:
    """Thread-safe storage for background tasks."""
    
    def __init__(self):
        self._storage: Dict[str, Dict] = {}
        self._lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[Dict]:
        async with self._lock:
            return self._storage.get(key)
    
    async def set(self, key: str, value: Dict):
        async with self._lock:
            self._storage[key] = value
    
    async def update(self, key: str, updates: Dict):
        async with self._lock:
            if key in self._storage:
                self._storage[key].update(updates)
    
    async def delete(self, key: str):
        async with self._lock:
            if key in self._storage:
                del self._storage[key]
    
    async def get_all(self) -> Dict[str, Dict]:
        async with self._lock:
            return dict(self._storage)
    
    async def cleanup_old_tasks(self, max_age_hours: int = 24):
        """Remove tasks older than specified hours."""
        async with self._lock:
            current_time = datetime.now()
            to_delete = []
            for task_id, task in self._storage.items():
                start_time = datetime.fromisoformat(task.get("start_time", "1970-01-01"))
                if (current_time - start_time).total_seconds() > max_age_hours * 3600:
                    to_delete.append(task_id)
            for task_id in to_delete:
                del self._storage[task_id]


task_storage = TaskStorage()


# ============== Security Validators ==============

def validate_uuid(uuid_str: str) -> bool:
    """Validate UUID format."""
    return bool(UUID_PATTERN.match(uuid_str))


def validate_filename(filename: str) -> bool:
    """Validate frame filename format."""
    return bool(FILENAME_PATTERN.match(filename))


def validate_reel_url(url: str) -> bool:
    """Validate reel URL format."""
    return bool(REEL_URL_PATTERN.match(url))


def validate_file_extension(filename: str) -> bool:
    """Validate file extension."""
    ext = Path(filename).suffix.lower()
    return ext in ALLOWED_EXTENSIONS


def get_safe_path(storage_folder: str, unique_id: str, filename: str) -> Path:
    """Get safe file path preventing path traversal."""
    base_path = Path(storage_folder).resolve()
    file_path = (base_path / unique_id / filename).resolve()
    
    # Ensure the path is within storage folder
    try:
        file_path.relative_to(base_path)
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return file_path


# ============== Background Tasks ==============

async def delete_frames_after_delay(unique_id: str, delay_minutes: int):
    """Delete frames after a specified delay using asyncio."""
    await asyncio.sleep(delay_minutes * 60)
    
    frame_dir = Path(settings.storage_folder) / unique_id
    if frame_dir.exists():
        shutil.rmtree(frame_dir)
    
    await task_storage.update(unique_id, {
        "status": "completed",
        "end_time": datetime.now().isoformat()
    })


# ============== API Models ==============

class HealthResponse(BaseModel):
    status: str
    timestamp: str
    version: str


class FrameExtractionResponse(BaseModel):
    unique_id: str
    frames: Dict[str, str]
    message: str


class TaskStatusResponse(BaseModel):
    status: str
    start_time: str
    end_time: Optional[str]
    frames: List[str]


# ============== Endpoints ==============

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint for monitoring."""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now().isoformat(),
        version="2.0.0"
    )


@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "ReelShot API",
        "version": "2.0.0",
        "docs": "/docs",
        "health": "/health"
    }


@app.post(
    "/extract-frames",
    response_model=FrameExtractionResponse,
    status_code=status.HTTP_201_CREATED
)
@limiter.limit("10/minute")
async def extract_frames_api(
    request: Request,
    video_file: UploadFile = File(...),
    method: str = Form("ssim"),
    threshold: float = Form(0.8),
    background_tasks: BackgroundTasks = None,
):
    """
    Extract frames from uploaded video file.
    
    - **video_file**: Video file to process (max 500MB)
    - **method**: Frame comparison method ('ssim' or 'pixel')
    - **threshold**: Similarity threshold (0.0 to 1.0)
    """
    # Validate method
    if method not in ['ssim', 'pixel']:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid method. Use 'ssim' or 'pixel'."
        )
    
    # Validate threshold
    if not (0 <= threshold <= 1):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Threshold must be between 0 and 1."
        )
    
    # Validate file extension
    if not validate_file_extension(video_file.filename):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid file type. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"
        )
    
    unique_id = str(uuid.uuid4())
    file_ext = Path(video_file.filename).suffix.lower()
    video_path = f"temp_{unique_id}{file_ext}"
    
    try:
        # Read and validate file size
        contents = await video_file.read()
        
        if len(contents) > settings.max_file_size:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File too large. Max size: {settings.max_file_size // (1024*1024)}MB"
            )
        
        # Async file write
        async with aiofiles.open(video_path, "wb") as buffer:
            await buffer.write(contents)
        
        # Create frame directory
        frame_dir = Path(settings.storage_folder) / unique_id
        frame_dir.mkdir(parents=True, exist_ok=True)
        
        # Run CPU-intensive operation in thread pool
        loop = asyncio.get_event_loop()
        frame_names = await loop.run_in_executor(
            executor,
            extract_frames,
            str(video_path),
            method,
            threshold,
            str(frame_dir)
        )
        
        # Schedule cleanup
        if background_tasks:
            background_tasks.add_task(
                delete_frames_after_delay,
                unique_id,
                settings.delete_delay_mins
            )
        
        # Store task info
        await task_storage.set(unique_id, {
            "status": "pending",
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "frames": frame_names,
        })
        
        # Generate frame URLs
        frame_urls = {
            name: f"/get-frame/{unique_id}/{name}"
            for name in frame_names
        }
        
        return FrameExtractionResponse(
            unique_id=unique_id,
            frames=frame_urls,
            message=f"Successfully extracted {len(frame_names)} frames"
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing video: {str(e)}"
        )
    finally:
        # Guaranteed cleanup
        if os.path.exists(video_path):
            os.remove(video_path)


@app.get("/get-frame/{unique_id}/{frame_name}")
@limiter.limit("100/minute")
async def get_frame(request: Request, unique_id: str, frame_name: str):
    """
    Serve a specific frame as an image.
    
    - **unique_id**: UUID of the extraction task
    - **frame_name**: Name of the frame file
    """
    # Validate UUID format
    if not validate_uuid(unique_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid unique_id format"
        )
    
    # Validate filename format
    if not validate_filename(frame_name):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid frame_name format"
        )
    
    # Get safe path
    try:
        frame_path = get_safe_path(settings.storage_folder, unique_id, frame_name)
    except HTTPException:
        raise
    
    if not frame_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Frame not found. It may have been deleted."
        )
    
    return StreamingResponse(
        open(frame_path, "rb"),
        media_type="image/png",
        headers={
            "Cache-Control": "public, max-age=3600",
            "X-Content-Type-Options": "nosniff"
        }
    )


@app.get("/background-tasks")
@limiter.limit("30/minute")
async def list_background_tasks(request: Request):
    """List all background tasks (admin only in production)."""
    tasks = await task_storage.get_all()
    return JSONResponse(content=tasks)


@app.get("/background-tasks/{unique_id}", response_model=TaskStatusResponse)
@limiter.limit("60/minute")
async def get_background_task_status(request: Request, unique_id: str):
    """Get the status of a specific background task."""
    if not validate_uuid(unique_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid unique_id format"
        )
    
    task = await task_storage.get(unique_id)
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Background task not found."
        )
    
    return TaskStatusResponse(**task)


@app.post("/extract-frames-url")
@limiter.limit("5/minute")
async def extract_frames_url_api(
    request: Request,
    reel_url: str = Form(...),
    method: str = Form('ssim'),
    threshold: float = Form(0.8),
    background_tasks: BackgroundTasks = None,
):
    """
    Extract frames from video URL (Instagram, YouTube, etc.).
    
    - **reel_url**: URL of the video to download
    - **method**: Frame comparison method ('ssim' or 'pixel')
    - **threshold**: Similarity threshold (0.0 to 1.0)
    """
    # Validate method
    if method not in ['ssim', 'pixel']:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid method. Use 'ssim' or 'pixel'."
        )
    
    # Validate threshold
    if not (0 <= threshold <= 1):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Threshold must be between 0 and 1."
        )
    
    # Validate URL
    if not validate_reel_url(reel_url):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid URL. Only Instagram, YouTube, and Facebook URLs are allowed."
        )
    
    unique_id = str(uuid.uuid4())
    video_path = f"temp_{unique_id}.mp4"
    
    try:
        # Async subprocess for downloading
        command = [
            "yt-dlp",
            "-f", "best[ext=mp4]/best",
            "--output", video_path,
            "--max-filesize", str(settings.max_file_size),
            "--",  # Separator to prevent injection
            reel_url
        ]
        
        proc = await asyncio.create_subprocess_exec(
            *command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=300  # 5 minute timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail="Download timed out."
            )
        
        if proc.returncode != 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Unable to download video. Check URL and try again."
            )
        
        # Create frame directory
        frame_dir = Path(settings.storage_folder) / unique_id
        frame_dir.mkdir(parents=True, exist_ok=True)
        
        # Extract frames
        loop = asyncio.get_event_loop()
        frame_names = await loop.run_in_executor(
            executor,
            extract_frames,
            video_path,
            method,
            threshold,
            str(frame_dir)
        )
        
        # Schedule cleanup
        if background_tasks:
            background_tasks.add_task(
                delete_frames_after_delay,
                unique_id,
                settings.delete_delay_mins
            )
        
        # Store task info
        await task_storage.set(unique_id, {
            "status": "pending",
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "frames": frame_names,
        })
        
        # Generate frame URLs
        frame_urls = {
            name: f"/get-frame/{unique_id}/{name}"
            for name in frame_names
        }
        
        return FrameExtractionResponse(
            unique_id=unique_id,
            frames=frame_urls,
            message=f"Successfully extracted {len(frame_names)} frames"
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing video: {str(e)}"
        )
    finally:
        # Guaranteed cleanup
        if os.path.exists(video_path):
            os.remove(video_path)


# ============== Error Handlers ==============

@app.exception_handler(404)
async def not_found_exception_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"detail": "Resource not found."}
    )


@app.exception_handler(500)
async def internal_server_error_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Please try again later."}
    )


# ============== Startup/Shutdown Events ==============

@app.on_event("startup")
async def startup_event():
    """Initialize on startup."""
    # Create storage directory
    os.makedirs(settings.storage_folder, exist_ok=True)
    print(f"🚀 ReelShot API started on port {settings.port}")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    executor.shutdown(wait=True)
    print("👋 ReelShot API shutdown complete")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.port,
        reload=False,
        workers=4
    )
