"""
Video processing utilities with performance optimizations.
"""

import os
import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim
from typing import List, Optional


def encode_frame(frame: np.ndarray) -> bytes:
    """Encode frame as PNG bytes."""
    _, buffer = cv2.imencode('.png', frame)
    return buffer.tobytes()


def extract_frames(
    video_path: str,
    method: str,
    threshold: float,
    frame_dir: str,
    skip_frames: int = 2,
    resize_for_comparison: tuple = (320, 240)
) -> List[str]:
    """
    Extract frames from video based on similarity threshold.
    
    Args:
        video_path: Path to the video file
        method: Comparison method ('ssim' or 'pixel')
        threshold: Similarity threshold (0.0 to 1.0)
        frame_dir: Directory to save extracted frames
        skip_frames: Number of frames to skip between comparisons (default: 2)
        resize_for_comparison: Resize frames for faster comparison (default: 320x240)
    
    Returns:
        List of saved frame filenames
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {video_path}")
    
    frame_names: List[str] = []
    prev_frame: Optional[np.ndarray] = None
    frame_count = 0
    saved_count = 0
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # Skip frames for performance
            if frame_count % (skip_frames + 1) != 0:
                frame_count += 1
                continue
            
            # Resize for faster comparison
            if resize_for_comparison:
                small_frame = cv2.resize(frame, resize_for_comparison)
            else:
                small_frame = frame
            
            gray_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2GRAY)
            
            if prev_frame is not None:
                should_save = False
                
                if method == 'ssim':
                    # SSIM comparison
                    score, _ = ssim(prev_frame, gray_frame, full=True)
                    should_save = score < threshold
                
                elif method == 'pixel':
                    # Pixel difference comparison
                    diff = cv2.absdiff(prev_frame, gray_frame)
                    diff_percent = np.count_nonzero(diff) / diff.size
                    should_save = diff_percent > threshold
                
                if should_save:
                    frame_name = f'frame_{saved_count:04d}.png'
                    frame_path = os.path.join(frame_dir, frame_name)
                    
                    # Save original frame (not resized)
                    success = cv2.imwrite(frame_path, frame)
                    if success:
                        frame_names.append(frame_name)
                        saved_count += 1
            
            prev_frame = gray_frame
            frame_count += 1
    
    finally:
        # Always release the capture
        cap.release()
    
    return frame_names


def save_frame(frame: np.ndarray, frame_name: str, frame_dir: str) -> bool:
    """
    Save frame to disk under the specified directory.
    
    Args:
        frame: Frame to save
        frame_name: Name of the file
        frame_dir: Directory to save to
    
    Returns:
        True if successful, False otherwise
    """
    os.makedirs(frame_dir, exist_ok=True)
    frame_path = os.path.join(frame_dir, frame_name)
    return cv2.imwrite(frame_path, frame)


def get_video_info(video_path: str) -> dict:
    """
    Get video file information.
    
    Args:
        video_path: Path to the video file
    
    Returns:
        Dictionary with video information
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"Cannot open video: {video_path}")
    
    try:
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        duration = frame_count / fps if fps > 0 else 0
        
        return {
            "fps": fps,
            "frame_count": frame_count,
            "width": width,
            "height": height,
            "duration_seconds": duration,
            "duration_formatted": f"{int(duration // 60)}:{int(duration % 60):02d}"
        }
    finally:
        cap.release()


def extract_frame_at_timestamp(
    video_path: str,
    timestamp_seconds: float,
    output_path: str
) -> bool:
    """
    Extract a single frame at a specific timestamp.
    
    Args:
        video_path: Path to the video file
        timestamp_seconds: Timestamp in seconds
        output_path: Path to save the frame
    
    Returns:
        True if successful, False otherwise
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return False
    
    try:
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_number = int(timestamp_seconds * fps)
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_number)
        
        ret, frame = cap.read()
        if ret:
            return cv2.imwrite(output_path, frame)
        return False
    finally:
        cap.release()
