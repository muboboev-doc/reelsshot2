#!/bin/bash
# Test script for Docker build and basic functionality

set -e

echo "==================================="
echo "Docker Build and Test Script"
echo "==================================="

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Test 1: Build Docker image
echo ""
echo "📦 Test 1: Building Docker image..."
if docker build -t reelshot:phase1 .; then
    echo -e "${GREEN}✅ Docker build successful${NC}"
else
    echo -e "${RED}❌ Docker build failed${NC}"
    exit 1
fi

# Test 2: Check image size
echo ""
echo "📊 Test 2: Checking image size..."
IMAGE_SIZE=$(docker images reelshot:phase1 --format "{{.Size}}")
echo "Image size: $IMAGE_SIZE"

# Test 3: Run container and test health endpoint
echo ""
echo "🚀 Test 3: Starting container..."
docker run -d --name reelshot-test -p 8000:8000 reelshot:phase1

# Wait for container to start
echo "Waiting for container to start..."
sleep 5

# Test 4: Health check
echo ""
echo "🏥 Test 4: Testing health endpoint..."
if curl -f http://localhost:8000/health; then
    echo -e "${GREEN}✅ Health check passed${NC}"
else
    echo -e "${RED}❌ Health check failed${NC}"
    docker logs reelshot-test
    docker stop reelshot-test
    docker rm reelshot-test
    exit 1
fi

# Test 5: Check security headers
echo ""
echo "🔒 Test 5: Checking security headers..."
HEADERS=$(curl -I -s http://localhost:8000/health)
if echo "$HEADERS" | grep -q "X-Content-Type-Options"; then
    echo -e "${GREEN}✅ Security headers present${NC}"
else
    echo -e "${RED}❌ Security headers missing${NC}"
fi

# Cleanup
echo ""
echo "🧹 Cleaning up..."
docker stop reelshot-test
docker rm reelshot-test

echo ""
echo "==================================="
echo -e "${GREEN}🎉 All Docker tests passed!${NC}"
echo "==================================="
