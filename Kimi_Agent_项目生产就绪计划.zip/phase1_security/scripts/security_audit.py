#!/usr/bin/env python3
"""
Security Audit Script for ReelShot Backend
Runs bandit, safety, and custom security checks
"""

import subprocess
import sys
import os
from pathlib import Path


def run_command(cmd: list, description: str) -> tuple:
    """Run a command and return success status and output."""
    print(f"\n{'='*60}")
    print(f"🔍 {description}")
    print('='*60)
    
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300
        )
        
        if result.stdout:
            print(result.stdout)
        
        if result.stderr:
            print(result.stderr, file=sys.stderr)
        
        success = result.returncode == 0
        return success, result.stdout + result.stderr
        
    except subprocess.TimeoutExpired:
        print(f"❌ Timeout after 300 seconds")
        return False, ""
    except FileNotFoundError:
        print(f"⚠️  Command not found: {cmd[0]}")
        return None, ""


def check_hardcoded_secrets():
    """Check for hardcoded secrets in code."""
    print(f"\n{'='*60}")
    print("🔍 Checking for hardcoded secrets")
    print('='*60)
    
    secret_patterns = [
        r'password\s*=\s*["\'][^"\']+["\']',
        r'secret\s*=\s*["\'][^"\']+["\']',
        r'api_key\s*=\s*["\'][^"\']+["\']',
        r'token\s*=\s*["\'][^"\']+["\']',
        r'AWS_ACCESS_KEY_ID\s*=\s*["\'][^"\']+["\']',
        r'AWS_SECRET_ACCESS_KEY\s*=\s*["\'][^"\']+["\']',
        r'PRIVATE_KEY\s*=\s*["\'][^"\']+["\']',
    ]
    
    import re
    
    found_secrets = []
    exclude_dirs = {'__pycache__', '.git', 'venv', 'env', '.venv'}
    
    for root, dirs, files in os.walk('.'):
        # Skip excluded directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if file.endswith('.py'):
                filepath = Path(root) / file
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()
                        
                    for pattern in secret_patterns:
                        matches = re.finditer(pattern, content, re.IGNORECASE)
                        for match in matches:
                            # Skip if it's in a config/example file
                            if 'example' in file.lower() or 'test' in file.lower():
                                continue
                            # Skip if it's a placeholder
                            if 'your-' in match.group() or 'change-' in match.group():
                                continue
                            found_secrets.append({
                                'file': str(filepath),
                                'line': content[:match.start()].count('\n') + 1,
                                'match': match.group()[:50] + '...' if len(match.group()) > 50 else match.group()
                            })
                except Exception as e:
                    print(f"⚠️  Could not read {filepath}: {e}")
    
    if found_secrets:
        print("⚠️  Potential hardcoded secrets found:")
        for secret in found_secrets:
            print(f"  - {secret['file']}:{secret['line']}: {secret['match']}")
        return False
    else:
        print("✅ No hardcoded secrets found")
        return True


def check_file_permissions():
    """Check for overly permissive file permissions."""
    print(f"\n{'='*60}")
    print("🔍 Checking file permissions")
    print('='*60)
    
    issues = []
    
    # Check for .env files
    for env_file in Path('.').glob('**/.env*'):
        if env_file.is_file():
            stat = env_file.stat()
            mode = oct(stat.st_mode)[-3:]
            if mode != '600':
                issues.append(f"{env_file} has permissions {mode}, should be 600")
    
    # Check for key files
    for key_file in Path('.').glob('**/*.key'):
        if key_file.is_file():
            stat = key_file.stat()
            mode = oct(stat.st_mode)[-3:]
            if mode != '600':
                issues.append(f"{key_file} has permissions {mode}, should be 600")
    
    if issues:
        print("⚠️  File permission issues found:")
        for issue in issues:
            print(f"  - {issue}")
        return False
    else:
        print("✅ File permissions are correct")
        return True


def check_dependencies():
    """Check dependencies for known vulnerabilities."""
    print(f"\n{'='*60}")
    print("🔍 Checking dependencies")
    print('='*60)
    
    # Check if safety is installed
    result = subprocess.run(['pip', 'show', 'safety'], capture_output=True, text=True)
    if result.returncode != 0:
        print("⚠️  safety not installed. Installing...")
        subprocess.run(['pip', 'install', 'safety'], check=True)
    
    success, output = run_command(
        ['safety', 'check', '--full-report'],
        "Safety vulnerability check"
    )
    
    return success if success is not None else True


def run_bandit():
    """Run bandit security scanner."""
    print(f"\n{'='*60}")
    print("🔍 Running Bandit security scanner")
    print('='*60)
    
    # Check if bandit is installed
    result = subprocess.run(['pip', 'show', 'bandit'], capture_output=True, text=True)
    if result.returncode != 0:
        print("⚠️  bandit not installed. Installing...")
        subprocess.run(['pip', 'install', 'bandit'], check=True)
    
    success, output = run_command(
        ['bandit', '-r', '.', '-f', 'screen', '-ll'],
        "Bandit SAST scan"
    )
    
    # Bandit returns exit code 1 if issues found
    if success is False and 'No issues identified' not in output:
        return False
    return True


def check_docker_security():
    """Check Docker security best practices."""
    print(f"\n{'='*60}")
    print("🔍 Checking Docker security")
    print('='*60)
    
    dockerfile = Path('Dockerfile')
    if not dockerfile.exists():
        print("⚠️  Dockerfile not found")
        return True
    
    with open(dockerfile, 'r') as f:
        content = f.read()
    
    issues = []
    
    # Check for non-root user
    if 'USER' not in content:
        issues.append("Dockerfile should use non-root USER")
    
    # Check for health check
    if 'HEALTHCHECK' not in content:
        issues.append("Dockerfile should include HEALTHCHECK")
    
    # Check for .dockerignore
    if not Path('.dockerignore').exists():
        issues.append(".dockerignore should exist")
    
    if issues:
        print("⚠️  Docker security issues found:")
        for issue in issues:
            print(f"  - {issue}")
        return False
    else:
        print("✅ Docker security looks good")
        return True


def main():
    """Run all security checks."""
    print("="*60)
    print("🔒 REELSHOT BACKEND SECURITY AUDIT")
    print("="*60)
    
    results = {
        'Bandit SAST': run_bandit(),
        'Dependency Check': check_dependencies(),
        'Hardcoded Secrets': check_hardcoded_secrets(),
        'File Permissions': check_file_permissions(),
        'Docker Security': check_docker_security(),
    }
    
    # Summary
    print(f"\n{'='*60}")
    print("📊 SECURITY AUDIT SUMMARY")
    print('='*60)
    
    all_passed = True
    for check, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status}: {check}")
        if not passed:
            all_passed = False
    
    print('='*60)
    
    if all_passed:
        print("🎉 All security checks passed!")
        return 0
    else:
        print("⚠️  Some security checks failed. Please review and fix issues.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
