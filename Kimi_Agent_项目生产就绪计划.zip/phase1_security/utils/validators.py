"""
Validation utilities for ReelShot Backend.
Fixes Command Injection and Path Traversal vulnerabilities.
"""

import re
from urllib.parse import urlparse
from pathlib import Path


# ============== URL Validation for Command Injection Fix ==============

# Разрешенные домены для скачивания видео
ALLOWED_DOMAINS = {
    'instagram.com',
    'www.instagram.com',
    'youtube.com',
    'www.youtube.com',
    'youtu.be',
    'fb.watch',
    'facebook.com',
    'www.facebook.com',
    'tiktok.com',
    'www.tiktok.com',
}

# Regex для валидации URL
REEL_URL_PATTERN = re.compile(
    r'^https?://'  # http:// или https://
    r'(?:www\.)?'  # опционально www.
    r'(?:instagram\.com/reel/[^/]+/?|'  # Instagram reels
    r'(?:youtube\.com/(?:watch\?v=|shorts/)|youtu\.be/)[^&/?]+/?|'  # YouTube
    r'(?:facebook\.com/(?:reel/|watch/)|fb\.watch/)[^/]+/?|'  # Facebook
    r'tiktok\.com/@[^/]+/video/\d+/?)'  # TikTok
    r'$',
    re.IGNORECASE
)


def validate_reel_url(url: str) -> bool:
    """
    Валидация URL для предотвращения Command Injection.
    
    Args:
        url: URL для проверки
        
    Returns:
        bool: True если URL валиден и безопасен
        
    Examples:
        >>> validate_reel_url("https://www.instagram.com/reel/ABC123/")
        True
        >>> validate_reel_url("https://malicious.com; rm -rf /")
        False
    """
    if not url or len(url) > 500:
        return False
    
    # Проверка на shell injection
    dangerous_chars = [';', '&', '|', '`', '$', '(', ')', '{', '}', '<', '>', '\n', '\r']
    if any(char in url for char in dangerous_chars):
        return False
    
    # Проверка паттерна
    if not REEL_URL_PATTERN.match(url):
        return False
    
    # Проверка домена
    try:
        parsed = urlparse(url)
        domain = parsed.netloc.lower()
        
        # Убираем порт если есть
        if ':' in domain:
            domain = domain.split(':')[0]
        
        if domain not in ALLOWED_DOMAINS:
            return False
        
        # Дополнительная проверка: URL не должен содержать двойные точки
        if '..' in parsed.path:
            return False
        
    except Exception:
        return False
    
    return True


# ============== UUID Validation for Path Traversal Fix ==============

# Regex для UUID v4
UUID_PATTERN = re.compile(
    r'^[0-9a-f]{8}-'  # 8 hex chars
    r'[0-9a-f]{4}-'   # 4 hex chars
    r'4[0-9a-f]{3}-'  # версия 4
    r'[89ab][0-9a-f]{3}-'  # variant
    r'[0-9a-f]{12}$',  # 12 hex chars
    re.IGNORECASE
)


def validate_uuid(uuid_str: str) -> bool:
    """
    Валидация UUID v4 формата.
    
    Args:
        uuid_str: Строка для проверки
        
    Returns:
        bool: True если валидный UUID
        
    Examples:
        >>> validate_uuid("550e8400-e29b-41d4-a716-446655440000")
        True
        >>> validate_uuid("../../../etc/passwd")
        False
    """
    if not uuid_str or len(uuid_str) != 36:
        return False
    
    return bool(UUID_PATTERN.match(uuid_str))


# ============== Filename Validation for Path Traversal Fix ==============

# Regex для имени файла кадра (frame_0000.png - frame_9999.png)
FILENAME_PATTERN = re.compile(
    r'^frame_'  # префикс
    r'\d{4}'    # 4 цифры
    r'\.png$'   # расширение
)


def validate_filename(filename: str) -> bool:
    """
    Валидация имени файла кадра.
    
    Args:
        filename: Имя файла для проверки
        
    Returns:
        bool: True если имя файла безопасно
        
    Examples:
        >>> validate_filename("frame_0000.png")
        True
        >>> validate_filename("../../../etc/passwd")
        False
    """
    if not filename or len(filename) > 20:
        return False
    
    # Проверка на path traversal
    if '..' in filename or '/' in filename or '\\' in filename:
        return False
    
    return bool(FILENAME_PATTERN.match(filename))


# ============== File Extension Validation ==============

# Разрешенные расширения для видео
ALLOWED_EXTENSIONS = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}


def validate_file_extension(filename: str) -> bool:
    """
    Валидация расширения файла.
    
    Args:
        filename: Имя файла для проверки
        
    Returns:
        bool: True если расширение разрешено
    """
    if not filename:
        return False
    
    ext = Path(filename).suffix.lower()
    return ext in ALLOWED_EXTENSIONS


# ============== Safe Path Construction ==============

def get_safe_path(storage_folder: str, unique_id: str, filename: str) -> Path:
    """
    Безопасное построение пути с защитой от path traversal.
    
    Args:
        storage_folder: Базовая директория хранения
        unique_id: UUID задачи
        filename: Имя файла
        
    Returns:
        Path: Безопасный путь к файлу
        
    Raises:
        ValueError: Если путь небезопасен
        
    Examples:
        >>> get_safe_path("/storage", "550e8400-e29b-41d4-a716-446655440000", "frame_0000.png")
        Path("/storage/550e8400-e29b-41d4-a716-446655440000/frame_0000.png")
    """
    # Валидация входных данных
    if not validate_uuid(unique_id):
        raise ValueError(f"Invalid UUID format: {unique_id}")
    
    if not validate_filename(filename):
        raise ValueError(f"Invalid filename format: {filename}")
    
    # Построение пути
    base_path = Path(storage_folder).resolve()
    file_path = (base_path / unique_id / filename).resolve()
    
    # Критически важная проверка: путь должен быть внутри base_path
    try:
        file_path.relative_to(base_path)
    except ValueError:
        raise ValueError(f"Path traversal detected: {file_path}")
    
    return file_path


# ============== Additional Security Validations ==============

def sanitize_input(input_str: str, max_length: int = 100) -> str:
    """
    Базовая санитизация строки.
    
    Args:
        input_str: Входная строка
        max_length: Максимальная длина
        
    Returns:
        str: Санитизированная строка
    """
    if not input_str:
        return ""
    
    # Обрезка
    input_str = input_str[:max_length]
    
    # Удаление опасных символов
    dangerous = ['<', '>', '"', "'", ';', '&', '|', '`', '$']
    for char in dangerous:
        input_str = input_str.replace(char, '')
    
    return input_str.strip()


def validate_method(method: str) -> bool:
    """
    Валидация метода извлечения кадров.
    
    Args:
        method: Метод ('ssim' или 'pixel')
        
    Returns:
        bool: True если метод валиден
    """
    return method in ('ssim', 'pixel')


def validate_threshold(threshold: float) -> bool:
    """
    Валидация порога схожести.
    
    Args:
        threshold: Значение порога
        
    Returns:
        bool: True если порог в диапазоне [0, 1]
    """
    return 0 <= threshold <= 1


# ============== Test Functions ==============

def run_tests():
    """Запуск тестов валидации."""
    print("Testing validators...")
    
    # Test URL validation
    assert validate_reel_url("https://www.instagram.com/reel/ABC123/") == True
    assert validate_reel_url("https://www.youtube.com/watch?v=ABC123") == True
    assert validate_reel_url("https://youtu.be/ABC123") == True
    assert validate_reel_url("https://malicious.com; rm -rf /") == False
    assert validate_reel_url("../../../etc/passwd") == False
    print("✅ URL validation tests passed")
    
    # Test UUID validation
    assert validate_uuid("550e8400-e29b-41d4-a716-446655440000") == True
    assert validate_uuid("not-a-uuid") == False
    assert validate_uuid("../../../etc/passwd") == False
    print("✅ UUID validation tests passed")
    
    # Test filename validation
    assert validate_filename("frame_0000.png") == True
    assert validate_filename("frame_9999.png") == True
    assert validate_filename("../../../etc/passwd") == False
    assert validate_filename("malicious.exe") == False
    print("✅ Filename validation tests passed")
    
    # Test file extension validation
    assert validate_file_extension("video.mp4") == True
    assert validate_file_extension("video.avi") == True
    assert validate_file_extension("video.exe") == False
    print("✅ File extension validation tests passed")
    
    # Test safe path construction
    try:
        get_safe_path("/storage", "550e8400-e29b-41d4-a716-446655440000", "frame_0000.png")
        print("✅ Safe path construction tests passed")
    except ValueError as e:
        print(f"❌ Safe path test failed: {e}")
    
    try:
        get_safe_path("/storage", "invalid-uuid", "frame_0000.png")
        print("❌ Should have raised ValueError for invalid UUID")
    except ValueError:
        print("✅ Correctly rejected invalid UUID")
    
    print("\n🎉 All validation tests passed!")


if __name__ == "__main__":
    run_tests()
