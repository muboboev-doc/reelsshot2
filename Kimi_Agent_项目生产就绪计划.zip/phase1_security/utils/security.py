"""
Security utilities for ReelShot Backend.
"""

import asyncio
import re
from pathlib import Path
from typing import Optional


class SecurityError(Exception):
    """Базовый класс для security ошибок."""
    pass


class ValidationError(SecurityError):
    """Ошибка валидации входных данных."""
    pass


class RateLimitExceeded(SecurityError):
    """Превышен лимит запросов."""
    pass


# ============== Command Injection Prevention ==============

def sanitize_for_shell(value: str) -> str:
    """
    Санитизация строки для безопасного использования в shell.
    
    Args:
        value: Входная строка
        
    Returns:
        str: Санитизированная строка
        
    Raises:
        ValidationError: Если строка содержит опасные символы
    """
    if not value:
        raise ValidationError("Empty value")
    
    # Проверка на опасные символы
    dangerous_pattern = re.compile(r'[;|&`$(){}[\]\\<>!]')
    
    if dangerous_pattern.search(value):
        raise ValidationError(f"Value contains dangerous characters: {value}")
    
    return value


def build_safe_command(base_command: list, url: str, output_path: str) -> list:
    """
    Построение безопасной команды для subprocess.
    
    Args:
        base_command: Базовая команда (['yt-dlp', '-f', 'mp4'])
        url: URL для скачивания
        output_path: Путь для сохранения
        
    Returns:
        list: Безопасная команда со всеми аргументами
        
    Raises:
        ValidationError: Если URL небезопасен
    """
    from .validators import validate_reel_url
    
    # Валидация URL
    if not validate_reel_url(url):
        raise ValidationError(f"Invalid or dangerous URL: {url}")
    
    # Построение команды с разделителем --
    command = base_command + [
        "--output", output_path,
        "--",  # Всё после -- считается positional argument
        url
    ]
    
    return command


# ============== Async Subprocess with Timeout ==============

async def run_subprocess_with_timeout(
    command: list,
    timeout: int = 300,
    cwd: Optional[str] = None
) -> tuple:
    """
    Безопасный запуск subprocess с таймаутом.
    
    Args:
        command: Команда со всеми аргументами
        timeout: Таймаут в секундах
        cwd: Рабочая директория
        
    Returns:
        tuple: (stdout, stderr)
        
    Raises:
        ValidationError: Если команда небезопасна
        asyncio.TimeoutError: Если превышен таймаут
        subprocess.CalledProcessError: Если команда завершилась с ошибкой
    """
    # Проверка что команда - это список (не строка!)
    if not isinstance(command, list):
        raise ValidationError("Command must be a list, not string")
    
    # Проверка на пустые аргументы
    if not command or not all(command):
        raise ValidationError("Command contains empty arguments")
    
    try:
        proc = await asyncio.create_subprocess_exec(
            *command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=cwd
        )
        
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise asyncio.TimeoutError(f"Command timed out after {timeout} seconds")
        
        if proc.returncode != 0:
            error_msg = stderr.decode().strip() if stderr else "Unknown error"
            raise subprocess.CalledProcessError(
                proc.returncode,
                command[0],
                output=stdout,
                stderr=stderr
            )
        
        return stdout, stderr
    
    except FileNotFoundError:
        raise ValidationError(f"Command not found: {command[0]}")


# ============== File Security ==============

def secure_filename(filename: str) -> str:
    """
    Преобразование имени файла в безопасное.
    
    Args:
        filename: Исходное имя файла
        
    Returns:
        str: Безопасное имя файла
    """
    if not filename:
        return "unnamed"
    
    # Удаление пути
    filename = Path(filename).name
    
    # Удаление опасных символов
    filename = re.sub(r'[^a-zA-Z0-9._-]', '', filename)
    
    # Ограничение длины
    if len(filename) > 100:
        name, ext = Path(filename).stem, Path(filename).suffix
        filename = name[:95] + ext
    
    return filename


def get_secure_temp_filename(original_filename: str, unique_id: str) -> str:
    """
    Генерация безопасного временного имени файла.
    
    Args:
        original_filename: Оригинальное имя файла
        unique_id: UUID для уникальности
        
    Returns:
        str: Безопасное имя файла
    """
    from .validators import validate_file_extension
    
    # Получение расширения
    ext = Path(original_filename).suffix.lower()
    
    # Проверка расширения
    if not validate_file_extension(original_filename):
        raise ValidationError(f"Invalid file extension: {ext}")
    
    return f"temp_{unique_id}{ext}"


# ============== Input Sanitization ==============

def sanitize_string(
    value: str,
    max_length: int = 100,
    allow_newlines: bool = False
) -> str:
    """
    Базовая санитизация строки.
    
    Args:
        value: Входная строка
        max_length: Максимальная длина
        allow_newlines: Разрешить ли переносы строк
        
    Returns:
        str: Санитизированная строка
    """
    if not value:
        return ""
    
    # Обрезка
    value = value[:max_length]
    
    # Удаление управляющих символов
    if not allow_newlines:
        value = value.replace('\n', ' ').replace('\r', ' ')
    
    # Удаление опасных символов
    dangerous = ['<', '>', '"', "'", ';', '&', '|', '`', '$', '{', '}', '(', ')']
    for char in dangerous:
        value = value.replace(char, '')
    
    return value.strip()


def sanitize_method(method: str) -> str:
    """
    Санитизация метода извлечения кадров.
    
    Args:
        method: Входной метод
        
    Returns:
        str: Санитизированный метод ('ssim' или 'pixel')
        
    Raises:
        ValidationError: Если метод невалиден
    """
    method = sanitize_string(method, max_length=10).lower()
    
    if method not in ('ssim', 'pixel'):
        raise ValidationError(f"Invalid method: {method}")
    
    return method


def sanitize_threshold(threshold: float) -> float:
    """
    Санитизация порога схожести.
    
    Args:
        threshold: Входное значение
        
    Returns:
        float: Санитизированное значение [0, 1]
        
    Raises:
        ValidationError: Если значение вне диапазона
    """
    try:
        threshold = float(threshold)
    except (TypeError, ValueError):
        raise ValidationError(f"Invalid threshold: {threshold}")
    
    if not 0 <= threshold <= 1:
        raise ValidationError(f"Threshold must be between 0 and 1: {threshold}")
    
    return threshold


# ============== Rate Limiting (Simple In-Memory) ==============

import time
from collections import defaultdict


class SimpleRateLimiter:
    """Простой in-memory rate limiter."""
    
    def __init__(self, max_requests: int = 10, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests = defaultdict(list)
    
    def is_allowed(self, key: str) -> bool:
        """
        Проверка разрешения запроса.
        
        Args:
            key: Идентификатор (IP, user_id, etc.)
            
        Returns:
            bool: True если запрос разрешен
        """
        now = time.time()
        window_start = now - self.window_seconds
        
        # Очистка старых запросов
        self.requests[key] = [
            req_time for req_time in self.requests[key]
            if req_time > window_start
        ]
        
        # Проверка лимита
        if len(self.requests[key]) >= self.max_requests:
            return False
        
        # Запись запроса
        self.requests[key].append(now)
        return True
    
    def get_remaining(self, key: str) -> int:
        """Получение оставшегося лимита."""
        now = time.time()
        window_start = now - self.window_seconds
        
        recent_requests = [
            req_time for req_time in self.requests[key]
            if req_time > window_start
        ]
        
        return max(0, self.max_requests - len(recent_requests))


# ============== Security Headers ==============

SECURITY_HEADERS = {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Content-Security-Policy': (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; "
        "font-src 'self'; "
        "connect-src 'self'; "
        "media-src 'self' blob:; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self';"
    ),
}


def get_security_headers() -> dict:
    """Получение security headers."""
    return SECURITY_HEADERS.copy()


def get_hsts_header(max_age: int = 31536000, include_subdomains: bool = True, preload: bool = True) -> dict:
    """
    Получение HSTS (HTTP Strict Transport Security) header.
    
    Args:
        max_age: Время в секундах (по умолчанию 1 год)
        include_subdomains: Включать ли subdomains
        preload: Разрешить preload в браузеры
        
    Returns:
        dict: HSTS header
    """
    value = f"max-age={max_age}"
    if include_subdomains:
        value += "; includeSubDomains"
    if preload:
        value += "; preload"
    
    return {'Strict-Transport-Security': value}


def get_comprehensive_security_headers(use_hsts: bool = False) -> dict:
    """
    Получение всех security headers.
    
    Args:
        use_hsts: Добавить HSTS header (только для HTTPS!)
        
    Returns:
        dict: Все security headers
    """
    headers = get_security_headers()
    
    if use_hsts:
        headers.update(get_hsts_header())
    
    # Additional headers
    headers['Permissions-Policy'] = (
        "accelerometer=(), "
        "camera=(), "
        "geolocation=(), "
        "gyroscope=(), "
        "magnetometer=(), "
        "microphone=(), "
        "payment=(), "
        "usb=()"
    )
    
    return headers


# ============== Test Functions ==============

def run_security_tests():
    """Запуск security тестов."""
    print("Running security tests...")
    
    # Test shell sanitization
    try:
        sanitize_for_shell("safe-string")
        print("✅ Safe string passed")
    except ValidationError:
        print("❌ Safe string should not raise error")
    
    try:
        sanitize_for_shell("; rm -rf /")
        print("❌ Should have raised ValidationError")
    except ValidationError:
        print("✅ Correctly rejected dangerous string")
    
    # Test filename sanitization
    assert secure_filename("../../../etc/passwd") == "passwd"
    assert secure_filename("video.mp4") == "video.mp4"
    print("✅ Filename sanitization tests passed")
    
    # Test rate limiter
    limiter = SimpleRateLimiter(max_requests=2, window_seconds=60)
    assert limiter.is_allowed("user1") == True
    assert limiter.is_allowed("user1") == True
    assert limiter.is_allowed("user1") == False
    print("✅ Rate limiter tests passed")
    
    print("\n🎉 All security tests passed!")


if __name__ == "__main__":
    run_security_tests()
