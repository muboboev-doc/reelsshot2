"""
ReelShot Backend - Phase 1 Security Fixes
Fixed: Command Injection, Path Traversal, Arbitrary File Write
"""

import os
import asyncio
import shutil
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import aiofiles
from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks, Request, Form, status
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings

# Import security utilities
from utils.validators import (
    validate_reel_url,
    validate_uuid,
    validate_filename,
    validate_file_extension,
    validate_method,
    validate_threshold,
    get_safe_path,
)
from utils.security import (
    ValidationError,
    build_safe_command,
    run_subprocess_with_timeout,
    get_secure_temp_filename,
    SimpleRateLimiter,
    get_security_headers,
)
from utils.video_utils import extract_frames


# ============== Configuration ==============

class Settings(BaseSettings):
    """Application settings with validation."""
    storage_folder: str = Field(default="storage", alias="STORAGE_FOLDER")
    frontend_url: str = Field(default="http://localhost:5173", alias="FRONTEND_URL")
    port: int = Field(default=8000, alias="PORT")
    delete_delay_mins: int = Field(default=10, alias="DELETE_DELAY_MINS")
    max_file_size: int = Field(default=500 * 1024 * 1024, alias="MAX_FILE_SIZE")  # 500MB
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()


# ============== Constants ==============

# Thread pool for CPU-bound operations
executor = ThreadPoolExecutor(max_workers=4)

# Rate limiters
upload_limiter = SimpleRateLimiter(max_requests=5, window_seconds=60)
url_limiter = SimpleRateLimiter(max_requests=3, window_seconds=60)
frame_limiter = SimpleRateLimiter(max_requests=60, window_seconds=60)


# ============== FastAPI App ==============

app = FastAPI(
    title="ReelShot API",
    description="API for extracting frames from video files - Security Hardened",
    version="1.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Security Headers Middleware
@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    """Add security headers to all responses."""
    response = await call_next(request)
    
    # Prevent MIME type sniffing
    response.headers["X-Content-Type-Options"] = "nosniff"
    
    # Prevent clickjacking
    response.headers["X-Frame-Options"] = "DENY"
    
    # XSS Protection
    response.headers["X-XSS-Protection"] = "1; mode=block"
    
    # Referrer Policy
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    
    # Content Security Policy (CSP)
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; "
        "font-src 'self'; "
        "connect-src 'self'; "
        "media-src 'self' blob:; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self';"
    )
    
    # Permissions Policy (formerly Feature Policy)
    response.headers["Permissions-Policy"] = (
        "accelerometer=(), "
        "camera=(), "
        "geolocation=(), "
        "gyroscope=(), "
        "magnetometer=(), "
        "microphone=(), "
        "payment=(), "
        "usb=()"
    )
    
    # Remove server identification
    response.headers.pop("Server", None)
    
    return response


# CORS middleware - restrictive
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_url],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
    max_age=600,
)

# Create storage directory
os.makedirs(settings.storage_folder, exist_ok=True)


# ============== Thread-safe task storage ==============

class TaskStorage:
    """Thread-safe storage for background tasks."""
    
    def __init__(self):
        self._storage: Dict[str, Dict] = {}
        self._lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[Dict]:
        async with self._lock:
            return self._storage.get(key)
    
    async def set(self, key: str, value: Dict):
        async with self._lock:
            self._storage[key] = value
    
    async def update(self, key: str, updates: Dict):
        async with self._lock:
            if key in self._storage:
                self._storage[key].update(updates)


task_storage = TaskStorage()


# ============== Background Tasks ==============

async def delete_frames_after_delay(unique_id: str, delay_minutes: int):
    """Delete frames after a specified delay using asyncio."""
    await asyncio.sleep(delay_minutes * 60)
    
    # Валидация UUID перед удалением
    if not validate_uuid(unique_id):
        print(f"Invalid UUID in cleanup: {unique_id}")
        return
    
    frame_dir = Path(settings.storage_folder) / unique_id
    if frame_dir.exists():
        shutil.rmtree(frame_dir)
    
    await task_storage.update(unique_id, {
        "status": "completed",
        "end_time": datetime.now().isoformat()
    })


# ============== API Models ==============

class HealthResponse(BaseModel):
    status: str
    timestamp: str
    version: str


class FrameExtractionResponse(BaseModel):
    unique_id: str
    frames: Dict[str, str]
    message: str


class TaskStatusResponse(BaseModel):
    status: str
    start_time: str
    end_time: Optional[str]
    frames: List[str]


# ============== Endpoints ==============

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint."""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now().isoformat(),
        version="1.1.0-security-fixes"
    )


@app.post("/extract-frames", response_model=FrameExtractionResponse)
async def extract_frames_api(
    request: Request,
    video_file: UploadFile = File(...),
    method: str = Form("ssim"),
    threshold: float = Form(0.8),
    background_tasks: BackgroundTasks = None,
):
    """
    Extract frames from uploaded video file.
    Security: File type validation, size limits, rate limiting
    """
    # Rate limiting
    client_ip = request.client.host
    if not upload_limiter.is_allowed(client_ip):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded. Max 5 uploads per minute."
        )
    
    # Validate method
    if not validate_method(method):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid method. Use 'ssim' or 'pixel'."
        )
    
    # Validate threshold
    if not validate_threshold(threshold):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Threshold must be between 0 and 1."
        )
    
    # Validate file extension
    if not validate_file_extension(video_file.filename):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid file type. Allowed: .mp4, .avi, .mov, .mkv, .webm"
        )
    
    unique_id = str(uuid.uuid4())
    
    try:
        video_path = get_secure_temp_filename(video_file.filename, unique_id)
    except ValidationError as e:
        raise HTTPException(400, str(e))
    
    try:
        # Read and validate file size
        contents = await video_file.read()
        
        if len(contents) > settings.max_file_size:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File too large. Max size: {settings.max_file_size // (1024*1024)}MB"
            )
        
        # Async file write
        async with aiofiles.open(video_path, "wb") as f:
            await f.write(contents)
        
        # Create frame directory
        frame_dir = Path(settings.storage_folder) / unique_id
        frame_dir.mkdir(parents=True, exist_ok=True)
        
        # Run CPU-intensive operation in thread pool
        loop = asyncio.get_event_loop()
        frame_names = await loop.run_in_executor(
            executor,
            extract_frames,
            str(video_path),
            method,
            threshold,
            str(frame_dir)
        )
        
        # Schedule cleanup
        if background_tasks:
            background_tasks.add_task(
                delete_frames_after_delay,
                unique_id,
                settings.delete_delay_mins
            )
        
        # Store task info
        await task_storage.set(unique_id, {
            "status": "pending",
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "frames": frame_names,
        })
        
        # Generate frame URLs
        frame_urls = {
            name: f"/get-frame/{unique_id}/{name}"
            for name in frame_names
        }
        
        return FrameExtractionResponse(
            unique_id=unique_id,
            frames=frame_urls,
            message=f"Successfully extracted {len(frame_names)} frames"
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing video: {str(e)}"
        )
    finally:
        # Guaranteed cleanup
        if os.path.exists(video_path):
            os.remove(video_path)


@app.get("/get-frame/{unique_id}/{frame_name}")
async def get_frame(request: Request, unique_id: str, frame_name: str):
    """
    Serve a specific frame as an image.
    Security: UUID validation, filename validation, path traversal protection
    """
    # Rate limiting
    client_ip = request.client.host
    if not frame_limiter.is_allowed(client_ip):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded."
        )
    
    # Validate UUID format
    if not validate_uuid(unique_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid unique_id format"
        )
    
    # Validate filename format
    if not validate_filename(frame_name):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid frame_name format"
        )
    
    # Get safe path (path traversal protection)
    try:
        frame_path = get_safe_path(settings.storage_folder, unique_id, frame_name)
    except ValueError as e:
        raise HTTPException(status_code=403, detail="Access denied")
    
    if not frame_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Frame not found. It may have been deleted."
        )
    
    # Add security headers
    headers = get_security_headers()
    headers['Cache-Control'] = 'public, max-age=3600'
    
    return StreamingResponse(
        open(frame_path, "rb"),
        media_type="image/png",
        headers=headers
    )


@app.post("/extract-frames-url")
async def extract_frames_url_api(
    request: Request,
    reel_url: str = Form(...),
    method: str = Form('ssim'),
    threshold: float = Form(0.8),
    background_tasks: BackgroundTasks = None,
):
    """
    Extract frames from video URL.
    Security: URL validation, command injection prevention, rate limiting
    """
    # Rate limiting
    client_ip = request.client.host
    if not url_limiter.is_allowed(client_ip):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded. Max 3 URL extractions per minute."
        )
    
    # Validate method
    if not validate_method(method):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid method. Use 'ssim' or 'pixel'."
        )
    
    # Validate threshold
    if not validate_threshold(threshold):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Threshold must be between 0 and 1."
        )
    
    # Validate URL (CRITICAL: prevents command injection!)
    if not validate_reel_url(reel_url):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid URL. Only Instagram, YouTube, Facebook, and TikTok URLs are allowed."
        )
    
    unique_id = str(uuid.uuid4())
    video_path = f"temp_{unique_id}.mp4"
    
    try:
        # Build safe command (prevents command injection)
        command = build_safe_command(
            ["yt-dlp", "-f", "best[ext=mp4]/best"],
            reel_url,
            video_path
        )
        
        # Add max file size limit
        command.extend(["--max-filesize", str(settings.max_file_size)])
        
        # Run subprocess with timeout
        try:
            stdout, stderr = await run_subprocess_with_timeout(command, timeout=300)
        except asyncio.TimeoutError:
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail="Download timed out after 5 minutes."
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unable to download video: {str(e)}"
            )
        
        # Create frame directory
        frame_dir = Path(settings.storage_folder) / unique_id
        frame_dir.mkdir(parents=True, exist_ok=True)
        
        # Extract frames
        loop = asyncio.get_event_loop()
        frame_names = await loop.run_in_executor(
            executor,
            extract_frames,
            video_path,
            method,
            threshold,
            str(frame_dir)
        )
        
        # Schedule cleanup
        if background_tasks:
            background_tasks.add_task(
                delete_frames_after_delay,
                unique_id,
                settings.delete_delay_mins
            )
        
        # Store task info
        await task_storage.set(unique_id, {
            "status": "pending",
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "frames": frame_names,
        })
        
        # Generate frame URLs
        frame_urls = {
            name: f"/get-frame/{unique_id}/{name}"
            for name in frame_names
        }
        
        return FrameExtractionResponse(
            unique_id=unique_id,
            frames=frame_urls,
            message=f"Successfully extracted {len(frame_names)} frames"
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing video: {str(e)}"
        )
    finally:
        # Guaranteed cleanup
        if os.path.exists(video_path):
            os.remove(video_path)


@app.get("/background-tasks/{unique_id}")
async def get_background_task_status(unique_id: str):
    """Get the status of a specific background task."""
    if not validate_uuid(unique_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid unique_id format"
        )
    
    task = await task_storage.get(unique_id)
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Background task not found."
        )
    
    return TaskStatusResponse(**task)


# ============== Error Handlers ==============

@app.exception_handler(404)
async def not_found_exception_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"detail": "Resource not found."},
        headers=get_security_headers()
    )


@app.exception_handler(500)
async def internal_server_error_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Please try again later."},
        headers=get_security_headers()
    )


# ============== Startup/Shutdown ==============

@app.on_event("startup")
async def startup_event():
    """Initialize on startup."""
    os.makedirs(settings.storage_folder, exist_ok=True)
    print(f"🚀 ReelShot API v1.1.0 started (Security Hardened)")
    print(f"   Storage: {settings.storage_folder}")
    print(f"   Max file size: {settings.max_file_size // (1024*1024)}MB")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    executor.shutdown(wait=True)
    print("👋 Shutdown complete")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=settings.port, reload=False)
