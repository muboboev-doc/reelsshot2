# ReelShot Backend - Phase 1 Security Fixes

Исправлены критические уязвимости: Command Injection, Path Traversal, Arbitrary File Write

---

## 🚀 Быстрый старт

### Локальная разработка

```bash
# 1. Установка зависимостей
make install

# 2. Настройка окружения
cp .env.example .env
# Отредактируйте .env при необходимости

# 3. Запуск
make dev
```

### Docker

```bash
# Сборка и запуск
make build
make run

# Проверка
make docker-test
```

---

## 🔒 Исправленные уязвимости

### ✅ Command Injection
- URL валидация через regex
- Whitelist разрешенных доменов
- `--` разделитель в команде
- Таймаут 300 секунд

### ✅ Path Traversal
- UUID валидация (v4 формат)
- Filename валидация (`frame_\d{4}\.png`)
- Safe path construction с `Path.relative_to()`

### ✅ Arbitrary File Write
- Whitelist расширений (`.mp4`, `.avi`, `.mov`, `.mkv`)
- Генерация безопасных имен файлов
- `try/finally` для очистки

### ✅ Rate Limiting
- In-memory rate limiter
- `/extract-frames`: 5/min
- `/extract-frames-url`: 3/min
- `/get-frame`: 60/min

---

## 🧪 Тестирование

```bash
# Unit тесты
make test

# С coverage
make test-cov

# Security audit
make security

# Docker тест
make docker-test
```

---

## 📁 Структура проекта

```
.
├── main.py                 # FastAPI приложение
├── requirements.txt        # Зависимости
├── Dockerfile             # Docker образ
├── docker-compose.yml     # Docker Compose
├── .env.example           # Пример конфигурации
├── Makefile               # Команды
├── utils/                 # Утилиты
│   ├── validators.py      # Валидация
│   ├── security.py        # Security функции
│   └── video_utils.py     # Обработка видео
└── tests/                 # Тесты
    └── test_security.py   # Security тесты
```

---

## 🔧 Переменные окружения

| Переменная | Описание | По умолчанию |
|------------|----------|--------------|
| `STORAGE_FOLDER` | Директория для хранения | `storage` |
| `DELETE_DELAY_MINS` | Время до удаления (мин) | `30` |
| `MAX_FILE_SIZE` | Макс. размер файла (bytes) | `524288000` (500MB) |
| `FRONTEND_URL` | URL фронтенда для CORS | `http://localhost:5173` |
| `PORT` | Порт сервера | `8000` |

---

## 📊 API Endpoints

| Endpoint | Method | Описание | Rate Limit |
|----------|--------|----------|------------|
| `/health` | GET | Health check | - |
| `/extract-frames` | POST | Загрузка и обработка | 5/min |
| `/extract-frames-url` | POST | Обработка по URL | 3/min |
| `/get-frame/{id}/{name}` | GET | Получение кадра | 60/min |

---

## 🛡️ Security Headers

Все ответы включают:
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `X-XSS-Protection: 1; mode=block`
- `Referrer-Policy: strict-origin-when-cross-origin`

---

## 📈 Мониторинг

```bash
# Health check
curl http://localhost:8000/health

# Metrics (если включено)
curl http://localhost:8000/metrics
```

---

## 📝 Лицензия

MIT
