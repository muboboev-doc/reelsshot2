"""
Pytest configuration and fixtures for ReelShot Backend tests.
"""

import pytest
import asyncio
import tempfile
import shutil
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import numpy as np

# Add parent to path
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from main import app, app_state, thread_pool


# ============== Fixtures ==============

@pytest.fixture
def event_loop():
    """Create an instance of the default event loop for each test case."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def client():
    """Create a test client for the FastAPI app."""
    from fastapi.testclient import TestClient
    return TestClient(app)


@pytest.fixture
def temp_storage_dir():
    """Create a temporary storage directory for tests."""
    temp_dir = tempfile.mkdtemp(prefix="reelshot_test_")
    yield temp_dir
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def mock_video_file():
    """Create a mock video file for testing."""
    return b"fake video content for testing"


@pytest.fixture
def valid_uuid():
    """Return a valid UUID for testing."""
    return "550e8400-e29b-41d4-a716-446655440000"


@pytest.fixture
def valid_frame_name():
    """Return a valid frame name for testing."""
    return "frame_0000.png"


@pytest.fixture
def mock_frame():
    """Create a mock frame (numpy array) for testing."""
    return np.random.randint(0, 255, (240, 320, 3), dtype=np.uint8)


@pytest.fixture
def reset_rate_limiters():
    """Reset rate limiters before each test."""
    from main import upload_limiter, url_limiter, frame_limiter
    upload_limiter.requests.clear()
    url_limiter.requests.clear()
    frame_limiter.requests.clear()
    yield


@pytest.fixture
def reset_app_state():
    """Reset application state before each test."""
    app_state.active_tasks = 0
    app_state.total_requests = 0
    app_state.total_errors = 0
    yield


# ============== Mock Fixtures ==============

@pytest.fixture
def mock_extract_frames():
    """Mock extract_frames function."""
    with patch('main.extract_frames') as mock:
        mock.return_value = ["frame_0000.png", "frame_0001.png"]
        yield mock


@pytest.fixture
def mock_video_capture():
    """Mock cv2.VideoCapture."""
    with patch('utils.video_utils.cv2.VideoCapture') as mock_cap:
        instance = MagicMock()
        instance.isOpened.return_value = True
        instance.read.return_value = (True, np.zeros((240, 320, 3), dtype=np.uint8))
        instance.get.side_effect = lambda x: {
            cv2.CAP_PROP_FPS: 30.0,
            cv2.CAP_PROP_FRAME_COUNT: 100,
            cv2.CAP_PROP_FRAME_WIDTH: 320,
            cv2.CAP_PROP_FRAME_HEIGHT: 240,
        }.get(x, 0)
        mock_cap.return_value = instance
        yield mock_cap


@pytest.fixture
def mock_subprocess():
    """Mock subprocess for yt-dlp calls."""
    with patch('utils.security.asyncio.create_subprocess_exec') as mock:
        proc = MagicMock()
        proc.returncode = 0
        proc.communicate = asyncio.coroutine(lambda: (b"", b""))
        mock.return_value = proc
        yield mock


# ============== Helper Functions ==============

def create_test_video_file(path: str, size_mb: int = 1):
    """Create a test video file of specified size."""
    with open(path, 'wb') as f:
        f.write(b'\x00' * (size_mb * 1024 * 1024))


def create_test_frame_file(path: str):
    """Create a test PNG frame file."""
    import cv2
    frame = np.random.randint(0, 255, (240, 320, 3), dtype=np.uint8)
    cv2.imwrite(path, frame)


# ============== Pytest Configuration ==============

def pytest_configure(config):
    """Configure pytest."""
    config.addinivalue_line(
        "markers", "integration: mark test as integration test"
    )
    config.addinivalue_line(
        "markers", "slow: mark test as slow running"
    )
    config.addinivalue_line(
        "markers", "security: mark test as security test"
    )


def pytest_collection_modifyitems(config, items):
    """Modify test collection."""
    # Add markers based on test name
    for item in items:
        if "security" in item.nodeid.lower():
            item.add_marker(pytest.mark.security)
        if "integration" in item.nodeid.lower():
            item.add_marker(pytest.mark.integration)
