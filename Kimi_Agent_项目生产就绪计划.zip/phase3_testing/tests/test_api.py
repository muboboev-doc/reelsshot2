"""
API endpoint tests for ReelShot Backend.
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock
import json


# ============== Health Endpoint Tests ==============

class TestHealthEndpoint:
    """Tests for /health endpoint."""
    
    def test_health_check_success(self, client):
        """Health check should return 200 with system info."""
        response = client.get("/health")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["status"] in ["healthy", "degraded", "critical"]
        assert "timestamp" in data
        assert "version" in data
        assert "uptime_seconds" in data
        assert "uptime_formatted" in data
        assert "system" in data
        assert "active_tasks" in data
        assert "total_requests" in data
        assert "total_errors" in data
    
    def test_health_check_system_info(self, client):
        """Health check should include system information."""
        response = client.get("/health")
        data = response.json()
        
        system = data["system"]
        assert "cpu_percent" in system
        assert "memory_percent" in system
        assert "memory_available_mb" in system
        assert "disk_usage_percent" in system
        assert "disk_free_gb" in system
        
        # Validate ranges
        assert 0 <= system["cpu_percent"] <= 100
        assert 0 <= system["memory_percent"] <= 100
        assert 0 <= system["disk_usage_percent"] <= 100
    
    def test_health_check_security_headers(self, client):
        """Health check response should include security headers."""
        response = client.get("/health")
        
        assert "X-Content-Type-Options" in response.headers
        assert response.headers["X-Content-Type-Options"] == "nosniff"


# ============== Extract Frames Tests ==============

class TestExtractFrames:
    """Tests for /extract-frames endpoint."""
    
    def test_extract_frames_invalid_method(self, client, reset_rate_limiters):
        """Should reject invalid method."""
        response = client.post(
            "/extract-frames",
            data={"method": "invalid", "threshold": "0.8"},
            files={"video_file": ("test.mp4", b"fake content", "video/mp4")}
        )
        
        assert response.status_code == 400
        assert "Invalid method" in response.json()["detail"]
    
    def test_extract_frames_invalid_threshold_high(self, client, reset_rate_limiters):
        """Should reject threshold > 1."""
        response = client.post(
            "/extract-frames",
            data={"method": "ssim", "threshold": "1.5"},
            files={"video_file": ("test.mp4", b"fake content", "video/mp4")}
        )
        
        assert response.status_code == 400
        assert "Threshold must be between 0 and 1" in response.json()["detail"]
    
    def test_extract_frames_invalid_threshold_low(self, client, reset_rate_limiters):
        """Should reject threshold < 0."""
        response = client.post(
            "/extract-frames",
            data={"method": "ssim", "threshold": "-0.5"},
            files={"video_file": ("test.mp4", b"fake content", "video/mp4")}
        )
        
        assert response.status_code == 400
        assert "Threshold must be between 0 and 1" in response.json()["detail"]
    
    def test_extract_frames_invalid_extension(self, client, reset_rate_limiters):
        """Should reject invalid file extension."""
        response = client.post(
            "/extract-frames",
            data={"method": "ssim", "threshold": "0.8"},
            files={"video_file": ("test.exe", b"malicious content", "application/x-msdownload")}
        )
        
        assert response.status_code == 400
        assert "Invalid file type" in response.json()["detail"]
    
    def test_extract_frames_file_too_large(self, client, reset_rate_limiters):
        """Should reject file exceeding max size."""
        # Create a "file" that reports large size
        large_content = b"x" * (501 * 1024 * 1024)  # 501MB
        
        response = client.post(
            "/extract-frames",
            data={"method": "ssim", "threshold": "0.8"},
            files={"video_file": ("test.mp4", large_content, "video/mp4")}
        )
        
        assert response.status_code == 413
        assert "File too large" in response.json()["detail"]
    
    @pytest.mark.integration
    def test_extract_frames_success(self, client, reset_rate_limiters, mock_extract_frames, temp_storage_dir):
        """Should successfully extract frames from valid video."""
        with patch('main.settings.storage_folder', temp_storage_dir):
            response = client.post(
                "/extract-frames",
                data={"method": "ssim", "threshold": "0.8"},
                files={"video_file": ("test.mp4", b"fake video content", "video/mp4")}
            )
            
            assert response.status_code == 200
            data = response.json()
            
            assert "unique_id" in data
            assert "frames" in data
            assert "message" in data
            assert len(data["frames"]) == 2


# ============== Get Frame Tests ==============

class TestGetFrame:
    """Tests for /get-frame/{unique_id}/{frame_name} endpoint."""
    
    def test_get_frame_invalid_uuid(self, client, reset_rate_limiters):
        """Should reject invalid UUID format."""
        response = client.get("/get-frame/invalid-uuid/frame_0000.png")
        
        assert response.status_code == 400
        assert "Invalid unique_id" in response.json()["detail"]
    
    def test_get_frame_invalid_filename(self, client, reset_rate_limiters):
        """Should reject invalid filename format."""
        response = client.get("/get-frame/550e8400-e29b-41d4-a716-446655440000/malicious.exe")
        
        assert response.status_code == 400
        assert "Invalid frame_name" in response.json()["detail"]
    
    def test_get_frame_path_traversal_attempt(self, client, reset_rate_limiters):
        """Should block path traversal attempts."""
        traversal_attempts = [
            "/get-frame/../../../etc/passwd/frame_0000.png",
            "/get-frame/550e8400-e29b-41d4-a716-446655440000/../../../etc/passwd",
            "/get-frame/..%2f..%2f..%2fetc%2fpasswd/frame_0000.png",
        ]
        
        for url in traversal_attempts:
            response = client.get(url)
            assert response.status_code in [400, 403, 404], f"Failed for {url}"
    
    def test_get_frame_not_found(self, client, reset_rate_limiters):
        """Should return 404 for non-existent frame."""
        response = client.get("/get-frame/550e8400-e29b-41d4-a716-446655440000/frame_0000.png")
        
        assert response.status_code == 404
        assert "Frame not found" in response.json()["detail"]


# ============== Extract Frames URL Tests ==============

class TestExtractFramesUrl:
    """Tests for /extract-frames-url endpoint."""
    
    def test_extract_frames_url_invalid_url(self, client, reset_rate_limiters):
        """Should reject invalid URL."""
        response = client.post(
            "/extract-frames-url",
            data={
                "reel_url": "https://malicious.com",
                "method": "ssim",
                "threshold": "0.8"
            }
        )
        
        assert response.status_code == 400
        assert "Invalid URL" in response.json()["detail"]
    
    def test_extract_frames_url_command_injection(self, client, reset_rate_limiters):
        """Should block command injection attempts."""
        injection_attempts = [
            "; rm -rf /",
            "| cat /etc/passwd",
            "`whoami`,
            "$(id)",
            "https://example.com; rm -rf /",
        ]
        
        for url in injection_attempts:
            response = client.post(
                "/extract-frames-url",
                data={
                    "reel_url": url,
                    "method": "ssim",
                    "threshold": "0.8"
                }
            )
            assert response.status_code == 400, f"Failed to block: {url}"
    
    def test_extract_frames_url_valid_instagram(self, client, reset_rate_limiters):
        """Should accept valid Instagram URL format."""
        # Note: This will fail because we can't actually download
        # but it should pass URL validation
        response = client.post(
            "/extract-frames-url",
            data={
                "reel_url": "https://www.instagram.com/reel/ABC123/",
                "method": "ssim",
                "threshold": "0.8"
            }
        )
        
        # Will fail at download stage but URL validation should pass
        # In real test with mocked subprocess, this would return 200
        assert response.status_code in [200, 400, 500]


# ============== Background Tasks Tests ==============

class TestBackgroundTasks:
    """Tests for /background-tasks/{unique_id} endpoint."""
    
    def test_get_task_status_invalid_uuid(self, client):
        """Should reject invalid UUID format."""
        response = client.get("/background-tasks/invalid-uuid")
        
        assert response.status_code == 400
        assert "Invalid unique_id" in response.json()["detail"]
    
    def test_get_task_status_not_found(self, client):
        """Should return 404 for non-existent task."""
        response = client.get("/background-tasks/550e8400-e29b-41d4-a716-446655440000")
        
        assert response.status_code == 404
        assert "Background task not found" in response.json()["detail"]


# ============== Rate Limiting Tests ==============

class TestRateLimiting:
    """Tests for rate limiting functionality."""
    
    def test_rate_limit_upload(self, client, reset_rate_limiters):
        """Should enforce rate limit on upload endpoint."""
        # Make 6 requests (limit is 5)
        responses = []
        for i in range(6):
            response = client.post(
                "/extract-frames",
                data={"method": "ssim", "threshold": "0.8"},
                files={"video_file": ("test.mp4", b"content", "video/mp4")}
            )
            responses.append(response.status_code)
        
        # At least one should be rate limited
        assert 429 in responses or all(r in [200, 400] for r in responses)
    
    def test_rate_limit_frame_access(self, client, reset_rate_limiters):
        """Should enforce rate limit on frame access."""
        # Make many requests
        responses = []
        for i in range(70):  # Limit is 60
            response = client.get("/get-frame/550e8400-e29b-41d4-a716-446655440000/frame_0000.png")
            responses.append(response.status_code)
        
        # Should see some rate limiting
        assert 429 in responses or 400 in responses


# ============== Error Handler Tests ==============

class TestErrorHandlers:
    """Tests for error handlers."""
    
    def test_404_handler(self, client):
        """Should return proper 404 response."""
        response = client.get("/non-existent-endpoint")
        
        assert response.status_code == 404
        assert "Resource not found" in response.json()["detail"]
        
        # Check security headers
        assert "X-Content-Type-Options" in response.headers
    
    def test_405_handler(self, client):
        """Should return proper 405 response for wrong method."""
        response = client.get("/extract-frames")  # POST only
        
        assert response.status_code == 405


# ============== Security Headers Tests ==============

class TestSecurityHeaders:
    """Tests for security headers."""
    
    def test_security_headers_present(self, client):
        """All responses should include security headers."""
        response = client.get("/health")
        
        assert "X-Content-Type-Options" in response.headers
        assert "X-Frame-Options" in response.headers
        assert "X-XSS-Protection" in response.headers
        assert "Referrer-Policy" in response.headers
        assert "Content-Security-Policy" in response.headers
    
    def test_no_server_header(self, client):
        """Server header should be removed."""
        response = client.get("/health")
        
        # Server header should not reveal implementation details
        assert response.headers.get("Server", "") == ""


# ============== Monitoring Tests ==============

class TestMonitoring:
    """Tests for monitoring functionality."""
    
    def test_request_counting(self, client, reset_app_state):
        """Should count requests correctly."""
        initial_requests = app_state.total_requests
        
        # Make some requests
        for _ in range(5):
            client.get("/health")
        
        assert app_state.total_requests == initial_requests + 5
    
    def test_active_tasks_tracking(self, client, reset_app_state):
        """Should track active tasks."""
        # This is harder to test without actual processing
        # Just verify the counter exists
        assert app_state.active_tasks >= 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
