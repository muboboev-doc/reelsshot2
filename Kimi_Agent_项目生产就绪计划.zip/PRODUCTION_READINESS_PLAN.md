# План доработок ReelShot Backend до 100% готовности к продакшену

> **Текущая готовность:** 15%  
> **Целевая готовность:** 100%  
> **Оценочное время:** 3-4 недели (1 разработчик)  
> **Дата плана:** 2026-04-07

---

## 📊 Матрица готовности

| Компонент | Текущий % | Целевой % | Приоритет | Оценка времени |
|-----------|:---------:|:---------:|:---------:|:--------------:|
| Безопасность | 10% | 100% | P0 | 5 дней |
| Производительность | 20% | 100% | P0 | 4 дня |
| Архитектура | 30% | 100% | P1 | 3 дня |
| Инфраструктура | 5% | 100% | P1 | 4 дня |
| Тестирование | 0% | 100% | P1 | 3 дня |
| Мониторинг | 0% | 100% | P2 | 2 дня |
| Документация | 10% | 100% | P2 | 2 дня |
| DevOps | 5% | 100% | P2 | 3 дня |
| **ИТОГО** | **15%** | **100%** | - | **26 дней** |

---

## 🗓️ Детальный план по неделям

### Неделя 1: Критическая безопасность и стабильность

#### День 1-2: Исправление критических уязвимостей

**Задачи:**
- [ ] **1.1. Исправить Command Injection** (4 часа)
  - Валидация URL через regex
  - Использование списка аргументов вместо строки
  - Добавить `--` разделитель
  
- [ ] **1.2. Исправить Path Traversal** (3 часа)
  - Валидация UUID формата
  - Валидация имени файла
  - Проверка safe path через `Path.relative_to()`
  
- [ ] **1.3. Исправить Arbitrary File Write** (3 часа)
  - Генерация безопасных имен файлов
  - Валидация расширений
  - Проверка MIME-type
  
- [ ] **1.4. Добавить rate limiting** (2 часа)
  - Установить slowapi
  - Настроить лимиты: 10/min для upload, 100/min для API
  - Настроить Redis backend для rate limiting

**Результат:** Устранены все CRITICAL уязвимости

#### День 3-4: Производительность и async

**Задачи:**
- [ ] **2.1. Асинхронная обработка файлов** (4 часа)
  - Установить `aiofiles`
  - Переписать чтение/запись файлов на async
  - Добавить `asyncio.to_thread()` для CPU-bound операций
  
- [ ] **2.2. Thread pool для CV2** (3 часа)
  - Создать `ThreadPoolExecutor(max_workers=4)`
  - Вынести `extract_frames()` в пул потоков
  - Добавить graceful shutdown
  
- [ ] **2.3. Оптимизация памяти** (3 часа)
  - Убрать хранение кадров в памяти
  - Возвращать только имена файлов
  - Добавить пропуск кадров (skip_frames=2)
  
- [ ] **2.4. Таймауты** (2 часа)
  - Добавить таймауты для subprocess (300 сек)
  - Таймауты для HTTP запросов
  - Обработка timeout ошибок

**Результат:** Сервер не блокируется, обрабатывает 10+ параллельных запросов

#### День 5: Docker и базовая инфраструктура

**Задачи:**
- [ ] **3.1. Dockerfile** (3 часа)
  - Многоступенчатая сборка
  - Non-root пользователь
  - Health check
  
- [ ] **3.2. Docker Compose** (2 часа)
  - Разработка + продакшен конфигурации
  - Redis для кэширования
  - Nginx reverse proxy
  
- [ ] **3.3. Environment variables** (2 часа)
  - Pydantic Settings для валидации
  - `.env.example` со всеми переменными
  - Secrets management

**Результат:** Проект запускается в Docker

---

### Неделя 2: Архитектура и тестирование

#### День 6-7: Улучшение архитектуры

**Задачи:**
- [ ] **4.1. Thread-safe хранилище задач** (4 часа)
  - Класс `TaskStorage` с `asyncio.Lock()`
  - Методы: get, set, update, delete, get_all
  - Автоматическая очистка старых задач
  
- [ ] **4.2. Graceful shutdown** (3 часа)
  - Обработка сигналов SIGTERM/SIGINT
  - Ожидание завершения background tasks
  - Корректное закрытие ThreadPoolExecutor
  
- [ ] **4.3. Health checks** (2 часа)
  - `/health` endpoint
  - Проверка диска, памяти, зависимостей
  - Готовность для Kubernetes/Docker Swarm
  
- [ ] **4.4. Рефакторинг дублирующегося кода** (3 часа)
  - Общая функция для обработки видео
  - Единая логика для upload и URL
  - Утилиты для валидации

**Результат:** Чистая, поддерживаемая архитектура

#### День 8-9: Unit и интеграционные тесты

**Задачи:**
- [ ] **5.1. Тесты для валидации** (3 часа)
  - Тесты для UUID, filename, URL валидации
  - Path traversal тесты
  - Security fuzzing тесты
  
- [ ] **5.2. Тесты для API endpoints** (4 часа)
  - `/health`, `/extract-frames`, `/get-frame`
  - Тесты для ошибок (404, 400, 413)
  - Async тесты с `pytest-asyncio`
  
- [ ] **5.3. Интеграционные тесты** (3 часа)
  - Полный цикл: upload → extract → get frame
  - Тесты с реальными видео файлами
  - Тесты для URL extraction
  
- [ ] **5.4. Coverage** (2 часа)
  - Настроить `pytest-cov`
  - Цель: >80% покрытие
  - Отчеты в HTML и XML

**Результат:** Надежный набор тестов

#### День 10: CI/CD пайплайн

**Задачи:**
- [ ] **6.1. GitHub Actions** (4 часа)
  - Workflow для test/lint/security
  - Сборка Docker образа
  - Пуш в Container Registry
  
- [ ] **6.2. Security scanning** (2 часа)
  - Bandit для SAST
  - Safety для зависимостей
  - Trivy для сканирования образа
  
- [ ] **6.3. Автоматический деплой** (2 часа)
  - Деплой в staging при push в develop
  - Деплой в production при создании tag
  - Уведомления в Slack

**Результат:** Автоматизированная доставка

---

### Неделя 3: Продакшен инфраструктура

#### День 11-12: Nginx и SSL

**Задачи:**
- [ ] **7.1. Nginx конфигурация** (4 часа)
  - Reverse proxy с load balancing
  - Rate limiting на уровне Nginx
  - Gzip compression
  
- [ ] **7.2. SSL/TLS** (3 часа)
  - Let's Encrypt сертификаты
  - HTTPS redirect
  - HSTS headers
  
- [ ] **7.3. Security headers** (2 часа)
  - X-Frame-Options, X-Content-Type-Options
  - CSP (Content Security Policy)
  - CORS настройка
  
- [ ] **7.4. File upload optimization** (3 часа)
  - `client_max_body_size 500M`
  - Buffer tuning
  - Timeouts для больших файлов

**Результат:** Производительный и безопасный веб-сервер

#### День 13-14: Мониторинг и логирование

**Задачи:**
- [ ] **8.1. Prometheus метрики** (4 часа)
  - `prometheus-client` библиотека
  - Метрики: запросы, latency, ошибки
  - Кастомные метрики: количество кадров, время обработки
  
- [ ] **8.2. Grafana dashboards** (3 часа)
  - Dashboard для API метрик
  - Dashboard для системных ресурсов
  - Alerts для критических ошибок
  
- [ ] **8.3. Centralized logging** (3 часа)
  - JSON формат логов
  - Structured logging с `python-json-logger`
  - Correlation ID для tracing
  
- [ ] **8.4. Alerting** (2 часа)
  - Alerts: high error rate, high latency, disk full
  - Интеграция с PagerDuty/Opsgenie
  - Email/Slack уведомления

**Результат:** Полная observability системы

#### День 15: Отказоустойчивость

**Задачи:**
- [ ] **9.1. Circuit breaker** (3 часа)
  - `pybreaker` для внешних вызовов
  - Fallback механизмы
  - Автоматическое восстановление
  
- [ ] **9.2. Retry logic** (2 часа)
  - `tenacity` для retry с backoff
  - Retry для yt-dlp вызовов
  - Idempotency ключи
  
- [ ] **9.3. Dead letter queue** (3 часа)
  - Хранение failed tasks
  - Повторная обработка
  - Админ интерфейс для просмотра ошибок

**Результат:** Система устойчива к сбоям

---

### Неделя 4: Оптимизация и масштабирование

#### День 16-17: База данных и кэширование

**Задачи:**
- [ ] **10.1. PostgreSQL для метаданных** (5 часов)
  - Модель `VideoTask` (SQLAlchemy)
  - Хранение статусов, путей, метрик
  - Миграции с Alembic
  
- [ ] **10.2. Redis кэширование** (3 часа)
  - Кэширование частых запросов
  - Rate limiting с Redis backend
  - Pub/sub для статусов задач
  
- [ ] **10.3. S3 хранилище** (4 часа)
  - Интеграция с AWS S3 / MinIO
  - Хранение кадров в объектном хранилище
  - Pre-signed URLs для доступа
  
- [ ] **10.4. CDN** (2 часа)
  - CloudFront / CloudFlare
  - Кэширование статических файлов
  - Geo-distribution

**Результат:** Масштабируемая архитектура

#### День 18-19: Очереди задач

**Задачи:**
- [ ] **11.1. Celery + Redis** (5 часов)
  - Асинхронная обработка видео
  - Отдельные workers для extraction
  - Prioritization очередей
  
- [ ] **11.2. Task monitoring** (3 часа)
  - Flower для мониторинга Celery
  - Отслеживание прогресса задач
  - Retry failed tasks
  
- [ ] **11.3. Horizontal scaling** (4 часа)
  - Stateless приложение
  - Load balancer configuration
  - Auto-scaling policies

**Результат:** Обработка 100+ параллельных задач

#### День 20: Документация и финализация

**Задачи:**
- [ ] **12.1. API Documentation** (3 часа)
  - OpenAPI/Swagger с примерами
  - Postman коллекция
  - CHANGELOG.md
  
- [ ] **12.2. Runbooks** (3 часа)
  - Onboarding документация
  - Troubleshooting guide
  - Incident response playbook
  
- [ ] **12.3. Security audit** (2 часа)
  - Повторный security scan
  - Penetration testing
  - Compliance checklist (GDPR)
  
- [ ] **12.4. Performance testing** (2 часа)
  - Load testing с Locust
  - Нагрузочное тестирование
  - Оптимизация bottleneck'ов

**Результат:** Проект готов к продакшену

---

## 📋 Чеклисты по фазам

### Фаза 1: Безопасность (Неделя 1)

```markdown
- [ ] Command Injection устранен
- [ ] Path Traversal устранен
- [ ] Arbitrary File Write устранен
- [ ] Rate limiting работает
- [ ] CORS правильно настроен
- [ ] Все входы валидируются
- [ ] Security headers добавлены
- [ ] Таймауты настроены
```

### Фаза 2: Стабильность (Неделя 1-2)

```markdown
- [ ] Async file operations
- [ ] Thread pool для CPU-bound задач
- [ ] Graceful shutdown работает
- [ ] Memory leaks устранены
- [ ] Health check endpoint
- [ ] Error handling
- [ ] Logging настроен
```

### Фаза 3: Тестирование (Неделя 2)

```markdown
- [ ] Unit tests >80% coverage
- [ ] Integration tests проходят
- [ ] Security tests проходят
- [ ] Load tests пройдены
- [ ] CI/CD pipeline работает
- [ ] Pre-commit hooks
```

### Фаза 4: Инфраструктура (Неделя 3)

```markdown
- [ ] Docker образ собирается
- [ ] Nginx + SSL работает
- [ ] Prometheus + Grafana
- [ ] Centralized logging
- [ ] Alerts настроены
- [ ] Backup strategy
```

### Фаза 5: Масштабирование (Неделя 4)

```markdown
- [ ] PostgreSQL интегрирована
- [ ] Redis кэширование
- [ ] S3 хранилище
- [ ] Celery очереди
- [ ] Horizontal scaling
- [ ] CDN настроен
```

---

## 🛠️ Технологический стек

### Core
| Компонент | Текущий | Целевой |
|-----------|---------|---------|
| Framework | FastAPI | FastAPI |
| Python | 3.11 | 3.11 |
| ASGI Server | Uvicorn | Uvicorn + Gunicorn |

### Безопасность
| Компонент | Текущий | Целевой |
|-----------|---------|---------|
| Rate Limiting | ❌ | slowapi + Redis |
| Auth | ❌ | JWT (optional) |
| Validation | ❌ | Pydantic + regex |
| Secrets | ❌ | Vault/AWS Secrets Manager |

### База данных
| Компонент | Текущий | Целевой |
|-----------|---------|---------|
| Storage | In-memory | PostgreSQL |
| Cache | ❌ | Redis |
| Object Storage | Local FS | S3 / MinIO |

### Очереди
| Компонент | Текущий | Целевой |
|-----------|---------|---------|
| Background Tasks | FastAPI native | Celery + Redis |
| Workers | 1 | 4+ scalable |
| Monitoring | ❌ | Flower |

### Инфраструктура
| Компонент | Текущий | Целевой |
|-----------|---------|---------|
| Containerization | ❌ | Docker + Compose |
| Orchestration | ❌ | Kubernetes (optional) |
| Reverse Proxy | ❌ | Nginx |
| SSL | ❌ | Let's Encrypt |

### Мониторинг
| Компонент | Текущий | Целевой |
|-----------|---------|---------|
| Metrics | ❌ | Prometheus |
| Dashboards | ❌ | Grafana |
| Logging | ❌ | ELK / Loki |
| Alerting | ❌ | Alertmanager |
| APM | ❌ | Jaeger (optional) |

### CI/CD
| Компонент | Текущий | Целевой |
|-----------|---------|---------|
| Version Control | Git | Git + GitHub |
| CI/CD | ❌ | GitHub Actions |
| Registry | ❌ | GHCR / ECR |
| Deployment | Manual | Automated |

---

## 💰 Оценка стоимости инфраструктуры (месяц)

### Минимальная конфигурация ($50-100/мес)
- VPS: $20 (4 vCPU, 8GB RAM)
- S3 Storage: $10-30
- CDN: $10-20
- Domain + SSL: $10

### Рекомендуемая конфигурация ($200-500/мес)
- Load Balancer: $20
- 2x App Servers: $80
- PostgreSQL RDS: $50
- Redis ElastiCache: $30
- S3: $50-100
- CloudFront: $50-100
- Monitoring: $20

### Enterprise конфигурация ($1000+/мес)
- Kubernetes Cluster: $300
- Managed Services: $400
- CDN + WAF: $200
- Monitoring Stack: $100

---

## 📈 Метрики успеха

### Технические метрики
| Метрика | Текущее | Целевое |
|---------|---------|---------|
| Uptime | N/A | 99.9% |
| Response Time (p95) | >10s | <2s |
| Throughput | 1 req/s | 50+ req/s |
| Error Rate | N/A | <0.1% |
| Test Coverage | 0% | >80% |

### Бизнес метрики
| Метрика | Целевое |
|---------|---------|
| Time to Market | 4 недели |
| Deployment Frequency | On-demand |
| Lead Time for Changes | <1 час |
| Mean Time to Recovery | <30 мин |

---

## 🎯 Definition of Done

### Для каждой задачи:
- [ ] Код написан и протестирован
- [ ] Unit tests добавлены
- [ ] Integration tests проходят
- [ ] Security scan чист
- [ ] Code review пройден
- [ ] Документация обновлена

### Для каждой фазы:
- [ ] Все задачи выполнены
- [ ] Чеклист пройден
- [ ] Demo проведен
- [ ] Sign-off получен

### Для проекта:
- [ ] Все фазы завершены
- [ ] Load testing пройден
- [ ] Security audit пройден
- [ ] Runbook создан
- [ ] Команда обучена

---

## 🚨 Риски и mitigation

| Риск | Вероятность | Влияние | Mitigation |
|------|:-----------:|:-------:|------------|
| Задержки в разработке | Средняя | Высокое | Buffer в плане, приоритизация |
| Проблемы с масштабированием | Низкая | Высокое | Раннее тестирование нагрузки |
| Security breach | Низкая | Критическое | Регулярные сканы, аудиты |
| Бюджет превышен | Средняя | Среднее | Фиксированная стоимость, этапы |
| Зависимости устареют | Высокая | Низкое | Dependabot, регулярные обновления |

---

## 📞 Контакты и ответственные

| Роль | Ответственный | Задачи |
|------|---------------|--------|
| Backend Dev | TBD | Разработка, тесты |
| DevOps | TBD | Инфраструктура, CI/CD |
| Security | TBD | Аудит, security |
| QA | TBD | Тестирование |
| Product Owner | TBD | Приоритизация |

---

## 📝 История изменений

| Версия | Дата | Изменения | Автор |
|--------|------|-----------|-------|
| 1.0 | 2026-04-07 | Initial plan | AI Assistant |

---

**Следующий шаг:** Начните с Phase 1, Day 1 - исправление Command Injection!
