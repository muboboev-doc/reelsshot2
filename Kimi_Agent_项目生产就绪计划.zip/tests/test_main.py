"""
Unit tests for ReelShot Backend API.
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock
import os
import uuid

# Import the app
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from main import app, validate_uuid, validate_filename, validate_reel_url, validate_file_extension

client = TestClient(app)


# ============== Test Fixtures ==============

@pytest.fixture
def mock_video_file():
    """Create a mock video file for testing."""
    return b"fake video content"


@pytest.fixture
def mock_uuid():
    """Generate a test UUID."""
    return str(uuid.uuid4())


# ============== Health Check Tests ==============

def test_health_check():
    """Test health check endpoint."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "timestamp" in data
    assert "version" in data


def test_root_endpoint():
    """Test root endpoint."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "name" in data
    assert "version" in data


# ============== Validation Tests ==============

def test_validate_uuid_valid():
    """Test UUID validation with valid UUID."""
    valid_uuid = "550e8400-e29b-41d4-a716-446655440000"
    assert validate_uuid(valid_uuid) is True


def test_validate_uuid_invalid():
    """Test UUID validation with invalid UUID."""
    invalid_uuids = [
        "not-a-uuid",
        "550e8400-e29b-41d4-a716",  # Too short
        "../../../etc/passwd",  # Path traversal attempt
        "",
    ]
    for invalid in invalid_uuids:
        assert validate_uuid(invalid) is False


def test_validate_filename_valid():
    """Test filename validation with valid filenames."""
    valid_names = [
        "frame_0000.png",
        "frame_1234.png",
        "frame_9999.png",
    ]
    for name in valid_names:
        assert validate_filename(name) is True


def test_validate_filename_invalid():
    """Test filename validation with invalid filenames."""
    invalid_names = [
        "../../../etc/passwd",
        "frame_0000.jpg",
        "not_a_frame.png",
        "frame.png",
        "",
    ]
    for name in invalid_names:
        assert validate_filename(name) is False


def test_validate_reel_url_valid():
    """Test reel URL validation with valid URLs."""
    valid_urls = [
        "https://www.instagram.com/reel/ABC123/",
        "https://instagram.com/reel/ABC123",
        "https://youtube.com/watch?v=ABC123",
        "https://youtu.be/ABC123",
    ]
    for url in valid_urls:
        assert validate_reel_url(url) is True


def test_validate_reel_url_invalid():
    """Test reel URL validation with invalid URLs."""
    invalid_urls = [
        "https://malicious.com/exec/rm -rf /",
        "ftp://instagram.com/reel/ABC123",
        "not-a-url",
        "",
    ]
    for url in invalid_urls:
        assert validate_reel_url(url) is False


def test_validate_file_extension_valid():
    """Test file extension validation with valid extensions."""
    valid_files = [
        "video.mp4",
        "video.avi",
        "video.mov",
        "video.mkv",
        "video.webm",
    ]
    for filename in valid_files:
        assert validate_file_extension(filename) is True


def test_validate_file_extension_invalid():
    """Test file extension validation with invalid extensions."""
    invalid_files = [
        "video.exe",
        "video.sh",
        "video.php",
        "video",
        "",
    ]
    for filename in invalid_files:
        assert validate_file_extension(filename) is False


# ============== Security Tests ==============

def test_path_traversal_protection(mock_uuid):
    """Test protection against path traversal attacks."""
    malicious_paths = [
        "../../../etc/passwd",
        "..\\..\\..\\windows\\system32\\config\\sam",
        "..%2f..%2f..%2fetc%2fpasswd",
    ]
    
    for malicious_path in malicious_paths:
        response = client.get(f"/get-frame/{mock_uuid}/{malicious_path}")
        assert response.status_code in [400, 403, 404]


def test_invalid_uuid_format():
    """Test handling of invalid UUID format."""
    response = client.get("/get-frame/invalid-uuid/frame_0000.png")
    assert response.status_code == 400
    assert "Invalid unique_id format" in response.json()["detail"]


def test_invalid_frame_name_format(mock_uuid):
    """Test handling of invalid frame name format."""
    response = client.get(f"/get-frame/{mock_uuid}/malicious.exe")
    assert response.status_code == 400
    assert "Invalid frame_name format" in response.json()["detail"]


# ============== API Endpoint Tests ==============

@patch('main.extract_frames')
@patch('main.os.remove')
def test_extract_frames_success(mock_remove, mock_extract, mock_video_file):
    """Test successful frame extraction."""
    mock_extract.return_value = ["frame_0000.png", "frame_0001.png"]
    
    response = client.post(
        "/extract-frames",
        files={"video_file": ("test.mp4", mock_video_file, "video/mp4")},
        data={"method": "ssim", "threshold": "0.8"}
    )
    
    assert response.status_code == 201
    data = response.json()
    assert "unique_id" in data
    assert "frames" in data
    assert len(data["frames"]) == 2


def test_extract_frames_invalid_method(mock_video_file):
    """Test frame extraction with invalid method."""
    response = client.post(
        "/extract-frames",
        files={"video_file": ("test.mp4", mock_video_file, "video/mp4")},
        data={"method": "invalid", "threshold": "0.8"}
    )
    
    assert response.status_code == 400
    assert "Invalid method" in response.json()["detail"]


def test_extract_frames_invalid_threshold(mock_video_file):
    """Test frame extraction with invalid threshold."""
    response = client.post(
        "/extract-frames",
        files={"video_file": ("test.mp4", mock_video_file, "video/mp4")},
        data={"method": "ssim", "threshold": "1.5"}
    )
    
    assert response.status_code == 400
    assert "Threshold must be between 0 and 1" in response.json()["detail"]


def test_extract_frames_invalid_file_type():
    """Test frame extraction with invalid file type."""
    response = client.post(
        "/extract-frames",
        files={"video_file": ("test.exe", b"malicious content", "application/x-msdownload")},
        data={"method": "ssim", "threshold": "0.8"}
    )
    
    assert response.status_code == 400
    assert "Invalid file type" in response.json()["detail"]


def test_get_frame_not_found(mock_uuid):
    """Test getting a non-existent frame."""
    response = client.get(f"/get-frame/{mock_uuid}/frame_0000.png")
    assert response.status_code == 404


def test_background_tasks_list():
    """Test listing background tasks."""
    response = client.get("/background-tasks")
    assert response.status_code == 200
    assert isinstance(response.json(), dict)


def test_background_task_status_invalid_uuid():
    """Test getting status of non-existent task."""
    response = client.get("/background-tasks/invalid-uuid")
    assert response.status_code == 400


def test_background_task_status_not_found(mock_uuid):
    """Test getting status of non-existent task with valid UUID."""
    response = client.get(f"/background-tasks/{mock_uuid}")
    assert response.status_code == 404


# ============== Error Handler Tests ==============

def test_404_handler():
    """Test 404 error handler."""
    response = client.get("/non-existent-endpoint")
    assert response.status_code == 404
    assert "Resource not found" in response.json()["detail"]


# ============== Rate Limiting Tests ==============

# Note: These tests would require a running Redis instance
# or mocking the rate limiter


# ============== Integration Tests ==============

@pytest.mark.integration
@patch('main.asyncio.create_subprocess_exec')
def test_extract_frames_url_success(mock_subprocess):
    """Test successful frame extraction from URL (integration)."""
    # Mock subprocess
    mock_proc = MagicMock()
    mock_proc.returncode = 0
    mock_proc.communicate = MagicMock(return_value=(b"", b""))
    mock_subprocess.return_value = mock_proc
    
    with patch('main.extract_frames') as mock_extract:
        mock_extract.return_value = ["frame_0000.png"]
        
        response = client.post(
            "/extract-frames-url",
            data={
                "reel_url": "https://www.instagram.com/reel/ABC123/",
                "method": "ssim",
                "threshold": "0.8"
            }
        )
        
        assert response.status_code == 200 or response.status_code == 201


@pytest.mark.integration
def test_extract_frames_url_invalid_url():
    """Test frame extraction from invalid URL."""
    response = client.post(
        "/extract-frames-url",
        data={
            "reel_url": "https://malicious.com/exec/rm -rf /",
            "method": "ssim",
            "threshold": "0.8"
        }
    )
    
    assert response.status_code == 400
    assert "Invalid URL" in response.json()["detail"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
