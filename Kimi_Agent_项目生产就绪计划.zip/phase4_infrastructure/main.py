"""
ReelShot Backend - Phase 2: Stability & Performance
Fixed: Command Injection, Path Traversal, Arbitrary File Write
Added: Async operations, Thread pool, Graceful shutdown, Health checks
"""

import os
import sys
import asyncio
import shutil
import uuid
import signal
import time
import psutil
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import aiofiles
from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks, Request, Form, status
from fastapi.responses import JSONResponse, StreamingResponse, PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings

# Prometheus metrics
try:
    from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    print("⚠️  prometheus-client not installed, metrics disabled")

# Import security utilities
from utils.validators import (
    validate_reel_url,
    validate_uuid,
    validate_filename,
    validate_file_extension,
    validate_method,
    validate_threshold,
    get_safe_path,
)
from utils.security import (
    ValidationError,
    build_safe_command,
    run_subprocess_with_timeout,
    get_secure_temp_filename,
    SimpleRateLimiter,
    get_security_headers,
)
from utils.video_utils import extract_frames


# ============== Configuration ==============

class Settings(BaseSettings):
    """Application settings with validation."""
    storage_folder: str = Field(default="storage", alias="STORAGE_FOLDER")
    frontend_url: str = Field(default="http://localhost:5173", alias="FRONTEND_URL")
    port: int = Field(default=8000, alias="PORT")
    delete_delay_mins: int = Field(default=10, alias="DELETE_DELAY_MINS")
    max_file_size: int = Field(default=500 * 1024 * 1024, alias="MAX_FILE_SIZE")  # 500MB
    
    # Performance settings
    max_workers: int = Field(default=4, alias="MAX_WORKERS")
    task_timeout: int = Field(default=600, alias="TASK_TIMEOUT")  # 10 minutes
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()


# ============== Prometheus Metrics ==============

if PROMETHEUS_AVAILABLE:
    # Request metrics
    http_requests_total = Counter(
        'http_requests_total',
        'Total HTTP requests',
        ['method', 'endpoint', 'status']
    )
    
    http_request_duration_seconds = Histogram(
        'http_request_duration_seconds',
        'HTTP request duration in seconds',
        ['method', 'endpoint'],
        buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0]
    )
    
    # Application metrics
    video_uploads_total = Counter(
        'video_uploads_total',
        'Total video uploads',
        ['method', 'status']
    )
    
    frames_extracted_total = Counter(
        'frames_extracted_total',
        'Total frames extracted',
        ['method']
    )
    
    active_processing_tasks = Gauge(
        'active_processing_tasks',
        'Number of active video processing tasks'
    )
    
    # System metrics (if psutil is available)
    if 'psutil' in sys.modules:
        system_cpu_percent = Gauge(
            'system_cpu_percent',
            'System CPU usage percentage'
        )
        
        system_memory_percent = Gauge(
            'system_memory_percent',
            'System memory usage percentage'
        )


# ============== Application State ==============

class ApplicationState:
    """Application state for monitoring and graceful shutdown."""
    
    def __init__(self):
        self.start_time = time.time()
        self.shutdown_event = asyncio.Event()
        self.active_tasks = 0
        self.total_requests = 0
        self.total_errors = 0
    
    def get_uptime_seconds(self) -> float:
        """Get application uptime in seconds."""
        return time.time() - self.start_time
    
    def get_uptime_formatted(self) -> str:
        """Get formatted uptime string."""
        uptime = self.get_uptime_seconds()
        hours = int(uptime // 3600)
        minutes = int((uptime % 3600) // 60)
        seconds = int(uptime % 60)
        return f"{hours}h {minutes}m {seconds}s"


app_state = ApplicationState()


# ============== Thread Pool ==============

class ThreadPoolManager:
    """Managed thread pool with graceful shutdown."""
    
    def __init__(self, max_workers: int = 4):
        self.max_workers = max_workers
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self._shutdown = False
    
    async def submit(self, func, *args, **kwargs):
        """Submit task to thread pool."""
        if self._shutdown:
            raise RuntimeError("Thread pool is shutting down")
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self.executor,
            func,
            *args,
            **kwargs
        )
    
    def shutdown(self, wait: bool = True):
        """Shutdown thread pool gracefully."""
        self._shutdown = True
        self.executor.shutdown(wait=wait)


# Initialize thread pool manager
thread_pool = ThreadPoolManager(max_workers=settings.max_workers)

# Rate limiters
upload_limiter = SimpleRateLimiter(max_requests=5, window_seconds=60)
url_limiter = SimpleRateLimiter(max_requests=3, window_seconds=60)
frame_limiter = SimpleRateLimiter(max_requests=60, window_seconds=60)


# ============== FastAPI App ==============

app = FastAPI(
    title="ReelShot API",
    description="API for extracting frames from video files - Security Hardened",
    version="1.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Security Headers Middleware
@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    """Add security headers to all responses."""
    response = await call_next(request)
    
    # Prevent MIME type sniffing
    response.headers["X-Content-Type-Options"] = "nosniff"
    
    # Prevent clickjacking
    response.headers["X-Frame-Options"] = "DENY"
    
    # XSS Protection
    response.headers["X-XSS-Protection"] = "1; mode=block"
    
    # Referrer Policy
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    
    # Content Security Policy (CSP)
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; "
        "font-src 'self'; "
        "connect-src 'self'; "
        "media-src 'self' blob:; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self';"
    )
    
    # Permissions Policy (formerly Feature Policy)
    response.headers["Permissions-Policy"] = (
        "accelerometer=(), "
        "camera=(), "
        "geolocation=(), "
        "gyroscope=(), "
        "magnetometer=(), "
        "microphone=(), "
        "payment=(), "
        "usb=()"
    )
    
    # Remove server identification
    response.headers.pop("Server", None)
    
    return response


# Request monitoring middleware
@app.middleware("http")
async def monitoring_middleware(request: Request, call_next):
    """Monitor requests and track metrics."""
    import time
    
    app_state.total_requests += 1
    start_time = time.time()
    
    try:
        response = await call_next(request)
        
        if response.status_code >= 400:
            app_state.total_errors += 1
        
        # Prometheus metrics
        if PROMETHEUS_AVAILABLE:
            duration = time.time() - start_time
            endpoint = request.url.path
            method = request.method
            status = str(response.status_code)
            
            http_requests_total.labels(
                method=method,
                endpoint=endpoint,
                status=status
            ).inc()
            
            http_request_duration_seconds.labels(
                method=method,
                endpoint=endpoint
            ).observe(duration)
        
        return response
    except Exception:
        app_state.total_errors += 1
        
        # Record error in Prometheus
        if PROMETHEUS_AVAILABLE:
            http_requests_total.labels(
                method=request.method,
                endpoint=request.url.path,
                status="500"
            ).inc()
        
        raise


# CORS middleware - restrictive
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_url],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
    max_age=600,
)

# Create storage directory
os.makedirs(settings.storage_folder, exist_ok=True)


# ============== Thread-safe task storage ==============

class TaskStorage:
    """Thread-safe storage for background tasks."""
    
    def __init__(self):
        self._storage: Dict[str, Dict] = {}
        self._lock = asyncio.Lock()
    
    async def get(self, key: str) -> Optional[Dict]:
        async with self._lock:
            return self._storage.get(key)
    
    async def set(self, key: str, value: Dict):
        async with self._lock:
            self._storage[key] = value
    
    async def update(self, key: str, updates: Dict):
        async with self._lock:
            if key in self._storage:
                self._storage[key].update(updates)


task_storage = TaskStorage()


# ============== Background Tasks ==============

async def delete_frames_after_delay(unique_id: str, delay_minutes: int):
    """Delete frames after a specified delay using asyncio."""
    await asyncio.sleep(delay_minutes * 60)
    
    # Валидация UUID перед удалением
    if not validate_uuid(unique_id):
        print(f"Invalid UUID in cleanup: {unique_id}")
        return
    
    frame_dir = Path(settings.storage_folder) / unique_id
    if frame_dir.exists():
        shutil.rmtree(frame_dir)
    
    await task_storage.update(unique_id, {
        "status": "completed",
        "end_time": datetime.now().isoformat()
    })


# ============== API Models ==============

class SystemInfo(BaseModel):
    """System information for health check."""
    cpu_percent: float
    memory_percent: float
    memory_available_mb: float
    disk_usage_percent: float
    disk_free_gb: float


class HealthResponse(BaseModel):
    """Enhanced health check response."""
    status: str
    timestamp: str
    version: str
    uptime_seconds: float
    uptime_formatted: str
    system: SystemInfo
    active_tasks: int
    total_requests: int
    total_errors: int


class FrameExtractionResponse(BaseModel):
    unique_id: str
    frames: Dict[str, str]
    message: str


class TaskStatusResponse(BaseModel):
    status: str
    start_time: str
    end_time: Optional[str]
    frames: List[str]


# ============== Endpoints ==============

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Comprehensive health check endpoint.
    Returns system status and metrics.
    """
    # Get system information
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage(settings.storage_folder)
    
    # Determine overall status
    status = "healthy"
    if memory.percent > 90 or disk.percent > 90:
        status = "degraded"
    if memory.percent > 95 or disk.percent > 95:
        status = "critical"
    
    # Update Prometheus system metrics
    if PROMETHEUS_AVAILABLE and 'psutil' in sys.modules:
        system_cpu_percent.set(cpu_percent)
        system_memory_percent.set(memory.percent)
    
    return HealthResponse(
        status=status,
        timestamp=datetime.now().isoformat(),
        version="1.3.0-infrastructure",
        uptime_seconds=app_state.get_uptime_seconds(),
        uptime_formatted=app_state.get_uptime_formatted(),
        system=SystemInfo(
            cpu_percent=cpu_percent,
            memory_percent=memory.percent,
            memory_available_mb=memory.available / (1024 * 1024),
            disk_usage_percent=disk.percent,
            disk_free_gb=disk.free / (1024 * 1024 * 1024)
        ),
        active_tasks=app_state.active_tasks,
        total_requests=app_state.total_requests,
        total_errors=app_state.total_errors
    )


@app.get("/metrics")
async def metrics():
    """
    Prometheus metrics endpoint.
    Returns metrics in Prometheus format.
    """
    if not PROMETHEUS_AVAILABLE:
        return PlainTextResponse(
            "# Metrics disabled - prometheus-client not installed",
            status_code=503
        )
    
    return PlainTextResponse(
        content=generate_latest(),
        media_type=CONTENT_TYPE_LATEST
    )


@app.post("/extract-frames", response_model=FrameExtractionResponse)
async def extract_frames_api(
    request: Request,
    video_file: UploadFile = File(...),
    method: str = Form("ssim"),
    threshold: float = Form(0.8),
    background_tasks: BackgroundTasks = None,
):
    """
    Extract frames from uploaded video file.
    Security: File type validation, size limits, rate limiting
    """
    # Rate limiting
    client_ip = request.client.host
    if not upload_limiter.is_allowed(client_ip):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded. Max 5 uploads per minute."
        )
    
    # Validate method
    if not validate_method(method):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid method. Use 'ssim' or 'pixel'."
        )
    
    # Validate threshold
    if not validate_threshold(threshold):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Threshold must be between 0 and 1."
        )
    
    # Validate file extension
    if not validate_file_extension(video_file.filename):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid file type. Allowed: .mp4, .avi, .mov, .mkv, .webm"
        )
    
    unique_id = str(uuid.uuid4())
    
    try:
        video_path = get_secure_temp_filename(video_file.filename, unique_id)
    except ValidationError as e:
        raise HTTPException(400, str(e))
    
    # Track active task
    app_state.active_tasks += 1
    
    try:
        # Read and validate file size
        contents = await video_file.read()
        
        if len(contents) > settings.max_file_size:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File too large. Max size: {settings.max_file_size // (1024*1024)}MB"
            )
        
        # Async file write
        async with aiofiles.open(video_path, "wb") as f:
            await f.write(contents)
        
        # Create frame directory
        frame_dir = Path(settings.storage_folder) / unique_id
        frame_dir.mkdir(parents=True, exist_ok=True)
        
        # Run CPU-intensive operation in thread pool
        frame_names = await thread_pool.submit(
            extract_frames,
            str(video_path),
            method,
            threshold,
            str(frame_dir)
        )
        
        # Schedule cleanup
        if background_tasks:
            background_tasks.add_task(
                delete_frames_after_delay,
                unique_id,
                settings.delete_delay_mins
            )
        
        # Store task info
        await task_storage.set(unique_id, {
            "status": "pending",
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "frames": frame_names,
        })
        
        # Generate frame URLs
        frame_urls = {
            name: f"/get-frame/{unique_id}/{name}"
            for name in frame_names
        }
        
        # Record Prometheus metrics
        if PROMETHEUS_AVAILABLE:
            video_uploads_total.labels(
                method="upload",
                status="success"
            ).inc()
            
            frames_extracted_total.labels(
                method=method
            ).inc(len(frame_names))
        
        return FrameExtractionResponse(
            unique_id=unique_id,
            frames=frame_urls,
            message=f"Successfully extracted {len(frame_names)} frames"
        )
    
    except HTTPException as e:
        # Record failed upload
        if PROMETHEUS_AVAILABLE:
            video_uploads_total.labels(
                method="upload",
                status="error"
            ).inc()
        raise
    except Exception as e:
        # Record failed upload
        if PROMETHEUS_AVAILABLE:
            video_uploads_total.labels(
                method="upload",
                status="error"
            ).inc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing video: {str(e)}"
        )
    finally:
        # Decrement active task counter
        app_state.active_tasks -= 1
        
        # Update Prometheus gauge
        if PROMETHEUS_AVAILABLE:
            active_processing_tasks.set(app_state.active_tasks)
        
        # Guaranteed cleanup
        if os.path.exists(video_path):
            os.remove(video_path)


@app.get("/get-frame/{unique_id}/{frame_name}")
async def get_frame(request: Request, unique_id: str, frame_name: str):
    """
    Serve a specific frame as an image.
    Security: UUID validation, filename validation, path traversal protection
    """
    # Rate limiting
    client_ip = request.client.host
    if not frame_limiter.is_allowed(client_ip):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded."
        )
    
    # Validate UUID format
    if not validate_uuid(unique_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid unique_id format"
        )
    
    # Validate filename format
    if not validate_filename(frame_name):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid frame_name format"
        )
    
    # Get safe path (path traversal protection)
    try:
        frame_path = get_safe_path(settings.storage_folder, unique_id, frame_name)
    except ValueError as e:
        raise HTTPException(status_code=403, detail="Access denied")
    
    if not frame_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Frame not found. It may have been deleted."
        )
    
    # Add security headers
    headers = get_security_headers()
    headers['Cache-Control'] = 'public, max-age=3600'
    
    return StreamingResponse(
        open(frame_path, "rb"),
        media_type="image/png",
        headers=headers
    )


@app.post("/extract-frames-url")
async def extract_frames_url_api(
    request: Request,
    reel_url: str = Form(...),
    method: str = Form('ssim'),
    threshold: float = Form(0.8),
    background_tasks: BackgroundTasks = None,
):
    """
    Extract frames from video URL.
    Security: URL validation, command injection prevention, rate limiting
    """
    # Rate limiting
    client_ip = request.client.host
    if not url_limiter.is_allowed(client_ip):
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Rate limit exceeded. Max 3 URL extractions per minute."
        )
    
    # Validate method
    if not validate_method(method):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid method. Use 'ssim' or 'pixel'."
        )
    
    # Validate threshold
    if not validate_threshold(threshold):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Threshold must be between 0 and 1."
        )
    
    # Validate URL (CRITICAL: prevents command injection!)
    if not validate_reel_url(reel_url):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid URL. Only Instagram, YouTube, Facebook, and TikTok URLs are allowed."
        )
    
    unique_id = str(uuid.uuid4())
    video_path = f"temp_{unique_id}.mp4"
    
    # Track active task
    app_state.active_tasks += 1
    
    try:
        # Build safe command (prevents command injection)
        command = build_safe_command(
            ["yt-dlp", "-f", "best[ext=mp4]/best"],
            reel_url,
            video_path
        )
        
        # Add max file size limit
        command.extend(["--max-filesize", str(settings.max_file_size)])
        
        # Run subprocess with timeout
        try:
            stdout, stderr = await run_subprocess_with_timeout(command, timeout=300)
        except asyncio.TimeoutError:
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail="Download timed out after 5 minutes."
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unable to download video: {str(e)}"
            )
        
        # Create frame directory
        frame_dir = Path(settings.storage_folder) / unique_id
        frame_dir.mkdir(parents=True, exist_ok=True)
        
        # Extract frames using thread pool
        frame_names = await thread_pool.submit(
            extract_frames,
            video_path,
            method,
            threshold,
            str(frame_dir)
        )
        
        # Schedule cleanup
        if background_tasks:
            background_tasks.add_task(
                delete_frames_after_delay,
                unique_id,
                settings.delete_delay_mins
            )
        
        # Store task info
        await task_storage.set(unique_id, {
            "status": "pending",
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "frames": frame_names,
        })
        
        # Generate frame URLs
        frame_urls = {
            name: f"/get-frame/{unique_id}/{name}"
            for name in frame_names
        }
        
        return FrameExtractionResponse(
            unique_id=unique_id,
            frames=frame_urls,
            message=f"Successfully extracted {len(frame_names)} frames"
        )
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing video: {str(e)}"
        )
    finally:
        # Decrement active task counter
        app_state.active_tasks -= 1
        
        # Guaranteed cleanup
        if os.path.exists(video_path):
            os.remove(video_path)


@app.get("/background-tasks/{unique_id}")
async def get_background_task_status(unique_id: str):
    """Get the status of a specific background task."""
    if not validate_uuid(unique_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid unique_id format"
        )
    
    task = await task_storage.get(unique_id)
    if not task:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Background task not found."
        )
    
    return TaskStatusResponse(**task)


# ============== Error Handlers ==============

@app.exception_handler(404)
async def not_found_exception_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"detail": "Resource not found."},
        headers=get_security_headers()
    )


@app.exception_handler(500)
async def internal_server_error_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Please try again later."},
        headers=get_security_headers()
    )


# ============== Signal Handlers ==============

def handle_signal(signum, frame):
    """Handle shutdown signals gracefully."""
    sig_name = signal.Signals(signum).name
    print(f"\n🛑 Received {sig_name}, initiating graceful shutdown...")
    
    # Set shutdown event
    asyncio.create_task(shutdown_gracefully())


async def shutdown_gracefully():
    """Graceful shutdown procedure."""
    print("⏳ Waiting for active tasks to complete...")
    
    # Signal shutdown
    app_state.shutdown_event.set()
    
    # Wait for active tasks (with timeout)
    wait_time = 0
    max_wait = 30  # seconds
    while app_state.active_tasks > 0 and wait_time < max_wait:
        await asyncio.sleep(1)
        wait_time += 1
        print(f"   Waiting... {app_state.active_tasks} tasks remaining")
    
    if app_state.active_tasks > 0:
        print(f"⚠️  Force shutdown after {max_wait}s, {app_state.active_tasks} tasks incomplete")
    else:
        print("✅ All tasks completed")
    
    # Shutdown thread pool
    print("🧵 Shutting down thread pool...")
    thread_pool.shutdown(wait=False)
    
    # Cleanup temporary files
    print("🧹 Cleaning up temporary files...")
    temp_files = list(Path('.').glob('temp_*'))
    for temp_file in temp_files:
        try:
            temp_file.unlink()
            print(f"   Removed: {temp_file}")
        except Exception as e:
            print(f"   Failed to remove {temp_file}: {e}")
    
    print("👋 Shutdown complete")
    sys.exit(0)


# ============== Startup/Shutdown ==============

@app.on_event("startup")
async def startup_event():
    """Initialize on startup."""
    # Create storage directory
    os.makedirs(settings.storage_folder, exist_ok=True)
    
    # Register signal handlers
    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)
    
    print(f"🚀 ReelShot API v1.2.0 started (Stability & Performance)")
    print(f"   Storage: {settings.storage_folder}")
    print(f"   Max file size: {settings.max_file_size // (1024*1024)}MB")
    print(f"   Max workers: {settings.max_workers}")
    print(f"   PID: {os.getpid()}")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    print("🧹 FastAPI shutdown event triggered")
    # Graceful shutdown is handled by signal handlers


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=settings.port, reload=False)
